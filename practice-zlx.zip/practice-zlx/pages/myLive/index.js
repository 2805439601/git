// pages/myLive/index.js
var app = getApp();
var urls = {
  'index': 'source=self&op=myEnter'
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pages:1,
    list:{},
    nomore:false,
    show:false,//弹框
    hideBox:false,//遮罩层
    vods:[],//弹框内容
    
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var data = { page: 1},
      url = urls['index'],
      s = { url: url, data: data };
    app.request(s, function (inf) {
        console.log(inf)
      if (inf.errorCode == 0) {
        console.log(inf.data.list)
        that.setData({
          list: inf.data.list
        })
      }
    })
  },
  go: function(e){
    var that = this
    var live = e.currentTarget.dataset.live
    var live_status = e.currentTarget.dataset.live_status
    if(live_status == '2'){
      wx.navigateTo({
        url: '../videodemo/videodemo?item=' + JSON.stringify(live),
      })
    } else if (live_status == '0') {
      
      
      wx.showModal({
        title: '直播未开始',
        content: '',
      })
    } else if (live_status == '1') {
      var tag = e.currentTarget.dataset.tag
      var url = e.currentTarget.dataset.url
      var vods = e.currentTarget.dataset.vods
      
      if (tag == 1) {
        if (vods.length == 1) {
        var item = vods[0]
        wx.navigateTo({
          url: '/pages/vodDemo/vodDemo?item=' + JSON.stringify(item)
        })
        }else{
          that.setData({
            show: true,
            vods: vods,
            hideBox: true
          })
        }
        // wx.navigateTo({
        //   url: '../myOld/index?url=' + url,
        // })
        
       
      } else {
        wx.showModal({
          title: '直播已结束',
          content: '没有录播视频',
        })
      }
      
    }
  },
  allgo:function(e){
    var that = this
    var item = e.currentTarget.dataset.item
    wx.navigateTo({
      url: '/pages/vodDemo/vodDemo?item=' + JSON.stringify(item)
    })
  },
  // 关闭弹框
  vclose:function(){
    var that = this
    that.setData({
      show:false,
      vods:[],
      hideBox:false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    // 显示顶部刷新图标
    wx.showNavigationBarLoading();
    var that = this
    var data = { page: 1 },
      url = urls['index'],
      s = { url: url, data: data };
    app.request(s, function (inf) {
      console.log(inf)
      // 隐藏导航栏加载框
      wx.hideNavigationBarLoading();
      // 停止下拉动作
      wx.stopPullDownRefresh();
      if (inf.errorCode == 0) {
        that.setData({
          list: inf.data.list,
          pages:1,
          nomore:false
        })
      }
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this
    var data = { page: that.data.pages + 1 },
      url = urls['index'],
      s = { url: url, data: data };
    app.request(s, function (inf) {
      console.log(inf)
      if (inf.errorCode == 0) {
        if (inf.data.list == ''){
          that.setData({
            nomore: true
          })
          wx.showToast({
            title: "没有更多数据了",
            icon: "success",
            duration: 2e3
          })
        } else{
          var list = that.data.list
          for(var i =0 ;i < inf.data.list.length;i++){
            list.push(inf.data.list[i])
          }
          that.setData({
            pages: that.data.pages + 1,
            list:list,
            nomore: false
          })
        }
        
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})