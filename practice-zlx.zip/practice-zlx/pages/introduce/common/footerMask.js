var app = getApp();
var myFooter = {
	data: {
		sizeIndex:0,//尺寸编号
		isProduce:2,//产品弹窗
		isFooterMask:2//底部弹窗
	},

	page: null,

	setData: function (opt) {
		this.page && this.page.setData(opt);
	},
	//用户授权
	getuserinfo: function(e){
		var userInfo = e.detail.userInfo;
		var that = this;
		if (userInfo){
			that.setData({
        islogin: true,
        isOpen: 2
			})
			wx.setStorageSync('scope.userInfo', userInfo);
			app.globalData.userInfo = userInfo;
			app.globalData.islogin = true;

			// if(e.target.dataset.type == "myStudent"){
			// 	that.myStudent();
			// }else{
			// 	that.myBuy();
      // }
      // console.log(wx.getStorageSync('scence'),23121212132434534)
      app.getToken(function () {
        // if(wx.getStorageSync('scence').scene == 1007 || wx.getStorageSync('scence').scene == 1008){
          // wx.navigateBack()
          // that.onLoad()
          // that.onShow()
          that.onReady()
        // }else{
        //   wx.reLaunch({
        //     url: '../index/index',
        //   })
        // }
      })
      // }
      // wx.redirectTo({
      //   url: '../index/index',
      // })
    

		}else{
			wx.showModal({
				title: '提示',
				showCancel: false,
				confirmColor: '#333333',
				content: '你已拒绝授权',
			})
		}
	},
  closeGetUser:function (e) {//关闭授权弹框
    var status = e.currentTarget.dataset.status;
    
    if (status =='getuserinfo'){
      this.setData({
        isOpen: 2
      })
    } else if (status =='getphonenumber'){
      this.setData({
        isphone: true
      })
    }
    
  },
  gonavigator:function (e) {
    var that = this;
    var vee = e.currentTarget.dataset.tap;
    if (app.globalData.islogin) {
      if (vee ==='myCollect'){
        that.myCollect(e);
      }
    } else {
      that.setData({
        isOpen: 1
      })
    }
  },
	//点击菜单弹窗
	myMaskShow: function (e) {
		var that = this,
			isShow = that.data.isFooterMask; 
		isShow == 1 ? isShow = 2 : isShow = 1;
		that.setData({
			isFooterMask: isShow
		})
	},
	myProduceShow:function(){
		var that = this,
			isShow = that.data.isProduce;
		isShow == 1 ? isShow = 2 : isShow = 1;
		that.setData({
			isProduce: isShow
		})
	},
	myStudent:function(){
    // console.log(this.data.query);
		  var that = this,
			myVideo = that.data.myVideo,
			myAudio = that.data.myAudio;
      app.myPhone(function(){
        that.setData({
          isphone:false
        })
      },function(){
        if (that.data.myData.section_list.length == 0 || !that.data.myData.section_list) {
          wx.showModal({
            title: '提示',
            showCancel: false,
            confirmColor: '#333333',
            content: '当前课程暂时没有更新',
          })
          return;
        }
        if (that.data.myData.lesson.disable == '1'){
          wx.showModal({
            title: '系统提示',
            content: '该课程已被禁用',
          })
          return
        }
        var index = parseInt(that.data.myIndex) || 0,
          sectionid = that.data.myData.section_list[index].id;
        var data1 = { id: that.data.id, op: 'display', sectionid: sectionid },
          url = 'source=lesson',
          data = {},
          s = { url: url, data: data1 };
        app.request(s, function (inf) {
          //console.log(inf)
          if (inf.errorCode == 0) {
            // console.log(index)
            var sectiontype = that.data.myData.section_list[index].sectiontype;//1：视频章节；2：图文章节；3音频章节；4：外链章节（已弃用）；5：直播章节
            var is_show = that.data.myData.section_list[index].is_show
            // console.log(sectiontype)
            if (is_show == 0){
              wx.showModal({
                title: '该章节未上架',
                content: '',
              })
              return
            }
            if (sectiontype == 1) {
              //先判断一下是否有观看记录，提示再跳转
              var query = that.data.query;
              wx.getStorage({
                key: 'isLook',
                success(res) {
                  res.data.forEach((item, index) => {
                    if (query.id == item.id) {//同一课程同一章
                      var diji = parseInt(item.idx) + 1;
                      wx.showModal({
                        title: '温馨提示',
                        content: '检测到您上次观看到本课程的第' + diji + '章节，是否继续观看',
                        success(rre) {
                          if (rre.confirm) {
                            // console.log('用户点击确定')
                            wx.navigateTo({
                              url: '/pages/introduce/section?sectionid=' + item.sectionid + '&sectiontype=' + item.sectiontype + '&idx=' + item.idx + '&id=' + item.id
                            })
                            //跳转
                          } else if(rre.cancel) {
                            wx.navigateTo({
                              url: '/pages/introduce/section?sectionid=' + sectionid + '&sectiontype=' + sectiontype + '&idx=' + index + '&id=' + that.data.id
                            })
                          }
                        }
                      })
                    }
                  })
                },
                fail(err){
                  wx.navigateTo({
                    url: '/pages/introduce/section?sectionid=' + sectionid + '&sectiontype=' + sectiontype + '&idx=' + index + '&id=' + that.data.id
                  })
                }
              })
              
            } else if (sectiontype == 2) {
              that.setData({ isVideo: 1 });
              wx.navigateTo({
                url: 'title?sectionid=' + sectionid + '&idx=' + index + '&id=' + that.data.id
              })
            } else if (sectiontype == 5){
              var live_status = that.data.myData.section_list[index].live_info.live_status;
              var live_info = that.data.myData.section_list[index].live_info
              if (live_status == 1) {
                // 看录播
                if (live_info.vods == '') {
                  wx.showModal({
                    title: '暂无录播视频',
                    content: '',
                  })
                } else if (live_info.vods.length == 1) {
                  var item = live_info.vods[0]
                  wx.navigateTo({
                    url: '/pages/vodDemo/vodDemo?item=' + JSON.stringify(item)
                  })
                } else {
                  that.setData({
                    vods: live_info.vods,
                    hideBox: true,
                    show: true,
                  })
                }

              } else if (live_status == 2 || live_status == 3) {
                // 看直播
                var live = that.data.myData.section_list[index].live_info.live
                wx.navigateTo({
                  url: '../videodemo/videodemo?item=' + JSON.stringify(live),
                })
              } else {
                // 未开始
                wx.showModal({
                  title: '直播未开始',
                  content: '',
                  showCancel: false
                })
              }

            } else {
              wx.navigateTo({
                url: '/pages/introduce/section?sectiontype=' + sectiontype + 'idx=' + index + '&id=' + that.data.id
              })
            }
            data.myIndex = index;
            that.setData(data);
          } else {
            wx.showModal({
              title: '提示',
              showCancel: false,
              confirmColor: '#333333',
              content: inf.data.message,
            })
          }
        }, function (inf) {
          wx.showModal({
            title: '提示',
            showCancel: false,
            confirmColor: '#333333',
            content: '数据加载失败',
          })
        })
      });
        //console.log(123)
      
		
	},
	//收藏
	myCollect : function(e){
		var that = this,
			key = e.currentTarget.dataset['key'],
			id = that.data.id,
			myData = that.data.myData;
			
		var data = { id: id, ctype: 'lesson' },
			s = { url: 'source=updatecollect', data: data };
		app.request(s, function (inf) {
			if (inf.errorCode==0){
				var data1 = inf.data;
				if (data1.status==1){
					myData.collect = 1;
				} else if (data1.status == 2){
					myData.collect = 2;
				}
				wx.showToast({
					title: data1.message,
					icon: 'success',
					duration: 2000
				})
				that.setData({
					myData: myData
				})
			}
		},function(inf){

		})
	},
	//购买
	myBuy:function(e){
		var that = this;
    app.myPhone(function () {
      that.setData({
        isphone: false
      })
    }, function () {
      if (that.data.myData.buynow_link) {
        // console.log(1)
      } else {
        //console.log(2)
        that.setData({
          isProduce: 1
        })
      }
    })
		
	},
  
	//选择规格
	choseSize:function(e){
		var that = this,
			index = e.currentTarget.dataset['index'],
			myData = that.data.myData,
			sizeId = that.data.myData.spec_list[index].spec_id,
			sizeDay = that.data.myData.spec_list[index].spec_day,
			sizePrice = that.data.myData.spec_list[index].spec_price;
			//console.log(that.data.sizeIndex)
			myData.lesson.price = sizePrice;
			that.setData({
				myData: myData,
				sizeIndex: index,
				sizeId: sizeId,
				sizeDay: sizeDay,
				sizePrice: sizePrice
			})
	},
	//查看二维码
	lookImg: function(){
		var that = this,
			img = [that.data.myData.lesson.weixin_qrcode];
			
		wx.previewImage({
			current: '', // 当前显示图片的http链接
			urls: img // 需要预览的图片http链接列表
		})
  },
	//确认订单
	goConfirm: function(){
    var that = this;
    if(that.data.syInfo=='ios'){
      wx.showModal({
        title: '提示',
        // content: '由于相关规范，iOS功能暂不可用',
        content: '了解更多课程信息，请前往观看试听课程',
        // showCancel:false
        success:function(res){
          if(res.confirm){
            that.setData({
              myTap:2
            })
          }
        }
      })
      return
    }
    var spec_id = 0;
    for (var i = 0; i < that.data.myData.spec_list.length;i++){
      if (that.data.myData.lesson.price == that.data.myData.spec_list[i].spec_price){
        spec_id = that.data.myData.spec_list[i].spec_id
      }
    }
    var data = { id: that.data.id, spec_id: spec_id },
			url = 'source=confirm',
			s = { url: url, data: data };
		app.request(s, function (inf) {
      if (inf.errorCode == 0) {
				that.setData({isProduce:2});
				wx.navigateTo({
					url: '/pages/introduce/confirm?id=' + that.data.id + '&spec_id=' + spec_id
				})
      } else if (inf.errorCode == 4401){
        console.log(that.data)
        
        that.myStudent()
      }else{
				wx.showModal({
					title: '提示',
					confirmColor: '#333333',
					content: inf.data.message,
					success: function (res) {
						if (res.confirm) {
							if (inf.data.message=='您还有该课程未付款订单！'){
								wx.reLaunch({
                  url: '/pages/myOrder/index'
								})
							}
						} else if (res.cancel) {
							/*wx.reLaunch({
								url: '/pages/myCurse/index'
							})*/
						}
					}
				})
			}

		},function(inf){

		})
	},
	
	init: function (page) {
		var self = this;
		this.page = page;
		
		//配置本组件函数到页面
		page.myMaskShow = this.myMaskShow;
		page.myCollect = this.myCollect;
		page.myBuy = this.myBuy;
		page.choseSize = this.choseSize;
		page.myProduceShow = this.myProduceShow;
		page.lookImg = this.lookImg;
		page.myStudent = this.myStudent;
		page.goConfirm = this.goConfirm;
		page.getuserinfo = this.getuserinfo;
    page.closeGetUser = this.closeGetUser;
    page.gonavigator = this.gonavigator;
		// 配置本组件数据到页面
		this.setData(this.data);

		//console.log(page);
	},
};
module.exports = myFooter;