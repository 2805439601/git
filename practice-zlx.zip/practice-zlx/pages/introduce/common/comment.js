var app = getApp();
var comment = {
	data: {
		isComment: 1,
		content:'',
		isInput:true,
		pic:''//是否显示导航
	},

	page: null,

	setData: function (opt) {
		this.page && this.page.setData(opt);
	},
	//点赞
	myPraise:function(e){
		var that = this,
			id = e.currentTarget.dataset['id'],
			idx = e.currentTarget.dataset['idx'],
			key = e.currentTarget.dataset['key'];
		console.log(idx)
		var data = { 'class': key, id: id, op:'like_num'},
			url = 'source=chapterreviews',
			s = { url: url, data: data };
		app.request(s, function (inf) {
			console.log(inf)
			if (inf.errorCode == 0) {
				var data1 = inf.data;
				wx.showToast({
					title: data1.message,
					icon: 'success',
					duration: 2000
				});
				if (idx>=0){
					var list = that.data.list;
					
					if (that.data.SaveNo==2){
						list[idx].st_2 = data1.static;
						list[idx].likes_num = parseInt(data1.num_add);
					}else{
						list[idx].st = data1.static;
						list[idx].like_num = parseInt(data1.num_add);
					}
					
					that.setData({
						list:list
					})
				}else{
					that.setData({
						st_1: data1.static,
						like_num: parseInt(data1.num_add)
					})
				}
				
				
			} else {
				wx.showModal({
					title: '提示',
					showCancel: false,
					confirmColor: '#333333',
					content: inf.data.message,
				})
			}

		}, function (inf) {
			wx.showModal({
				title: '提示',
				showCancel: false,
				confirmColor: '#333333',
				content: inf.data.message,
			})
		})
	},
	//选择表情
	choseFace :function (e) {
		var that = this,

			content = that.data.content || '',
			key = e.currentTarget.dataset['face'],
			data = {};
		content = content + '[EM' + key + ']';
		data.pic = '';
		data.content = content;
		that.setData(data)

	},
	//关闭评论
	myClose:function(e){
		var key = e.currentTarget.dataset['key'],
			myplaceholder = e.currentTarget.dataset['myplaceholder'],
			id = e.currentTarget.dataset['id'],
			that = this;
		//console.log(myplaceholder)
		var data = {};
		data.isComment = key;
		data.myPlaceholder = myplaceholder;
		if (!id){
			data.isId = '';
			data.myId = '';
		
		}else{
			data.isId = 1;
			data.myId = e.currentTarget.dataset['id'];
		}
		that.setData(data)
	},
	//点开表情包
	chosePic : function (e) {
		var key = e.currentTarget.dataset['key'],
			that = this,
			pic = that.data.pic;
		if (pic == key) {
			key = '';
		}
		that.setData({ pic: key });
	},
	//输入评论
	myInput : function (e) {
		var that = this,
			value = e.detail.value,
			data = {};
		value = value.replace(/ /ig, '');
		data.content = value;
		that.setData(data);
	},
	TextAreaBlur:function(){
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '评论内容不能为空',
		})
	},
	//发表评论
	mySave : function(e){
		var that = this,
		SaveNo = that.data.SaveNo,
			content = that.data.content || '';


		if (content.length ==0) {
			wx.showModal({
				title: '提示',
				showCancel: false,
				confirmColor: '#333333',
				content: '评论内容不能为空',
			})
			return
		}
		var url = 'source=chapterreviews',
			data = {};
		
		if (SaveNo==1){
			data.pid = that.data.id;
			data.cid = that.data.sectionid; 
			data.content = encodeURIComponent(content);
			var s= { url: url, data: data };
			app.request(s, function (inf) {
				console.log(inf)
				if (inf.errorCode == 0) {
					var data1 = inf.data;
					wx.showToast({
						title: data1.message,
						icon: 'success',
						duration: 2000
					});

					that.reset(1);
					that.setData({
						isComment:1,
						content:'',
						pic:''
					})
				}else{
					wx.showModal({
						title: '提示',
						showCancel: false,
						confirmColor: '#333333',
						content: inf.data.message,
					})
				}

			}, function (inf) {
				wx.showModal({
					title: '提示',
					showCancel: false,
					confirmColor: '#333333',
					content: inf.data.message,
				})
			})
		} else if (SaveNo == 2){
			data.op = "two_comment";
			data.contents = encodeURIComponent(content);
      var myplaceholder = e.currentTarget.dataset['myplaceholder']
      var a = myplaceholder.split("@")
      // console.log(a)
      data.u_name = a[1]
      // data.myplaceholder
			if(!that.data.myId){
				data.oid = that.data.id;
			}else{
				data.oid = that.data.id;
				// data.u_name = that.data.myId;
			}
			// console.log(data);
			//return;
			var s = { url: url, data: data };
			app.request(s, function (inf) {
				
				if (inf.errorCode == 0) {
					var data1 = inf.data;
					wx.showToast({
						title: data1.message,
						icon: 'success',
						duration: 2000
					});

					that.reset(1);
					that.setData({
						isComment: 1,
						content: '',
						pic: ''
					})
				} else {
					wx.showModal({
						title: '提示',
						showCancel: false,
						confirmColor: '#333333',
						content: inf.data.message,
					})
				}

			}, function (inf) {
				wx.showModal({
					title: '提示',
					showCancel: false,
					confirmColor: '#333333',
					content: inf.data.message,
				})
			})
		}
	},
	init: function (page) {
		var self = this;
		this.page = page;

		//配置本组件函数到页面
		page.choseFace = this.choseFace;
		page.chosePic = this.chosePic;
		page.myInput = this.myInput;
		page.myClose = this.myClose;
		page.mySave = this.mySave;
		page.TextAreaBlur = this.TextAreaBlur;
		page.myPraise = this.myPraise;
		// 配置本组件数据到页面
		this.setData(this.data);

		//console.log(page);
	},
};
module.exports = comment;