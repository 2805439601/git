// pages/introduce/common/footMenu.js
var app = getApp();
var myGoto = {
	data: {
		isShow: 1,//是否显示导航
	},

	page: null,

	setData: function (opt) {
		this.page && this.page.setData(opt);
	},
	//跳转导航页面
	oyGoTo: function (e) {
		var self = this;
		var key = e.currentTarget.dataset['key'];
		//console.log(key);
		if (key == 'usercenter') {
				key += '/' + key
		} else {
				key += '/index';
		}
		wx.reLaunch({
			url: '/pages/' + key
		})
		


	},
	//点击菜单弹窗
	myOpen:function(e){
		var that = this,
			isShow = that.data.isShow;
		isShow == 1 ? isShow = 2 : isShow = 1;
		that.setData({
			isShow: isShow
		})
	},



	init: function (page) {
		var self = this;
		this.page = page;

		//配置本组件函数到页面
		page.oyGoTo = this.oyGoTo;
		page.myOpen = this.myOpen;
		// 配置本组件数据到页面
		this.setData(this.data);

		//console.log(page);
	},
};
module.exports = myGoto;