// pages/introduce/index.js
var app = getApp();
var fontMenu = require('common/footMenu.js');
var footerMask = require('common/footerMask.js');
var WxParse = require('../../utils/wxParse/wxParse.js');
var {
  formatTime
} = require('../../utils/util.js');

var VM = {
  data: {
    show: false, //弹框
    hideBox: false, //遮罩层
    vods: [], //弹框内容 
    myTapFirst: 1,
    myTap: 1, //切换1介绍，2章节，3评论
    isVideo: 1, //是否播放视频
    page: 1, //第几页
    end: false, //是否加载中
    noend: true, //是否最后一页 true非最后一页
    isOpen: 2,
    isphone: true, //是否已经获取了手机号码
    syInfo: '', //系统信息，安卓还是iOS或PC

    //测试数据
    islogin: false,
    myIndex: 0,
    isAllList: true,
    listLen: 2,
    noStro: 0, //默认是没有记录
    myData: {
      collect: 1,
      level_name: "",
      show_isbuy: false,
      //章节列表
      section_list: [],
      allow_evaluate: true,
      //课程详情
      lesson: {
        // images: "/images/banner.jpg",
        // bookname: "社群运营高手5天速成班",
        // difficulty: "高级",
        // desc: "课程简介课程简介课程简介课程简介课程简介简介简介简介简介课程简介课程简介课程简介课程简介课程简介简介简介简介简介",
        // teacherphoto: "http://img4.imgtn.bdimg.com/it/u=2246980521,2027696365&fm=26&gp=0.jpg",
        // teacher: "王老师",
        // teacherdesc: "老师简介简介老师简介简介老师简介简介老师简介简介老师简介简介老师简介简介老师简介简介老师简介简介老师简介简介老师简介简介",
        // price: 0.01,
        // lesson_type: 1,
        // integral_rate: 1,
        // integral: 1,
        // validity: 99
      },
      //产品规格
      spec_list: [{
          id: 0,
          spec_day: -1,
          spec_price: 1.00,
          spec_name: "永久有效"
        },
        {
          id: 1,
          spec_day: 99,
          spec_price: 0.01,
          spec_name: "有效期99天"
        }
      ]
    },
    //评论
    count_evaluate: 2,
    list: []
  },
};

var urls = {
  'detail': 'source=lesson'
}
VM.nogo = function () {
  wx.showModal({
    title: '该章节未上架',
    content: '',
  })
}
//切换
VM.tap = function (e) {
  var that = this,
    key = e.currentTarget.dataset['key']; //第几个
  if (that.data.myTapFirst == 1) {
    that.getList1();
    that.setData({
      myTapFirst: 2
    })
  }
  that.setData({
    myTap: key
  });
}

//查看全部章节
VM.lookAtAll = function () {
  this.setData({
    isAllList: !this.data.isAllList
  })
}

VM.play = function (e) { //播放视频
  var mye = e;
  this.isLook(mye); //先判断是否有播放记录
}
VM.newPlay = function (mye) {
  if (!app.globalData.islogin) {
    this.setData({
      isOpen: 1
    })
    return
  }
  var that = this,
    index = mye.currentTarget.dataset['key'], //第几个
    sectionid = mye.currentTarget.dataset['sectionid'],
    data = {},
    myVideo = that.data.myVideo;
  if (that.data.myData.lesson.disable == '1') {
    wx.showModal({
      title: '系统提示',
      content: '该课程已被禁用',
    })
    return
  }

  var data1 = {
      id: that.data.id,
      op: 'display',
      sectionid: sectionid
    },
    url = urls['detail'],
    s = {
      url: url,
      data: data1
    };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      var sectiontype = that.data.myData.section_list[index].sectiontype;
      if (sectiontype == 1) {
        // console.log('播放视频')
        wx.navigateTo({
          url: '/pages/introduce/section?sectionid=' + sectionid + '&sectiontype=' + sectiontype + '&idx=' + index + '&id=' + that.data.id
        })

      } else if (sectiontype == 2) {
        that.setData({
          isVideo: 1
        });
        wx.navigateTo({
          url: 'title?sectionid=' + sectionid + '&idx=' + index + '&id=' + that.data.id
        })
      } else if (sectiontype == 5) {
        var live_status = that.data.myData.section_list[index].live_info.live_status;
        var live_info = that.data.myData.section_list[index].live_info;

        if (live_status == 1) {
          // 看录播
          if (live_info.vods == '') {
            wx.showModal({
              title: '暂无录播视频',
              content: '',
            })
          } else if (live_info.vods.length == 1) {
            var item = live_info.vods[0]
            var freeType = that.data.myData.section_list[index].is_free;

            wx.navigateTo({
              url: '/pages/vodDemo/vodDemo?free=' + freeType + '&item=' + JSON.stringify(item)
            })
          } else {
            that.setData({
              vods: live_info.vods,
              hideBox: true,
              show: true,
            })
          }

        } else if (live_status == 2 || live_status == 3) {
          // 看直播
          var live = that.data.myData.section_list[index].live_info.live
          wx.navigateTo({
            url: '../videodemo/videodemo?item=' + JSON.stringify(live),
          })
        } else {
          // 未开始
          wx.showModal({
            title: '直播未开始',
            content: '',
            showCancel: false
          })
        }
      } else {
        // data.isVideo = 3;
        // data.myAudio = that.data.myData.section_list[index].videourl;
        wx.navigateTo({
          url: '/pages/introduce/section?sectiontype=' + sectiontype + '&idx=' + index + '&id=' + that.data.id + '&sectionid=' + sectionid
        })
        // console.log('播放音频')
      }
      data.myIndex = index;
      that.setData(data);

    } else {
      if (that.data.syInfo == 'ios') {
        that.goConfirm();
        return
      }
      wx.showModal({
        title: '提示',
        confirmColor: '#333333',
        content: that.data.syInfo == 'ios' ? '请先报名后再学习！立即前往！' : inf.data.message + '立即前往!',
        confirmText: that.data.syInfo == 'ios' ? '立即报名' : '立即购买',
        success(res) {
          if (res.confirm) {
            that.goConfirm()
          }
        }
      })
    }
  }, function (inf) {
    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '数据加载失败',
    })
  })
  /*
    if (myVideo==''){
      data.isVideo=2;
    }
    
    data.myIndex = index;
    data.myVideo = that.data.myData.section_list[index].videourl;
    that.setData(data);
  */
}
// 关闭弹框
VM.vclose = function () {
  var that = this
  that.setData({
    show: false,
    vods: [],
    hideBox: false
  })
}
// 去录播
VM.allgo = function (e) {
  var that = this
  var item = e.currentTarget.dataset.item
  wx.navigateTo({
    url: '/pages/vodDemo/vodDemo?item=' + JSON.stringify(item)
  })
}
VM.pause = function (e) {
  // console.log(e)
}
VM.videoErrorCallback = function (e) {
  // console.log('视频错误信息:')
  // console.log(e.detail.errMsg)
  wx.showModal({
    title: '提示',
    showCancel: false,
    confirmColor: '#333333',
    content: '视频播放失败',
  })

}
VM.AudioErrorCallback = function (e) {
  // console.log('音频错误信息:')
  // console.log(e.detail.errMsg)
  wx.showModal({
    title: '提示',
    showCancel: false,
    confirmColor: '#333333',
    content: '音频播放失败',
  })

}
// 播放视频事件
VM.myTime = function (e) {

};
//重新加载
VM.reset = function () {
  var that = this;
  that.setData({
    page: 1,
    end: false,
    noend: true,
    list: []
  });
  that.getList1()
}
//加载评论
VM.getList1 = function () {
  var that = this,
    id = that.data.id,
    page = that.data.page,
    myEnd = that.data.end;
  if (myEnd || !that.data.noend) {
    return
  }; //判断是否在加载中或者已经到最后一个
  that.setData({
    end: true
  });
  var data = {
      id: id,
      op: 'ajaxgetlist',
      page: page
    },
    url = urls['detail'],
    s = {
      url: url,
      data: data
    };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      var list = that.data.list || [];
      inf.data.evaluate_list.forEach(function (o, i) {
        if (o.grade == '好评') {
          o.gradeImg = 'h';
        } else if (o.grade == '中评') {
          o.gradeImg = 'z';
        }
        if (o.grade == '差评') {
          o.gradeImg = 'c';
        }
        o.content = o.content
        list.push(o);

      })
      page++;
      if (inf.data.pageCount < page) {
        that.setData({
          list: list,
          noend: false,
          page: page,
          end: false

        });
      } else {
        that.setData({
          list: list,
          page: page,
          end: false

        });
      }
    } else {

      that.setData({
        end: false
      });
    }


  }, function (inf) {
    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '数据加载失败',
    })
    that.setData({
      end: false
    });

  })
}
VM.getList = function (e) {
  var that = this;

};

VM.getPhoneNumber = function (e) {
  var that = this;
  if (e.detail.errMsg == "getPhoneNumber:ok") {
    wx.setStorageSync('isphone', true);
    app.myGetPhoneNumber(function () {
      that.setData({
        isphone: true
      })
    }, e.detail);
  } else {
    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '你已拒绝授权',
    })
    that.setData({
      isphone: true
    })
  }
}

//获取用户信息
VM.onLoad = function (query) {
  // 登录
  var that = this;
  app.checkToken()
  fontMenu.init(that);
  footerMask.init(that);
  if (query.id) {
    that.setData({
      query: query,
      islogin: app.globalData.islogin,
      id: query.id
    })
  } else {
    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '页面参数缺失',
    })
  }
  that.setData({
    isProduce: 2, //产品弹窗
    isFooterMask: 2 //底部弹窗
  });
  var data = {
      id: that.data.id,
      op: 'display'
    },
    url = urls['detail'],
    s = {
      url: url,
      data: data
    };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      if (!inf.data.lesson.teacherdes) {
        inf.data.lesson.teacherdes = '';
      }
      WxParse.wxParse('teacherdes1', 'html', inf.data.lesson.teacherdes, that, 5);
      WxParse.wxParse('descript1', 'html', inf.data.lesson.descript, that, 5);
      that.setData({
        myData: inf.data
      })
      that.reset();
    } else {
      wx.showModal({
        title: '系统提示',
        content: inf.data.message,
        showCancel: false,
        success(res) {
          if (res.confirm) {
            wx.navigateBack({})
          }
        }
      })
    }
  }, function (inf) {
    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '数据加载失败',
    })
  })

  //格式转换
  let newlist = this.filter(this.data.list);
  this.setData({
    list: newlist
  })

  var syInfo = app.sysInfo(); //判断iOS还是安卓
  that.setData({
    syInfo: syInfo
  })


};

//判断是否已经含有观看过是视频
VM.isLook = function (mye) {
  var that = this;
  var query = that.data.query;
  wx.getStorage({
    key: 'isLook',
    success(res) {
      res.data.forEach((item, index) => {
        if (query.id == item.id) { //同一课程同一章
          var diji = parseInt(item.idx) + 1;
          if (item.idx == mye.currentTarget.dataset['key']) {
            that.newPlay(mye);
            return;
          }
          that.setData({
            noStro: 1
          });
          wx.showModal({
            title: '温馨提示',
            content: '检测到您上次观看到本课程的第' + diji + '节，是否继续观看',
            success(rre) {
              if (rre.confirm) {
                // console.log('用户点击确定')
                wx.navigateTo({
                  url: '/pages/introduce/section?sectionid=' + item.sectionid + '&sectiontype=' + item.sectiontype + '&idx=' + item.idx + '&id=' + item.id
                })
                //跳转
              } else if (rre.cancel) {

                that.newPlay(mye);
              }
              return
            }
          })
        } else {
          if (that.data.noStro == 0 && index == res.data.length - 1) that.newPlay(mye)
        }
      })
    },
    fail(err) {
      that.newPlay(mye); //
    }
  })

};
//时间格式
VM.filter = function (list) {
  let that = this;
  let newList = list.map(item => {
    item.newTime = formatTime(item.addtime, 'y-m-d h:i:s');
    return item;
  });
  return newList;
}

//未购买课程
VM.notPurchased = function () {
  wx.showToast({
    title: "请先购买课程",
    icon: "none"
  })

}

VM.onReady = function () {

};
//下拉刷新
VM.onPullDownRefresh = function () {
  var that = this;
  that.setData({
    isProduce: 2, //产品弹窗
    isFooterMask: 2 //底部弹窗
  });
  var data = {
      id: that.data.id,
      op: 'display'
    },
    url = urls['detail'],
    s = {
      url: url,
      data: data
    };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      if (!inf.data.lesson.teacherdes) {
        inf.data.lesson.teacherdes = '';
      }
      WxParse.wxParse('teacherdes1', 'html', inf.data.lesson.teacherdes, that, 5);
      WxParse.wxParse('descript1', 'html', inf.data.lesson.descript, that, 5);
      that.setData({
        myData: inf.data
      })
      that.reset();
    }
  }, function (inf) {
    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '数据加载失败',
    })
  })
}
VM.onShow = function () {
  var that = this;
  // that.setData({
  // 	isProduce: 2,//产品弹窗
  // 	isFooterMask: 2//底部弹窗
  // });
  // var data = { id: that.data.id, op: 'display' },
  // 	url = urls['detail'],
  // 	s = { url: url, data: data };
  // app.request(s, function (inf) {
  // 	if (inf.errorCode == 0) {
  // 		if (!inf.data.lesson.teacherdes){
  // 			inf.data.lesson.teacherdes = '';
  // 		}
  // 		WxParse.wxParse('teacherdes1', 'html', inf.data.lesson.teacherdes, that, 5);
  // 		WxParse.wxParse('descript1', 'html', inf.data.lesson.descript, that, 5);
  // 		that.setData({
  // 			myData: inf.data
  // 		})
  // 		that.reset();
  // 	}else{
  //     wx.showModal({
  //       title: '系统提示',
  //       content: inf.data.message,
  //       showCancel:false,
  //       success(res){
  //         if(res.confirm){
  //           wx.navigateBack({})
  //         }
  //       }
  //     })
  //   }
  // }, function (inf) {
  // 	wx.showModal({
  // 		title: '提示',
  // 		showCancel: false,
  // 		confirmColor: '#333333',
  // 		content: '数据加载失败',
  // 	})
  // }) 
};
VM.onReachBottom = function () {
  var that = this;
  if (that.data.myTap == 3) {
    that.getList(); //请求数据
  }

};
VM.onShareAppMessage = function (res) {
  var that = this
  if (res.from === 'button') {
    // 来自页面内转发按钮
    // console.log(res.target)
  }
  return {
    title: that.data.myData.title,
    // path: '/pages/index/index'
  }
};
Page(VM);