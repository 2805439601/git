// pages/introduce/title.js
var app = getApp();
var footerMask = require('common/comment.js');
var WxParse = require('../../utils/wxParse/wxParse.js');
var VM = {
	data: {
		isUp: 1,
		page: 1,//第几页
		end: false,//是否加载中
		noend: true,//是否最后一页 true非最后一页
		myIndex: '',
		SaveNo: 1,
    loadingHidden: true,
    toView: '',
    timestamp0: 0,
    timestamp1: 0,
    myData:{}
	},
};

var urls = {
	'detail': 'source=lesson',
	'chapterreviews': 'source=chapterreviews',
  'time': 'source=record'
}

VM.jumpTo = function () {
  // 获取标签元素上自定义的 data-opt 属性的值

  this.setData({
    toView: 'dddd'
  })
}
//取消
VM.myColse = function (e) {
	var that = this,
		key = e.currentTarget.dataset['key'];
	if (key == 1) {
		wx.navigateBack({
			delta: 1
		})
	} else {
		that.setData({
			isUp: 1
		})
	}

};
//重新加载
VM.reset = function (isFirst) {
	var that = this;
	that.setData({
		page: 1,//第几页
		end: false,//是否加载中
		noend: true,//是否最后一页 true非最后一页
		list: []
	})
	that.getList(isFirst);
}
//获取评论
VM.getList = function (isFirst) {
	var that = this,
		id = that.data.id,
		sectionid = that.data.sectionid,
		page = that.data.page,
		myEnd = that.data.end;
	if (myEnd || !that.data.noend) { return };//判断是否在加载中或者已经到最后一个
	that.setData({
		end: true
	});
	var data = { cid: sectionid, pid: id, op: 'demo', page: page },
		url = urls['chapterreviews'],
		s = { url: url, data: data };
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			var list = that.data.list || [];
			inf.data.list.forEach(function (o) {
				o.content = decodeURIComponent(o.content)
				o.comment.forEach(function (P, Index) {
					P.contents1 = decodeURIComponent(P.contents)
				})
				list.push(o)
			})
			page++;
			if (inf.data.pageCount < page) {
				that.setData({
					list: list,
					noend: false,
					page: page,
					end: false

				});
			} else {
				that.setData({
					list: list,
					page: page,
					end: false

				});
			}
		} else {

			if (inf.data.message == "暂无评论！") {
				that.setData({
					noTitle: inf.data.message
				});
			} else {
				wx.showModal({
					title: '提示',
					showCancel: false,
					confirmColor: '#333333',
					content: inf.data.message,
				})
			}
			that.setData({
				end: false
			});
		}


	}, function (inf) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '数据加载失败',
		})
		that.setData({
			end: false
		});

	})
}


//获取用户信息
VM.onLoad = function (query) {
	var that = this;
	footerMask.init(that);
  var timestamp = Date.parse(new Date());
  var timestamp0 = timestamp / 1000;
	if (query.id && query.sectionid) {
    setTimeout(function () {
      // console.log(966555)
      // that.setData({
      //   toView: 'dddd',
      // })
      that.jumpTo()
    }, 1000)
		that.setData(query);
    that.setData({
      sectionid: query.sectionid,
      id: query.id
    })
		var data = { id: query.id, sectionid: query.sectionid, op: 'display' },
			url = urls['detail'],
			s = { url: url, data: data };
		app.request(s, function (inf) {
			//console.log(inf)
			if (inf.errorCode == 0) {
        that.setData({
          myData : inf.data
        })
				// var article = inf.data.section_list[query.idx].content;
        var article = inf.data.section_list[query.idx].content.replace(/\width="484px"/gi, 'width="284px" ');
				console.log(article)
				WxParse.wxParse('article1', 'html', article, that, 5);
				that.setData(inf.data)
			} else {
				wx.showModal({
					title: '提示',
					showCancel: false,
					confirmColor: '#333333',
					content: inf.data.message,
					success: function (res) {
						
					}
				})
			}
		}, function (inf) {

		})
	} else {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '页面参数缺失',
		})
	}

}
//下拉刷新
VM.onPullDownRefresh = function () {
  var that = this;
  footerMask.init(that);
  var timestamp = Date.parse(new Date());
  var timestamp0 = timestamp / 1000;
  if (that.data.id && that.data.sectionid) {
    setTimeout(function () {
      // console.log(966555)
      // that.setData({
      //   toView: 'dddd',
      // })
      that.jumpTo()
    }, 1000)
    // that.setData(query);
    // that.setData({
    //   sectionid: query.sectionid,
    //   id: query.id
    // })
    var data = { id: that.data.id, sectionid: that.data.sectionid, op: 'display' },
      url = urls['detail'],
      s = { url: url, data: data };
    app.request(s, function (inf) {
      //console.log(inf)
      if (inf.errorCode == 0) {
        // var article = inf.data.section_list[query.idx].content;
        var article = inf.data.section_list[that.data.idx].content.replace(/\width="484px"/gi, 'width="284px" ');
        // console.log(article)
        WxParse.wxParse('article1', 'html', article, that, 5);
        that.setData(inf.data)
      } else {
        wx.showModal({
          title: '提示',
          showCancel: false,
          confirmColor: '#333333',
          content: inf.data.message,
          success: function (res) {

          }
        })
      }
    }, function (inf) {

    })
  } else {
    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '页面参数缺失',
    })
  }
}
VM.onHide = function (e) {
  var that = this
  var timestamp = Date.parse(new Date());
  var timestamp1 = timestamp / 1000;
  var time = timestamp1 - that.data.timestamp0
  // console.log(time)

  var data = {}
  var data1 = { lessonid: that.data.id, sectionid: that.data.sectionid, currentTime: time },
    url = urls['time'],
    s = { url: url, data: data1 };
  app.request(s, function (inf) {

  })

}
VM.onUnload = function (e) {
  var that = this
  var timestamp = Date.parse(new Date());
  var timestamp1 = timestamp / 1000;
  var time = timestamp1 - that.data.timestamp0
  // console.log(time)

  var data = {}
  var data1 = { lessonid: that.data.id, sectionid: that.data.sectionid, currentTime: time },
    url = urls['time'],
    s = { url: url, data: data1 };
  app.request(s, function (inf) {

  })
}
VM.play = function (e) {
  var that = this
  var index = e.currentTarget.dataset['index']//第几个
  var sectionid = e.currentTarget.dataset['sectionid']
  var sectiontype = e.currentTarget.dataset['sectiontype']
  var is_show = e.currentTarget.dataset['is_show']
  var need_buy = e.currentTarget.dataset['need_buy']

  if (is_show == '0') {
    wx.showModal({
      title: '该章节未上架',
      content: '',
    })
    return
  }
  if (need_buy == '1') {
    wx.showModal({
      title: '提示',
      confirmColor: '#333333',
      content: '请先购买',
      confirmText: '立即前往',
      success(res) {
        if (res.confirm) {
          // wx.navigateBack({})
          
          // 跳转下单页或者我的订单页面
          var spec_id = 0
          for (var i = 0; i < that.data.myData.spec_list.length; i++) {
            if (that.data.myData.lesson.price == that.data.myData.spec_list[i].spec_price) {
              spec_id = that.data.myData.spec_list[i].spec_id
            }
          }
          var data = { id: that.data.id, spec_id: spec_id },
            url = 'source=confirm',
            s = { url: url, data: data };
          app.request(s, function (inf) {
            if (inf.errorCode == 0) {
              that.setData({ isProduce: 2 });
              wx.navigateTo({
                url: '/pages/introduce/confirm?id=' + that.data.id + '&spec_id=' + spec_id
              })
            } else {
              wx.showModal({
                title: '提示',
                confirmColor: '#333333',
                content: inf.data.message,
                success: function (res) {
                  if (res.confirm) {
                    if (inf.data.message == '您还有该课程未付款订单！') {
                      wx.reLaunch({
                        url: '/pages/myOrder/index'
                      })
                    }
                  } else if (res.cancel) {
                    /*wx.reLaunch({
                      url: '/pages/myCurse/index'
                    })*/
                  }
                }
              })
            }

          }, function (inf) {

          })


        }
      }
    })
    return
  }
  var data1 = { id: that.data.id, op: 'display', sectionid: sectionid },
    url = urls['detail'],
    s = { url: url, data: data1 };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      if (sectiontype == 1) {
        // console.log('播放视频')
        wx.redirectTo({
          url: '/pages/introduce/section?sectionid=' + sectionid + '&sectiontype=' + sectiontype + '&idx=' + index + '&id=' + that.data.id
        })

      } else if (sectiontype == 2) {
        that.setData({ isVideo: 1 });
        wx.redirectTo({
          url: 'title?sectionid=' + sectionid + '&idx=' + index + '&id=' + that.data.id
        })
      } else {
        // data.isVideo = 3;
        // data.myAudio = that.data.section_list[index].videourl;
        wx.redirectTo({
          url: '/pages/introduce/section?sectiontype=' + sectiontype + '&idx=' + index + '&id=' + that.data.id + '&sectionid=' + sectionid
        })
        // console.log('播放音频')
      }
    }else {
			wx.showModal({
				title: '提示',
				confirmColor: '#333333',
				content: inf.data.message + '立即前往!',
        confirmText: '立即购买',
				success(res) {
					if(res.confirm){
						that.goConfirm()
					}
				}
			})
		}
  })
  
}

//老王新增
VM.goConfirm = function(){
  var that = this
  var spec_id = 0
  // console.log(that.data);
  for (var i = 0; i < that.data.spec_list.length;i++){
    if (that.data.lesson.price == that.data.spec_list[i].spec_price){
      spec_id = that.data.spec_list[i].spec_id
    }
  }
    // spec_list =that.data.spec_list,
    // spec_id = spec_list[that.data.sizeIndex].spec_id;
  // console.log(newspec_id)
  // console.log(that.data)
  var data = { id: that.data.id, spec_id: spec_id },
    url = 'source=confirm',
    s = { url: url, data: data };

  //测试跳转
  // wx.navigateTo({
  //   url: '/pages/introduce/confirm?id=' + that.data.id + '&spec_id=' + spec_id
  // })

  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      that.setData({isProduce:2});
      wx.navigateTo({
        url: '/pages/introduce/confirm?id=' + that.data.id + '&spec_id=' + spec_id
      })
    }else{
      wx.showModal({
        title: '提示',
        confirmColor: '#333333',
        content: inf.data.message,
        success: function (res) {
          if (res.confirm) {
            if (inf.data.message=='您还有该课程未付款订单！'){
              wx.reLaunch({
                url: '/pages/myCurse/index'
              })
            }
          } else if (res.cancel) {
            /*wx.reLaunch({
              url: '/pages/myCurse/index'
            })*/
          }
        }
      })
    }

  },function(inf){

  })
}

// 课件下载
VM.load = function () {

  this.setData({

    loadingHidden: false

  })

  let _that = this;

  wx.downloadFile({

    url: '',

    success: function (res) {

      var filePath = res.tempFilePath;

      // console.log(res)

      //页面显示加载动画

      wx.openDocument({

        filePath: filePath,

        success: function (res) {

          _that.setData({

            loadingHidden: true

          })

          // console.log('打开文档成功')

        }

      })

    }

  })

}



VM.onReady = function () {

};

VM.onShow = function () {
	var that = this;
	that.reset(1);

};
VM.onReachBottom = function () {
	var that = this;
	that.getList();//请求数据
};

VM.onShareAppMessage = function () {

};
Page(VM);