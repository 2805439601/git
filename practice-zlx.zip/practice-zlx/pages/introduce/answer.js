// pages/introduce/answer.js
var app = getApp();
var fontMenu = require('common/footMenu.js');
var footerMask = require('common/footerMask.js');
var VM = {
	data: {
		page: 1,//第几页
		end: false,//是否加载中
		noend: true,//是否最后一页 true非最后一页
	},
};

var urls = {
	'detail': 'source=lesson'
}


VM.getList = function(){
	var that = this,
		id = that.data.id,
		page = that.data.page,
		myEnd = that.data.end;
	if (myEnd || !that.data.noend) { return };//判断是否在加载中或者已经到最后一个
	that.setData({
		end: true
	});
	var data = { id: id, op: 'ajaxgetlist',page:page },
		url = urls['detail'],
		s = { url: url, data: data };
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			var list = that.data.list || [];
			inf.data.evaluate_list.forEach(function (o, i) {
				if(o.grade=='好评'){
					o.gradeImg = 'h';
				} else if (o.grade == '中评'){
					o.gradeImg = 'z';
				} if (o.grade == '差评') {
					o.gradeImg = 'c';
				}
				list.push(o);

			})
			page++;
			if (inf.data.pageCount < page) {
				that.setData({
					list: list,
					noend: false,
					page: page,
					end: false

				});
			} else {
				that.setData({
					list: list,
					page: page,
					end: false

				});
			}
		} else {
			
			that.setData({
				end: false
			});
		}


	}, function (inf) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '数据加载失败',
		})
		that.setData({			
			end: false
		});

	})
}



//获取用户信息
VM.onLoad = function (query) {
	var that = this;
	fontMenu.init(that);
	footerMask.init(that);
	if (query.id) {
		that.setData({
			id: query.id
		})
		
	} else {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '页面参数缺失',
		})
	}
};

VM.onReady = function () {

};

VM.onShow = function () {
	var that = this;
	that.setData({
		page: 1,
		end: false,
		noend: true,
		list: [],
		isProduce: 2,//产品弹窗
		isFooterMask: 2//底部弹窗
	});
	var data = { id: that.data.id, op: 'display' },
		url = urls['detail'],
		s = { url: url, data: data };
	app.request(s, function (inf) {

		//console.log(inf)
		if (inf.errorCode == 0) {

			that.setData({
				myData: inf.data
			})
			that.getList();
		}

	}, function (inf) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '数据加载失败',
		})
	})
};
VM.onReachBottom = function () {
	var that = this;
	that.getList();//请求数据
};
VM.onShareAppMessage = function () {

};
Page(VM);