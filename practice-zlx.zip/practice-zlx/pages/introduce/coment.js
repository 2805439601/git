// pages/introduce/coment.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {
		content:'',
		index:''
	},
};
var urls = {
	'evaluate': 'source=evaluate'
}
VM.myInput = function(e){
	var self = this, value = e.detail.value;
	if (value != '') {
		value = value.replace(/ /ig, '')
		self.setData({
			content: value,

		})
	} else {
		self.setData({
			content: ''
		})
	}
}
//提交评价
VM.save = function(){
	var that = this,
		grade = that.data.index,
		content = that.data.content;
	if (grade==''){
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '请选择评分',
		})
		return;
	}
	if (content == '') {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '请输入评论内容',
		})
		return;
	}
	var data = { submit: '1', lessonid: that.data.lessonid };
	data.grade = grade;
	data.content = content;
	
	if (that.data.orderid=='free'){
		data.orderid = 0;
		data.op = 'freeorder';
	}else{
		data.orderid = that.data.orderid;
	
	}
	var url = urls['evaluate'],
		s = { url: url, data: data };
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			wx.showToast({
				title: '评价成功',
				icon: 'success',
				duration: 2000,
				success:function(){
					wx.navigateBack({
						delta: 1
					})
				}
			})
		}
	}, function (inf) {

	})
}
//选择评价
VM.choseOc = function(e){
	var that = this,
		key = e.currentTarget.dataset['key'];
	if (that.data.index==key){
		return;
	}
	that.setData({index:key})
}







//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var that = this;
	fonter.init(that);
	if (query.orderid && query.lessonid){
		that.setData(query)
		//console.log(that.data.orderid)
		var data = {lessonid: query.lessonid};
		if (query.orderid == 'free' || query.orderid == '0'){
			data.op = 'freeorder';
		}else{
			data.orderid = query.orderid;
		}
		var url = urls['evaluate'],
			s = { url: url, data: data };
		app.request(s, function (inf) {
			//console.log(inf)
			if (inf.errorCode == 0) {
				that.setData({myData:inf.data})
			}
		}, function (inf) {

		})
	}
};

VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};

VM.onShareAppMessage = function () {

};
Page(VM);
