// pages/introduce/thComment.js
var app = getApp();
var footerMask = require('common/comment.js');
var VM = {
	data: {
		page: 1,//第几页
		end: false,//是否加载中
		noend: true,//是否最后一页 true非最后一页
		SaveNo: 2,
		//测试数据
		images: "",
		username: "",
		content1: "",
		createtime: '',
		like_num: 1,
		st_1: 1,
		list:[
			// {
			// 	id: 0,
			// 	imagess: "http://img4.imgtn.bdimg.com/it/u=2246980521,2027696365&fm=26&gp=0.jpg",
			// 	usernames: "老王",
			// 	contents: "老好了老弟老好了老弟老好了老弟老好了老弟老好了老弟",
			// 	grade: "好评",
			// 	createtimes: 1565851206995,
			// 	st: 1,
			// 	st_2: 1,
			// 	likes_num: 1,
			// },
			// {
			// 	id: 1,
			// 	imagess: "http://img4.imgtn.bdimg.com/it/u=2246980521,2027696365&fm=26&gp=0.jpg",
			// 	usernames: "老王",
			// 	contents: "老好了老弟老好了老弟老好了老弟老好了老弟老好了老弟老好了老弟老好了老弟",
			// 	grade: "好评",
			// 	createtimes: 1565851206995,
			// 	st: 0,
			// 	likes_num: 0
			// }
		]
	},
};


var urls = {
	'chapterreviews': 'source=chapterreviews'
}

//重新加载
VM.reset = function (isFirst) {
	var that = this;
	that.setData({
		page: 1,//第几页
		end: false,//是否加载中
		noend: true,//是否最后一页 true非最后一页
		list: []
	})
	that.getList(isFirst);
}
//获取评论
VM.getList = function (isFirst) {
	//console.log(343);
	var that = this,
		id = that.data.id,
		page = that.data.page,
		myEnd = that.data.end;
	if (myEnd || !that.data.noend) { return };//判断是否在加载中或者已经到最后一个
	that.setData({
		end: true
	});
	var data = { id: id, op: 'demos', page_2: page },
		url = urls['chapterreviews'],
		s = { url: url, data: data };
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			var list = that.data.list || [];
			page++;
			if (page == 2 && inf.data.list.length>0){
				var data2 ={};
				data2.id=inf.data.list[0].id;
				data2.c_num = inf.data.list[0].c_num;
				data2.cid = inf.data.list[0].cid;
				data2.content1 = decodeURIComponent(inf.data.list[0].content);
				data2.createtime = inf.data.list[0].createtime;
				data2.d_num = inf.data.list[0].d_num;
				data2.images = inf.data.list[0].images;
				data2.like_num = inf.data.list[0].like_num;
				data2.pid = inf.data.list[0].pid;
				data2.uid = inf.data.list[0].uid;
				data2.st_1 = inf.data.list[0].st_1;
				data2.username = inf.
				data.list[0].username;
				that.setData(data2);
			}
			inf.data.list[0].data.forEach(function(o){
				o.contents=decodeURIComponent(o.contents);
				list.push(o);
			})
			if (inf.data.list[0].d_num < page) {
				that.setData({
					list: list,
					noend: false,
					page: page,
					end: false

				});
			} else {
				that.setData({
					list: list,
					page: page,
					end: false

				});
			}
		} else {
			wx.showModal({
				title: '提示',
				showCancel: false,
				confirmColor: '#333333',
				content: inf.data.message,
			})
			that.setData({
				end: false
			});
		}


	}, function (inf) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '数据加载失败',
		})
		that.setData({
			end: false
		});

	})
}
//获取用户信息
VM.onLoad = function (query) {
	var that = this;
	wx.setNavigationBarTitle({
		title: "评论"
	})
	footerMask.init(that);
	if (query.id) {
		that.setData(query);
	} else {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '页面参数缺失',
		})
	}
};

VM.onReady = function () {

};

VM.onShow = function () {
	var that = this;
	that.reset(1);
};

VM.onShareAppMessage = function () {

};
Page(VM);