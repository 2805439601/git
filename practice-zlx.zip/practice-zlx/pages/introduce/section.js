// pages/introduce/section.js
var app = getApp();
var fontMenu = require('common/footMenu.js');
var footerMask = require('common/footerMask.js');
var footerMasks = require('common/comment.js');
var VM = {
  data: {
    isFrist: 1,
    myAudio: '',
    page: 1, //第几页
    end: false, //是否加载中
    noend: true, //是否最后一页 true非最后一页
    myIndex: '',
    SaveNo: 1,
    controls: true,
    //测试数据
    isVideo: 0,
    myVideo: '',
    isneedbuy: '',
    isOpen: 2,
    query: {},
    isqcode: false,
    loadingHidden: true,
    toView: '',
    timestamp0: 0,
    timestamp1: 0,
    xx: 0,
    iscode: 0,
    startPlayTime:0,//开始播放时间，单位/秒
    nowTimeStamp:0,//现在时间
    nowProgress:0,//当前播放到的进度
    syInfo:'',//判断当前设备iOS还是安卓
    hideBox:false,//遮罩层
    tan1:false,//ios弹框
    myData: {

    },
    list: [
      // {
      // 	id: 0,
      // 	images: "",
      // 	username: "",
      // 	content: "",
      // 	grade: "",
      // 	createtime: 1565851206995,
      // 	st: 1,
      // 	like_num: 1,
      // },
      // {
      // 	id: 1,
      // 	images: "",
      // 	username: "",
      // 	content: "",
      // 	grade: "",
      // 	createtime: 1565851206995,
      // 	st: 0,
      // 	like_num: 0
      // },
      // {
      // 	id: 2,
      // 	images: "",
      // 	username: "",
      // 	content: "",
      // 	grade: "",
      // 	createtime: 1565851206995,
      // 	st: 0,
      // 	like_num: 0
      // }
    ],
    RateArray: [
      {
        value: 0.5,
        name: '0.5x'
      },
      {
        value: 0.8,
        name: '0.8x'
      },
      {
        value: 1.0,
        name: '1.0x'
      },
      {
        value: 1.25,
        name: '1.25x'
      },
      {
        value: 1.5,
        name: '1.5x'
      }
    ],
    RateIndex: 2,
    scrollType:0,
    loadType:0,
    wxToken: null,
    cpUrl: null,
  },
};
VM.jumpTo = function () {
  // 获取标签元素上自定义的 data-opt 属性的值

  this.setData({
    toView: 'dddd'
  })
}

var urls = {
  'detail': 'source=lesson',
  'chapterreviews': 'source=chapterreviews',
  'load': 'source=lesson&id=78&op=getPPT',
  'time': 'source=record',
  'check':'source=token&op=check'
}
// VM.playno = function(){
//   var that = this
//   wx.showModal({
//     title: '该章节未上架',
//     content: '',
//   })
// }
// VM.play = function(e){//播放视频
// 	var that = this,
// 		index = e.currentTarget.dataset['key'],//第几个
// 		sectionid = e.currentTarget.dataset['sectionid'],
// 		data = {},
// 		myVideo = that.data.myVideo;

//  
// 	var data1 = { id: that.data.id, op: 'display', sectionid: sectionid },
// 		url = urls['detail'],
// 		s = { url: url, data: data1 };
// 	app.request(s, function (inf) {

// 		// console.log(inf)
// 		if (inf.errorCode == 0) {
// 			//console.log(index)
// 			var sectiontype = that.data.myData.section_list[index].sectiontype;
// 			if (sectiontype==1){
// 				data.isVideo = 2;
// 				data.myVideo = that.data.myData.section_list[index].videourl;


// 			} else if (sectiontype == 2){
// 				that.setData({ isVideo: 1 });
// 					wx.navigateTo({
// 						url: 'title?sectionid=' + sectionid + '&idx=' + index + '&id=' + that.data.id
// 					})
// 			}else{


// 				data.isVideo =3;
// 				data.myAudio = that.data.myData.section_list[index].videourl;

// 				// console.log('播放音频')
// 			}
// 			data.myIndex = index;
// 			that.setData(data);

// 		}else {
// 			wx.showModal({
// 				title: '提示',
// 				showCancel: false,
// 				confirmColor: '#333333',
// 				content: inf.data.message,
// 			})
// 		}
// 	}, function (inf) {
// 		wx.showModal({
// 			title: '提示',
// 			showCancel: false,
// 			confirmColor: '#333333',
// 			content: '数据加载失败',
// 		})
// 	})
// 	/*if (myVideo==''){
// 		data.isVideo=2;
// 	}

// 	data.myIndex = index;
// 	data.myVideo = that.data.myData.section_list[index].videourl;
// 	that.setData(data);*/
// }
VM.pause = function (e) {
  // console.log(e)
}
VM.videoErrorCallback = function (e) {
  // console.log('视频错误信息:')
  // console.log(e.detail.errMsg)
  wx.showModal({
    title: '提示',
    showCancel: false,
    confirmColor: ' #333333',
    content: '视频播放失败',
  })

}
VM.AudioErrorCallback = function (e) {
  // console.log('音频错误信息:')
  // console.log(e.detail.errMsg)
  wx.showModal({
    title: '提示',
    showCancel: false,
    confirmColor: '#333333',
    content: '音频播放失败',
  })

}
//跳转到一刷过小程序
VM.goto = function (){
  wx.navigateToMiniProgram({
    appId: 'wxda9be8fea6c488a1',
    //path: 'page/index/index',
    extraData: {
      foo: 'bar'
    },
    envVersion: 'release',
    success(res) {
      // 打开成功
    }
  })
}


// 点击播放视频事件
VM.playvideo = function () {
  var that = this
  if (that.data.isneedbuy == 1) {
    that.videoContext.seek(0)
    that.videoContext.pause();
    wx.showModal({
      title: '提示',
      confirmColor: '#333333',
      content: '请先购买',
      confirmText: '立即前往',
      success(res) {
        if (res.confirm) {
          // wx.navigateBack({})


          // 跳转下单页或者我的订单页面
          var spec_id = 0
          for (var i = 0; i < that.data.myData.spec_list.length; i++) {
            if (that.data.myData.lesson.price == that.data.myData.spec_list[i].spec_price) {
              spec_id = that.data.myData.spec_list[i].spec_id
            }
          }
          var data = { id: that.data.id, spec_id: spec_id },
            url = 'source=confirm',
            s = { url: url, data: data };
          app.request(s, function (inf) {
            if (inf.errorCode == 0) {
              that.setData({ isProduce: 2 });
              wx.navigateTo({
                url: '/pages/introduce/confirm?id=' + that.data.id + '&spec_id=' + spec_id
              })
            } else {
              wx.showModal({
                title: '提示',
                confirmColor: '#333333',
                content: inf.data.message,
                success: function (res) {
                  if (res.confirm) {
                    if (inf.data.message == '您还有该课程未付款订单！') {
                      wx.reLaunch({
                        url: '/pages/myOrder/index'
                      })
                    }
                  } else if (res.cancel) {
                    /*wx.reLaunch({
                      url: '/pages/myCurse/index'
                    })*/
                  }
                }
              })
            }

          }, function (inf) {

          })



        }
      }
    })
  }
}
//重新加载
VM.reset = function (isFirst) {
  var that = this;
  that.setData({
    page: 1, //第几页
    end: false, //是否加载中
    noend: true, //是否最后一页 true非最后一页
    list: []
  })
  that.getList(isFirst);
}
//获取评论
VM.getList = function (isFirst) {
  var that = this,
    id = that.data.query.id,
    sectionid = that.data.query.sectionid,
    page = that.data.page,
    myEnd = that.data.end;
  if (myEnd || !that.data.noend) {
    return
  }; //判断是否在加载中或者已经到最后一个
  that.setData({
    end: true
  });
  var data = {
      cid: sectionid,
      pid: id,
      op: 'demo',
      page: page
    },
    url = urls['chapterreviews'],
    s = {
      url: url,
      data: data
    };
  app.request(s, function (inf) {
    // console.log(inf)
    inf.errorCode = 1;
    inf.data.message = "暂无评论！"
    if (inf.errorCode == 0) {
      var list = that.data.list || [];
      inf.data.list.forEach(function (o) {
        o.content = decodeURIComponent(o.content)
        o.comment.forEach(function (P, Index) {
          P.contents1 = decodeURIComponent(P.contents)
        })
        list.push(o)
      })
      page++;
      if (inf.data.pageCount < page) {
        that.setData({
          list: list,
          noend: false,
          page: page,
          end: false
        });
      } else {
        that.setData({
          list: list,
          page: page,
          end: false

        });
      }
    } else {

      if (inf.data.message == "暂无评论！") {
        that.setData({
          noTitle: inf.data.message
        });
      } else {
        wx.showModal({
          title: '提示',
          showCancel: false,
          confirmColor: '#333333',
          content: inf.data.message,
        })
      }
      that.setData({
        end: false
      });
    }


  }, function (inf) {
    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '数据加载失败',
    })
    that.setData({
      end: false
    });

  })
}
VM.copyText= function (e) {
  console.log(e)
  wx.setClipboardData({
    data: this.data.pcUrl,
    success: function (res) {
      wx.getClipboardData({
        success: function (res) {
          wx.showToast({
            title: '复制成功'
          })
        }
      })
    }
  })
}
//获取用户信息
VM.onLoad = function (query) {
  var that = this;
  
  wx.getStorage({//获取本地缓存
    key: "token",
    success: function (res) {
      that.data.pcUrl = 'https://zlx.51cedu.com/1_video/video.php?op=' + res.data+'&pid=' + query.id + '&page=' + query.idx;

      console.log(query)
      console.log(that.data.pcUrl)

    },
  })

  wx.onMemoryWarning(function () {
    wx.showModal({
      title: '警告',
      content: '内存严重不足,建议关闭其它应用！',
    })
  })
  that.setData({
    query: query
  })
    that.isLook(query);//判断
    fontMenu.init(that);
    footerMask.init(that);
    var syInfo = app.sysInfo();//判断iOS还是安卓
    that.setData({
      syInfo: syInfo
    })
    var data = {
      id: that.data.query.id,
      op: 'display'
    },
      url = urls['detail'],
      s = {
        url: url,
        data: data
      };
    app.request(s, function (inf) {
      if (inf.errorCode == 0) {
        that.setData({
          xx: 1
        })
        var data = {};
        data.myData = inf.data;
        data.imgHp = app.globalData.appImg;
        if (that.data.query.sectiontype == 1) {
          data.isVideo = 2;
          data.myVideo = inf.data.section_list[that.data.query.idx].videourl;
          data.isneedbuy = inf.data.section_list[that.data.query.idx].need_buy;
        }
        if (that.data.query.sectiontype == 3) {
          data.isVideo = 3;
          data.myVideo = inf.data.section_list[that.data.query.idx].videourl;
          data.isneedbuy = inf.data.section_list[that.data.query.idx].isneedbuy;
        }
        that.setData(data)
      } else if (inf.errorCode == 1003) {
        console.log(33)
        app.getToken()

      } else {
        that.setData({
          iscode: 1
        })
      }

    }, function (inf) {
      wx.showModal({
        title: '提示',
        showCancel: false,
        confirmColor: '#333333',
        content: inf.data.message,
      })
    })

    //赋予默认排序
    wx.getStorage({
      key: 'sectionListType',
      success: function(res) {
        that.setData({
          "scrollType": res.data
        })
        
      },
    })
};
//判断是否已经含有观看过是视频
VM.isLook = function(query){
  var that = this;
  wx.getStorage({
    key: 'isLook',
    success(res) {
      res.data.forEach((item,index) => {
        if(query.id==item.id){//同一课程同一章
          if(query.idx==item.idx){//当前小节就是上次观看的小节
            that.setData({ startPlayTime: item.startPlayTime})
          }else{
            var diji = parseInt(item.idx)+1;
            // wx.showModal({
            //   title: '温馨提示',
            //   content: '检测到您上次观看到本课程的第'+diji+'章节，是否继续观看',
            //   success(rre) {
            //     if (rre.confirm) {
            //       // console.log('用户点击确定')
            //       wx.redirectTo({
            //         url: '/pages/introduce/section?sectionid=' + item.sectionid + '&sectiontype=' + item.sectiontype + '&idx=' + item.idx + '&id=' + item.id
            //       })
            //     } else if (rre.cancel) {
            //       // console.log('用户点击取消')//清除stroage
            //       var newstr = res.data;
            //       newstr.splice(index,1);
            //       wx.setStorage({
            //         key: "isLook",
            //         data: newstr
            //       })
            //     }
            //   }
            // })
          }
        }
      })
    }
  })
  
};
//设置身体stroage存储观看记录
VM.setStroage = function (query){
  var isLook = [];
  var nowProgress = this.data.nowProgress;
  if (nowProgress>0){
    wx.getStorage({
      key: 'isLook',
      success(res) {
        isLook = res.data;
        if (isLook){
          isLook.forEach((item, index) => {
            if (query.id == item.id) {
              isLook.splice(index, 1)
            }
          })
        }
        var newLook = { id: query.id, sectionid: query.sectionid, idx: query.idx, sectiontype: query.sectiontype, startPlayTime: nowProgress };
        isLook.push(newLook);
        wx.setStorage({
          key: "isLook",
          data: isLook
        })
      },
      fail(err){
        var newLook = { id: query.id, sectionid: query.sectionid, idx: query.idx, sectiontype: query.sectiontype, startPlayTime: nowProgress };
        isLook.push(newLook);
        wx.setStorage({
          key: "isLook",
          data: isLook
        })
      }
    })
  }
  
};
//播放进度变化时触发，event.detail = {currentTime, duration} 。触发频率 250ms 一次
VM.bindtimeupdate = function(e){
  var that = this;
  var nowtime = new Date();
  if (nowtime.getTime() - that.data.nowTimeStamp>2200){
    that.setData({
      nowTimeStamp: nowtime.getTime(),
      nowProgress:e.detail.currentTime
    })
    // console.log('刷新当前播放进度2222222222')
  }
  
};
//当播放到末尾时播放
VM.bindended = function(){
  this.setData({
    nowProgress:0
  })
  //应该在这里清除本条缓存记录，如果在页面关闭再清除的话，不知道是否观看过，还是只是进来没有观看
  wx.getStorage({
    key: 'isLook',
    success(res) {
      res.data.forEach((item, index) => {
        if (query.id == item.id) {//同一课程同一章
          if (query.idx == item.idx) {//当前小节就是上次观看的小节
            var newstr = res.data;
            newstr.splice(index, 1);
            wx.setStorage({
              key: "isLook",
              data: newstr
            })
          }
        }
      })
    }
  })
};
//下拉刷新
VM.onPullDownRefresh = function () {
  if (app.globalData.islogin) {
    console.log('刷新')
    var that = this;
    wx.showNavigationBarLoading() //在标题栏中显示加载
    wx.showLoading({
      title: '正在刷新',
      mask: true
    })
    var timestamp = Date.parse(new Date());
    var timestamp0 = timestamp / 1000;
    // console.log(timestamp0)
    that.setData({
      timestamp0: timestamp0
    })
    wx.getSystemInfo({
      success: function (res) {
        if (res.model.indexOf('iPhone 6') != -1) {
          that.setData({
            'isiPhone': 1
          })
        }
      }
    })
    footerMasks.init(that);
    if (that.data.id) {
      // console.log(query);
      // that.setData(query);

      // that.setData({
      //   sectionid: query.sectionid,
      //   id: query.id
      // })
      setTimeout(function () {
        // console.log(966555)
        // that.setData({
        //   toView: 'dddd',
        // })
        that.jumpTo()
      }, 1000)
      var data = {
          id: that.data.id,
          op: 'display'
        },
        url = urls['detail'],
        s = {
          url: url,
          data: data
        };
      app.request(s, function (inf) {
        if (inf.errorCode == 0) {
          wx.hideNavigationBarLoading() //完成停止加载
          wx.hideLoading()
          wx.stopPullDownRefresh() //停止下拉刷新
          that.setData({
            xx: 1
          })
          var data = {};
          data.myData = inf.data;
          data.imgHp = app.globalData.appImg;
          if (that.data.sectiontype == 1) {
            data.isVideo = 2;
            data.myVideo = inf.data.section_list[that.data.idx].videourl;
            data.isneedbuy = inf.data.section_list[that.data.idx].need_buy;
          }
          if (that.data.sectiontype == 3) {
            data.isVideo = 3;
            data.myVideo = inf.data.section_list[that.data.idx].videourl;
            data.isneedbuy = inf.data.section_list[that.data.idx].need_buy;
          }
          that.setData(data)
        }

      }, function (inf) {
        wx.showModal({
          title: '提示',
          showCancel: false,
          confirmColor: '#333333',
          content: inf.data.message,
        })
      })

    } else {
      wx.showModal({
        title: '提示',
        showCancel: false,
        confirmColor: '#333333',
        content: '页面参数缺失',
      })
    }
  }
}
VM.onHide = function (e) {
  this.setStroage(this.data.query);
  var that = this
  var timestamp = Date.parse(new Date());
  var timestamp1 = timestamp / 1000;
  var time = timestamp1 - that.data.timestamp0
  // console.log(time)

  var data = {}
  var data1 = {
      lessonid: that.data.id,
      sectionid: that.data.sectionid,
      currentTime: time
    },
    url = urls['time'],
    s = {
      url: url,
      data: data1
    };
  app.request(s, function (inf) {

  })
  this.data=null
}
VM.onUnload = function (e) {
  this.setStroage(this.data.query);
  var that = this;
  var timestamp = Date.parse(new Date());
  var timestamp1 = timestamp / 1000;
  var time = timestamp1 - that.data.timestamp0
  // console.log(time)

  var data = {}
  var data1 = {
      lessonid: that.data.id,
      sectionid: that.data.sectionid,
      currentTime: time
    },
    url = urls['time'],
    s = {
      url: url,
      data: data1
    };
  app.request(s, function (inf) {

  })
  this.data=null
}
VM.play = function (e) {
  var that = this
  var datas = {
  },
    urlss = urls['check'],
    ss = {
      url: urlss,
      data: datas
    };
  app.request(ss, function (inf) {
    if (inf.errorCode == 0){
      if (inf.data.result == 1) {//token没过期

      } else {//过期
        app.getToken()
        
      }
    }else{

    }
    that.setData({
      loadType: 1
    });
    setTimeout(function () {
      var data = {
        id: that.data.query.id,
        op: 'display'
      },
        url = urls['detail'],
        s = {
          url: url,
          data: data
        };
      app.request(s, function (inf) {
        if (inf.errorCode == 0) {
          var data = {};
          data.myData = inf.data;
          data.imgHp = app.globalData.appImg;
          if (that.data.query.sectiontype == 1) {
            data.isVideo = 2;
            data.myVideo = inf.data.section_list[that.data.query.idx].videourl;
            data.isneedbuy = inf.data.section_list[that.data.query.idx].need_buy;
          }
          if (that.data.query.sectiontype == 3) {
            data.isVideo = 3;
            data.myVideo = inf.data.section_list[that.data.query.idx].videourl;
            data.isneedbuy = inf.data.section_list[that.data.query.idx].isneedbuy;
          }
          that.setData(data)
          setTimeout(function () {
            var index = e.currentTarget.dataset['index'] //第几个
            var sectionid = e.currentTarget.dataset['sectionid']
            var sectiontype = e.currentTarget.dataset['sectiontype']
            var is_show = e.currentTarget.dataset['is_show']
            var need_buy = inf.data.section_list[index].need_buy
            if (is_show == '0') {
              wx.showModal({
                title: '该章节未上架',
                content: '',
              })
              return
            }
            if (need_buy == '1' && that.data.syInfo != 'ios') {
              wx.showModal({
                title: '提示',
                confirmColor: '#333333',
                content: that.data.syInfo == 'ios' ? '请先报名后再学习！立即前往！' : '请先购买',
                confirmText: '立即前往',
                success(res) {
                  if (res.confirm) {
                    // wx.navigateBack({})
                    // 跳转下单页或者我的订单页面
                    if (that.data.syInfo == 'ios') {
                      wx.showModal({
                        title: '提示',
                        content: '由于相关规范，iOS功能暂不可用',
                        showCancel: false
                      })
                      return
                    }
                    var spec_id = 0
                    for (var i = 0; i < that.data.myData.spec_list.length; i++) {
                      if (that.data.myData.lesson.price == that.data.myData.spec_list[i].spec_price) {
                        spec_id = that.data.myData.spec_list[i].spec_id
                      }
                    }
                    var data = { id: that.data.id, spec_id: spec_id },
                      url = 'source=confirm',
                      s = { url: url, data: data };
                    app.request(s, function (inf) {
                      if (inf.errorCode == 0) {
                        that.setData({ isProduce: 2 });
                        wx.navigateTo({
                          url: '/pages/introduce/confirm?id=' + that.data.id + '&spec_id=' + spec_id
                        })
                      } else {
                        wx.showModal({
                          title: '提示',
                          confirmColor: '#333333',
                          content: inf.data.message,
                          success: function (res) {
                            if (res.confirm) {
                              if (inf.data.message == '您还有该课程未付款订单！') {
                                wx.reLaunch({
                                  url: '/pages/myOrder/index'
                                })
                              }
                            } else if (res.cancel) {
                              /*wx.reLaunch({
                                url: '/pages/myCurse/index'
                              })*/
                            }
                          }
                        })
                      }

                    }, function (inf) {

                    })
                  }
                }
              })
              return
            } else if (need_buy == '1' && that.data.syInfo == 'ios') {
              //假如是ios用户
              that.setData({
                tan1: true,
                hideBox: true
              })
            } else {
              if (sectiontype == 1) {
                // console.log('播放视频')
                wx.redirectTo({
                  url: '/pages/introduce/section?sectionid=' + sectionid + '&sectiontype=' + sectiontype + '&idx=' + index + '&id=' + that.data.id
                })

              } else if (sectiontype == 2) {
                that.setData({
                  isVideo: 1
                });
                wx.redirectTo({
                  url: 'title?sectionid=' + sectionid + '&idx=' + index + '&id=' + that.data.id
                })
              } else {
                // data.isVideo = 3;
                // data.myAudio = that.data.myData.section_list[index].videourl;
                wx.redirectTo({
                  url: '/pages/introduce/section?sectiontype=' + sectiontype + '&idx=' + index + '&id=' + that.data.id + '&sectionid=' + sectionid
                })
                // console.log('播放音频')
              }
            }

          }, 200)
        }

      })
    }, 200)
    
  })
  
  
  
  
}
//取消ios弹框
VM.closetan1 = function(){
  var that = this
  that.setData({
    tan1: false,
    hideBox: false
  })
}
// 课件下载
VM.load = function () {
  let _that = this;
  var data = {}
  var data1 = {
    id: _that.data.sectionid
  }
  var url = urls['load']
  var s = {
    url: url,
    data: data1
  };
  app.request(s, function (inf) {
    if (inf.errorCode == '0') {
      if (inf.data.need_buy == '0') {
        if (inf.data.ppturl == "") {
          wx.showModal({
            title: '提示',
            content: inf.data.emptyMessage,
            success: function (res) {}
          })
          return
        }
        _that.setData({

          loadingHidden: false

        })
        wx.downloadFile({

          url: inf.data.ppturl,

          success: function (res) {

            var filePath = res.tempFilePath;

            // console.log(res)

            //页面显示加载动画

            wx.openDocument({

              filePath: filePath,

              success: function (res) {

                _that.setData({

                  loadingHidden: true

                })

                // console.log('打开文档成功')

              }

            })

          }

        })
      } else {

        wx.showModal({
          title: '提示',
          content: inf.data.emptyMessage,
          success: function (res) {}
        })

      }
    }

  })


}

VM.onReady = function () {
  var that = this;
  that.videoContext = wx.createVideoContext('myVideo');
};
VM.onReachBottom = function () {
  var that = this;
};
VM.onShow = function () {
  var that = this;
  setTimeout(() => {
    if (!app.globalData.islogin) {
      that.setData({
        isOpen: 1,
        isqcode: true
      })
      return
    }
    var timestamp = Date.parse(new Date());
    var timestamp0 = timestamp / 1000;
    // console.log(timestamp0)
    that.setData({
      timestamp0: timestamp0
    })

    wx.getSystemInfo({
      success: function (res) {
        if (res.model.indexOf('iPhone 6') != -1) {
          that.setData({
            'isiPhone': 1
          })
        }
      }
    })
    footerMasks.init(that);

    if (that.data.query.id) {
      // console.log(that.data.query);
      that.setData(that.data.query);

      that.setData({
        sectionid: that.data.query.sectionid,
        id: that.data.query.id
      })
      setTimeout(function () {
        // console.log(966555)
        // that.setData({
        //   toView: 'dddd',
        // })
        that.jumpTo()
      }, 1000)
      

    } else {
      wx.showModal({
        title: '提示',
        showCancel: false,
        confirmColor: '#333333',
        content: '页面参数缺失',
      })
    }
  }, 500);
  // console.log(1)
  that.reset(1);
};

//切换picker后更换速率
VM.bindPickerChange = function (e) {
  this.setData({
    RateIndex: e.detail.value
  })
  if (this.videoContext.playbackRate) {
    this.videoContext.play();
    this.videoContext.playbackRate(parseFloat(this.data.RateArray[e.detail.value].value));
  } else {
    wx.showModal({
      title: "提示",
      content: "当前版本微信不支持该功能，请升级版本！"
    })
  }
};

VM.changedLsitStyle = function(e){
  var that = this,
      type = e.currentTarget.dataset.type;

  wx.setStorage({
    key: 'sectionListType',
    data: type,
  })

  that.setData({
    scrollType: type,
    toView: ''
  })

  setTimeout(()=>{
    that.setData({
      scrollType: type,
      toView: 'dddd'
    })
  },100);
  
};

VM.onShareAppMessage = function () {

};
Page(VM);