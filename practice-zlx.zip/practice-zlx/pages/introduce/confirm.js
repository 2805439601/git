// pages/introduce/confirm.js
var app = getApp();

var VM = {
	data: {
		isUp:1,
		myCuponId:'-2',
		couponMoney:'0.00',
		//测试数据
		price: 1,
		teacherphoto: "",
		lesson: {
			teacher: "",
			images: "",
			bookname: "",
			lesson_type: 0,
		},
		spec:{
			spec_day: -1,
			spec_name: "",
			spec_price: 1.00,
		},
		setting: {
			is_invoivce: true
		},
		coupon_list:[
			// {
			// 	id: 0,

			// }
		],
		deduct_switch: true,
		appoint_info:["手机"],
		vipCoupon: 0.5,
		couponMoney: '0.00',
		deducMoney: '',
    jsdeducMoney:0,//积分抵扣 计算后
		apply_price: 0.1,
		price_deducMoney_couponMoney:0.21,
		price_couponMoney: 0.2
	},
};

var urls = {
	'confirm': 'source=confirm',
	'save':'source=addtoorder'
}
//使用优惠券
VM.useUp = function(e){
	var that = this;

	if (that.data.coupon_list.length>0){
		that.setData({
			isUp:2
		})
	}else{
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '你没有可以选择的优惠券',
		})
		return;
	}
};
//选择优惠券
VM.choseCupon = function(e){
	var that = this,
		key = e.currentTarget.dataset['index'],
		myCuponId = that.data.myCuponId;

	if (myCuponId==key){
		that.setData({myCuponId:'-2'})
	}else{
		that.setData({myCuponId: key })
	}
  
}
//确定
VM.confirmBtn = function(){
	var that = this,
		list = that.data.coupon_list,
		data = {},
		myCuponId = that.data.myCuponId;
	if (myCuponId == '-2' || myCuponId == '-1'){
		data.couponMoney = '0.00';
		data.coupon_id = '';
	}else{
		data.couponMoney = list[myCuponId].amount;
		data.coupon_id = list[myCuponId].id;
	}
	data.isUp = 1;
	that.setData(data);
  var should = that.data.spec.spec_price;
  that.setData({
    price_couponMoney: should - that.data.couponMoney
  });
}
//输入
VM.myInput = function(e){
	var that = this, 
    
		value = e.detail.value,
    
		key = e.currentTarget.dataset['key'],
		appoint_info1 = that.data.appoint_info1;
  if (Number(value) > Number(that.data.jdata.deduct_integral)){
    wx.showModal({
      title: "最多只能使用" + that.data.jdata.deduct_integral+"积分",
      content: '',
      success: function (res) {
        that.setData({
          deducMoney:0,
          jsdeducMoney:0
        })
        if (res.confirm) {        
        }
      }
    })
  }
	if (value != '') {
		value = value.replace(/ /ig, '')
		if (key =='deducMoney'){
			that.setData({
				deducMoney: value,
        jsdeducMoney: (Number(value) * Number(that.data.jdata.deduct_money)).toFixed(2)
			})
		}else{
			appoint_info1[key] = value
			that.setData({
				appoint_info1: appoint_info1,
        
			})
		}
		
	} else {
		if (key == 'deducMoney') {
			that.setData({
				
        deducMoney: '',
        jsdeducMoney: 0
			})
		} else {
			appoint_info1[key] = ""
			that.setData({
				appoint_info1: appoint_info1
			})
		}
		
	}
}
//支付
VM.save = function(){
	var that = this,
		appoint_info = that.data.appoint_info,
		data = {},
		appoint_info1 = that.data.appoint_info1;
	//console.log(appoint_info1)
	if (appoint_info1){
		var isBack = false;
		for (var i = 0; i < appoint_info1.length;i++){
			var o = appoint_info1[i];
			//console.log(o)
			if (o=='') {
				wx.showModal({
					title: '提示',
					showCancel: false,
					confirmColor: '#333333',
					content: appoint_info[i] + '不能为空',
				})
				isBack = true;
				break;
			}else{
				if (appoint_info[i]=='电话'&&o.length!=11){
					wx.showModal({
						title: '提示',
						showCancel: false,
						confirmColor: '#333333',
						content: '手机号码为11位数字',
					})
					isBack = true;
					break;
				}
			}
		}
		
		if (isBack){return}
		data.appoint_info = appoint_info1;
	}
	//console.log(data);
	if (that.data.coupon_list.length > 0 && that.data.couponMoney > 0 && that.data.coupon_id && that.data.coupon_id!=''){
		data.couponMoney = parseFloat(that.data.couponMoney);
		data.couponID= that.data.coupon_id;
	}
	if (that.data.deducMoney > 0 && that.data.deduct_switch){
		data.deducMoney = that.data.deducMoney;
	}
	
	data.id = that.data.id;
	data.spec_id = that.data.spec_id;
  data.deduct_integral = that.data.deducMoney
	
	var url = urls['save'] ,
		s = { url: url, data: data};
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			wx.redirectTo({
				url: '/pages/pay/index?level_id=' + inf.data.orderid
			})
		}else{
			wx.showModal({
				title: '提示',
				showCancel: false,
				confirmColor: '#333333',
				content: inf.data.message,
			})
		}
	}, function (inf) {

	})

}
//取消
VM.myColse = function (e) {
	var that = this,
		key = e.currentTarget.dataset['key'];
	if(key==1){
		wx.navigateBack({
			delta: 1
		})
	}else{
		that.setData({
			isUp: 1
		})
	}
	


};
//查看用户协议
VM.goAgreement = function(){
	wx.navigateTo({
		url: '/pages/agreement/index'
	})
}

//获取用户信息
VM.onLoad = function (query) {
	var that = this;
	if (query.id &&query.spec_id){
		that.setData(query);
		var data = { id: query.id, spec_id: query.spec_id },
			url = urls['confirm'],
			s = { url: url, data: data };
		app.request(s, function (inf) {
			console.log(inf);
      that.setData({
        price_couponMoney: inf.data.spec.spec_price,
        jdata: inf.data
      });
			if (inf.errorCode == 0) {
				if (inf.data.lesson.lesson_type == 1 && inf.data.appoint_info.length != 0){
					var arr = [];
					inf.data.appoint_info.forEach(function(o){
						arr.push('')
					})
					inf.data.appoint_info1 = arr;
				}
        var aa = inf.data.coupon_list
				that.setData(inf.data)
			}else{
				wx.showModal({
					title: '提示',
					showCancel: false,
					confirmColor: '#333333',
					content: inf.data.message,
					success: function (res) {
						if (res.confirm) {
							wx.reLaunch({
								url: '/pages/myCurse/index'
							})
						} else if (res.cancel) {
							wx.reLaunch({
								url: '/pages/myCurse/index'
							})
						}
					}
				})
			}
		}, function (inf) {

		})
	}else{
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '页面参数缺失',
		})
	}
	
}
VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};
VM.onReachBottom = function () {
	var that = this;
	
};
VM.onShareAppMessage = function () {

};
Page(VM);