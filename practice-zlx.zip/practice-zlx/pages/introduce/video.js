// pages/introduce/video.js
var app = getApp();
var fontMenu = require('common/footMenu.js');
var footerMask = require('common/footerMask.js');
var VM = {
	data: {
		current_sw: 0,
		isFooterMask: 2
	},
};


VM.pause = function(e){
	console.log(e)
}
VM.videoErrorCallback = function(e) {
	console.log('视频错误信息:')
	console.log(e.detail.errMsg)
}
// 播放视频事件
VM.myTime = function (e) {
	// console.log(e)
};









//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var self = this;
	fontMenu.init(self);
	
	footerMask.init(self);

};

VM.onReady = function () {
	this.videoContext = wx.createVideoContext('myVideo');
};

VM.onShow = function () {
	var self = this;

};

VM.onShareAppMessage = function () {

};
Page(VM);
