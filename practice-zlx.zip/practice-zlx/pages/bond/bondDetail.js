// pages/bond/bondDetail.js
var app = getApp();
var VM = {
	data: {

	},
};
var urls = {
	'index': 'source=mc_bond_ctrl'
}

//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var that = this;
	
	if (query.id){
		that.setData({
			myType:query.type
		})
		var data = { type: 'recorddetail', op: 'credits', id: query.id},
			url = urls['index'];
		data.credittype = 'credit' + query.type;
		var s = { url: url, data: data };
		app.request(s, function (inf) {
			//console.log(inf)
			if (inf.errorCode == 0) {
				that.setData(inf.data)

			}
		}, function (inf) {

		})
	}else{
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '页面参数错误',
		})
	}
	

};



VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};

VM.onShareAppMessage = function () {

};
Page(VM);