// pages/bond/bond.js
var app = getApp();

var VM = {
	data: {
		array: [],
		array1: [1,0,-1,-2],
		page: 1,//第几页
		end: false,//是否加载中
		noend: true,//是否最后一页 true非最后一页
		index:0,
		
	},
};
var urls = {
	'index': 'source=mc_bond_ctrl'
}
//取消
VM.myColse = function (e) {
	var that = this;
	//console.log('我在返回')
	wx.navigateBack({
		delta: 1
	})


};
//选择日期
VM.bindPickerChange = function(e){
	var that = this;
	that.setData({
		index: e.detail.value
	})
	that.reset();
}

//重新获取数据
VM.reset = function(){
	var that = this;
	that.setData({
		page: 1,
		end: false,
		noend: true,
		list: []
	});
	that.getList();
}
//获取数据
VM.getList = function (isFirst) {
	
	var that = this, page = that.data.page, myEnd = that.data.end;
	if (myEnd || !that.data.noend) { return };//判断是否在加载中或者已经到最后一个
	that.setData({
		end: true
	});

	wx.showLoading({
		title: '加载中...',
	})
	var index = that.data.index,
		data = { page: page, type: 'record', op: 'credits', period: that.data.array1[index] },
		url = urls['index'];
		data.credittype = 'credit'+that.data.type;
		var s = { url: url, data: data };
	
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			if (isFirst==1){
				var array = [];
				array[0] = '查看全部';
				array[1] = inf.data.today;
				array[2] = inf.data.prevmonth;
				array[3] = inf.data.prevsmonth;
				that.setData({
					array: array,
					income: inf.data.income,
					pay: inf.data.pay
				})
			}
			var list = that.data.list || [];
			inf.data.data.forEach(function (o, i) {
				list.push(o);
			})
			page++;
			if (inf.data.pagenums < page) {
				that.setData({
					list: list,
					noend: false,
					page: page,
					end: false

				});
			} else {
				that.setData({
					list: list,
					page: page,
					end: false

				});
			}
		} else {
			
			that.setData({
				end: false
			});
		}
		wx.hideLoading();
	}, function (inf) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '数据加载失败',
		})
		wx.hideLoading();
		that.setData({
			end: false
		});
	})

}





//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var that = this;
	
	//判断是否授权用户信息
	app.myGetSetting({
		scope_key: 'scope.userInfo',
		fail: function () {

		},
		callback: function () {
			if (query.type) {
				that.setData(query);
				that.getList(1)
			}else{
				wx.showModal({
					title: '提示',
					showCancel: false,
					confirmColor: '#333333',
					content: '页面参数错误',
				})
			}
			
		}

	})



};

VM.onReady = function () {

};

VM.onShow = function () {
	var that = this;

};
VM.onReachBottom = function () {
	var that = this;

	
};
VM.onShareAppMessage = function () {

};
Page(VM);
