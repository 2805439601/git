// pages/cash/cash.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {
		array: ['请选择提现方式', ' 提现到余额 √', ' 提现到微信钱包 √', ' 提现到支付宝 √'],
		index: 0
	},
};

//请求地址集合
var urls = {
	'index1': 'source=commission',
	'index2': 'source=lessoncash'
	
}
//取消
VM.myColse = function (e) {
	var that = this;
	// console.log('我在返回')
	wx.navigateBack({
		delta: 1
	})


};
// 输入
VM.input = function (e) {
	let value = e.detail.value,
		key = e.currentTarget.dataset['key'];
	var data = {};
	if (key == 'myMoney') {
		if (isNaN(value)) {
			value = 0;
		}
	}
	data[key] = value;

	this.setData(data);
};
//选择日期
VM.bindPickerChange = function (e) {
	var that = this;
	that.setData({
		index: e.detail.value
	})

}

//提交
VM.again = function () {
	var that = this,
		id = that.data.idx;
		if(!id){
			wx.showModal({
				title: '提示',
				showCancel: false,
				confirmColor: '#333333',
				content: '页面参数有误',
			})
			return;
		}
	
	var data = { drawings: 1 },
		url = urls['index' + id];
	if (id == 1) {
		data.op = 'cash';
	}
	if (that.data.index == 0) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '请选择提现方式',
		})
		return;
	}
	data.cash_way = that.data.index;
	if (that.data.index == 3) {
		if (!that.data.accont) {
			wx.showModal({
				title: '提示',
				showCancel: false,
				confirmColor: '#333333',
				content: '支付宝帐号不能为空',
			})
			return;
		}
		if (!that.data.myName) {
			wx.showModal({
				title: '提示',
				showCancel: false,
				confirmColor: '#333333',
				content: '支付宝户主姓名不能为空',
			})
			return;
		}
		data.pay_account = that.data.accont;
		data.pay_name = that.data.myName
	}
	if (!that.data.myMoney) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '提现金额不能为空',
		})
		return;
	}
	if (that.data.myMoney < 0 || isNaN(that.data.myMoney)) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '提现金额有误',
		})
		return;
	}
	data.cash_num = that.data.myMoney;


	app.myGetSetting({
		scope_key: 'scope.userInfo',
		fail: function () {

		},
		callback: function () {

			var s = { url: url, data: data };
			app.request(s, function (inf) {
				console.log(inf)
				if (inf.errorCode == 0) {

					wx.showToast({
						title: '提现成功',
						icon: 'success',
						duration: 2000,
						success: function () {
							wx.navigateBack({
								delta: 1
							})
						}
					})
				} else {
					wx.showModal({
						title: '提示',
						showCancel: false,
						confirmColor: '#333333',
						content: inf.data.message,
					})
				}
			}, function (inf) {

			})
		}

	})
}

//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var that = this;
	fonter.init(that);
	if (query.idx){
		that.setData(query);
		app.myGetSetting({
			scope_key: 'scope.userInfo',
			fail: function () {

			},
			callback: function () {
				var data = { },
					url = urls['index' + query.idx];
					if(query.idx==1){
						data.op = 'cash'; 
					}
				var s = { url: url, data: data };
				app.request(s, function (inf) {
					//console.log(inf)
					if (inf.errorCode == 0) {
						if (!inf.data.nopay_commission) {
							inf.data.nopay_commission1 = '';
						} else {
							inf.data.nopay_commission1 = inf.data.nopay_commission;
						}
						if (query.idx==1){
							inf.data.nopay_lesson = inf.data.member.nopay_commission;
							inf.data.textTitle = '提现佣金';
						}else{
							inf.data.textTitle = '课程收入';
						}
						that.setData(inf.data)

					} else {
						wx.showModal({
							title: '提示',
							showCancel: false,
							confirmColor: '#333333',
							content: inf.data.message,
						})
					}
				}, function (inf) {

				})

			}
		});
	}else{
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '页面参数有误',
			
		})
	}
	
};

VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};
//滑动加载
VM.onReachBottom = function () {
	var that = this;
	that.getList();//请求数据
};
VM.onShareAppMessage = function () {

};
Page(VM);