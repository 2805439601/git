// pages/usercenter/usercenter.js
var app = getApp();

var fonter = require('../common/footer.js');
var VM = {
  data: {
    isFooter: 'usercenter',
    avatar: "",
    nickname: "",
    isOpen: 2,
    idcard: '',
    isedit: false,
    userInfo: {}
  },
};

//请求地址集合
var urls = {
  'index': 'source=self',
  'applyteacher': 'source=applyteacher',
  'tkeep': 'source=self&op=getInfo',
  'ckeep': 'source=self&op=edit'
}

//用户授权
VM.getuserinfo = function (e) {
  //console.log(e.detail.userInfo);
  var userInfo = e.detail.userInfo,
    that = this;
  if (userInfo) {
    //用户意见授权过
    if (app.globalData.islogin) {
      this.setData({
        isedit: true
      })
    }
    this.setData({
      avatar: userInfo.avatarUrl,
      nickname: userInfo.nickName,
      isOpen: 2
    })
    wx.setStorageSync('scope.userInfo', userInfo);
    app.globalData.userInfo = userInfo;
    app.globalData.islogin = true;
    app.getToken(function () {
      that.getData();
    }, userInfo);
    var data = {},
      url = urls['tkeep'],
      s = {
        url: url,
        data: data
      };
    app.request(s, function (inf) {
      if (inf.errorCode == 0) {
        that.setData({
          phone: inf.data.member.mobile,
          name: inf.data.member.nickname,
          idcard: inf.data.member.id_card
        })
      } else {
        wx.showModal({
          title: inf.data.message,
          content: '',
          showCancel: false,
        })
      }
    })
  } else {

    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '你已拒绝授权',
    })
    console.log('用户拒绝授权')
  }


};

VM.gotoEditPhone = function () {
  wx.navigateTo({
    url: '/pages/bound/bound',
  })
}

VM.goTeacher = function () {
  var self = this,
    url = urls['applyteacher'],
    s = {
      url: url,
      data: {},
      post: 'GET'
    };
  app.myGetSetting({
    scope_key: 'scope.userInfo',
    fail: function () {},
    callback: function () {
      app.request(s, function (inf) {
        if (inf.data.status == 0) {
          wx.navigateTo({
            url: '/pages/askTeacher/teachercenter',
          })
        } else {
          wx.navigateTo({
            url: '/pages/askTeacher/index',
          })
        }

      }, function (inf) {})
    }
  })
}
VM.closeGetUser = function () { //关闭授权弹框
  this.setData({
    isOpen: 2
  })
}
VM.gonavigator = function (e) {
  var that = this;
  if (app.globalData.islogin) {
    wx.navigateTo({
      url: e.currentTarget.dataset.url,
    })
  } else {
    that.setData({
      isOpen: 1
    })
  }
}

VM.getData = function () {
  var self = this;
  var url = urls['index'],
    s = {
      url: url,
      data: {}
    };
  app.request(s, function (inf) {
    self.setData({
      credit1: inf.data.credit1,
      credit2: inf.data.credit2,
      is_sale: inf.data.is_sale,
      studentno: inf.data.studentno,

    });

  }, function (inf) {

  })
}

VM.phoneInput = function (e) {
  let str = 'userInfo.phone';
  this.setData({
    phone: e.detail.value
  })
}
VM.nameInput = function (e) {
  let str = 'userInfo.name';
  this.setData({
    name: e.detail.value
  })
}
VM.idcardInput = function (e) {
  let str = 'userInfo.idcard';
  this.setData({
    idcard: e.detail.value
  })
}
VM.closeEdit = function () {
  this.setData({
    isedit: false
  })
}
VM.saveEdit = function () {
  var that = this
  // var phone = that.data.phone
  var name = that.data.name
  var idcard = that.data.idcard
  // if (phone == ''){
  //   wx.showModal({
  //     title: '请填写手机号',
  //     content: '',
  //     showCancel: false,
  //   })
  //   return
  // }
  if (name == '') {
    wx.showModal({
      title: '请填写姓名',
      content: '',
      showCancel: false,
    })
    return
  }
  // if (idcard == '') {
  //   wx.showModal({
  //     title: '请填写身份证号码',
  //     content: '',
  //     showCancel: false,
  //   })
  //   return
  // }
  var data = {
      id_card: idcard,
      nickname: name
    },
    url = urls['ckeep'],
    s = {
      url: url,
      data: data
    };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      wx.showToast({
        title: '保存成功'
      });
      that.setData({
        isedit: false
      })
    } else {
      wx.showModal({
        title: inf.data.message,
        content: '',
        showCancel: false,
      })

    }
  })
  //提交数据接口

}

//获取用户信息
VM.onLoad = function (query) {

  // 登录
  var self = this;
  var that = this;
  fonter.init(self);

  let islogin = app.globalData.islogin;
  let userInfo = app.globalData.userInfo;
  if (islogin && userInfo) {
    this.setData({
      avatar: userInfo.avatarUrl,
      nickname: userInfo.nickName,
      isOpen: 2
    })
    self.getData();
  }
  var data = {},
    url = urls['tkeep'],
    s = {
      url: url,
      data: data
    };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      self.setData({
        phone: inf.data.member.mobile,
        name: inf.data.member.nickname,
        idcard: inf.data.member.id_card
      })
    } else {
      wx.showModal({
        title: inf.data.message,
        content: '',
        showCancel: false,
      })
    }
  })
  //var url = urls['index'], s = { url: url, data: {} };
  // app.myGetSetting({
  // 	scope_key: 'scope.userInfo',
  // 	fail: function () {

  // 	},
  // 	callback: function () {
  // 		app.request(s, function (inf) {
  // 			//console.log(inf.data)
  // 			self.setData(inf.data)
  // 		}, function (inf) {

  // 		})
  // 	}
  // })
  var syInfo = app.sysInfo(); //判断iOS还是安卓
  that.setData({
    syInfo: syInfo
  })
};

VM.onReady = function () {

};

VM.onShow = function () {
  var self = this;
  wx.hideHomeButton();
};

VM.onShareAppMessage = function () {

};
Page(VM);