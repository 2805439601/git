// pages/footprint/index.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
  data: {
    page: 1,//第几页
    end: false,//是否加载中
    noend: true,//是否最后一页 true非最后一页

    //测试数据
    list: [
      // {
      //   id: 0,
      //   teacherphoto: "http://img4.imgtn.bdimg.com/it/u=2246980521,2027696365&fm=26&gp=0.jpg",
      //   teacher: "王老师",
      //   student_num: 198,
      //   lesson_total: 30,
			//   teacherdes: "具有丰富的培训和内训经验，专业基础知识扎实；熟悉经济师考试内容，结合实践经验对于经济师培训有自己独到的方法；曾在《中国证券报》、《证券时报》、《上海证券报》《期货日报》、《中国橡胶》及《中国石油报》等报纸和杂志上发表过文章。"
      // },
      // {
      //   id: 1,
      //   teacherphoto: "http://img4.imgtn.bdimg.com/it/u=2246980521,2027696365&fm=26&gp=0.jpg",
      //   teacher: "王老师",
      //   student_num: 198,
      //   lesson_total: 30,
			//   teacherdes: "具有丰富的培训和内训经验，专业基础知识扎实；熟悉经济师考试内容，结合实践经验对于经济师培训有自己独到的方法；曾在《中国证券报》、《证券时报》、《上海证券报》《期货日报》、《中国橡胶》及《中国石油报》等报纸和杂志上发表过文章。"
      // }
    ]
  },
};

var urls = {
  'index': 'source=collect',
}

//取消
VM.myColse = function (e) {
  var that = this;
  // console.log('我在返回')
  wx.navigateBack({
    delta: 1
  })
};
//请求数据
VM.requestData = function (e) {
  var that = this, page = that.data.page, myEnd = that.data.end;

  if (myEnd || !that.data.noend) { return }
  that.setData({
    end: true
  });
  // wx.showLoading({
  //   title: '加载中...',
  // })
  var url = urls['index'],
    that = this,
    s = { url: url, data: { op: 'ajaxgetteacher', page: that.data.page,ctype:2 }, post: 'GET' };
  app.request(s, function (inf) {
    console.log(inf);
    if (inf.errorCode == 0) {
      var list = that.data.list || [];
      inf.data.teacherlist.forEach(function (o, i) {
        list.push(o);
      });
      page++;
      if (inf.data.pageCount < page) {
        that.setData({
          list: list,
          noend: false,
          page: page,
          end: false

        });
      } else {
        that.setData({
          list: list,
          page: page,
          end: false

        });
      }
    } else {
      wx.showToast({
        title: '数据加载失败',
        icon: 'none'
      })
      that.setData({
        end: false
      });
    }
    wx.hideLoading();
  }, function (inf) {
    wx.hideLoading();
  })

};

//获取用户信息
VM.onLoad = function (query) {
  // 登录
  var self = this;
  fonter.init(self);
  self.requestData();//请求数据
};

VM.onReady = function () {

};
VM.onReachBottom = function () {
  var that = this;
  that.requestData();//请求数据
};
VM.onShow = function () {
  var self = this;
};

VM.onShareAppMessage = function () {

};
Page(VM);