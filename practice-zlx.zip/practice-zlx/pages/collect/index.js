// pages/collect/index.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {
		page: 1,//第几页
		end: false,//是否加载中
		
		//测试数据
		noend: false,//是否最后一页 true非最后一页
		myData: {
			ctype: 1,
		},
    syInfo: '',//系统信息，安卓还是iOS或PC
		list: [
			{
				id: 0,
				images: "/images/banner.jpg",
				buynum_total: 2,
				seccount: 7,
				bookname: "本科学历提升",
				price: 0.01,
				section_status: 0,
				type_list: [
					{
						id: 0,
						type: "职称咨询"
					},
					{
						id: 1,
						type: "学历提升"
					}
				],
			},
			{
				id: 0,
				images: "/images/banner.jpg",
				buynum_total: 2,
				seccount: 7,
				bookname: "本科学历提升",
				price: 0.01,
				type_list: [
					{
						id: 0,
						type: "职称咨询"
					},
					{
						id: 2,
						type: "考证"
					}
				],
			},
			{
				id: 0,
				images: "/images/banner.jpg",
				buynum_total: 2,
				seccount: 7,
				bookname: "本科学历提升",
				price: "免费",
				type_list: [
					{
						id: 0,
						type: "职称咨询"
					},
					{
						id: 1,
						type: "学历提升"
					}
				],
			}
		]
	},
};
//请求地址集合
var urls = {
	'index': 'source=collect'
}

//取消
VM.myColse = function (e) {
	var that = this;
	console.log('我在返回')
	wx.navigateBack({
		delta: 1
	})


};
//重置页面
VM.reset = function () {//
	var that = this;
	that.setData({
		page: 1,
		end: false,
		noend: true,
		list: []
	});
	that.getList(1)
};
//获取数据
VM.getList = function (isFirst) {
	var that = this, page = that.data.page, myEnd = that.data.end;
	if (myEnd || !that.data.noend) { return };//判断是否在加载中或者已经到最后一个
	that.setData({
		end: true
	});

	wx.showLoading({
		title: '加载中...',
	})
	var data =  { ctype: 1,page:page } ,
		url = urls['index'],
		s = { url: url, data: data };
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			var list = that.data.list || [];
			inf.data.lessonlist.forEach(function (o, i) {
				list.push(o);
			})
			page++;
			if (inf.data.pageCount < page) {
				var data2 = {
					list: list,
					noend: false,
					page: page,
					end: false
				}
				if (isFirst==1){
					data2.myData = inf.data;
				}
				that.setData(data2);
			} else {
				var data2 = {
					list: list,
					page: page,
					end: false

				}
				if (isFirst == 1) {
					data2.myData = inf.data;
				}
				that.setData(data2);		
			}
		}

		wx.hideLoading()
	}, function (inf) {
		wx.hideLoading()
		that.setData({
			end: false
		});
	})

}





//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var self = this;
	fonter.init(self);
  var syInfo = app.sysInfo();//判断iOS还是安卓
  this.setData({
    syInfo: syInfo
  })
	
};
VM.onReachBottom = function () {
	var that = this;
	that.getList();
};
VM.onReady = function () {

};

VM.onShow = function () {
	var that = this;
  that.reset();
	// app.myGetSetting({
	// 	scope_key: 'scope.userInfo',
	// 	fail: function () {

	// 	},
	// 	callback: function () {
	// 		// that.reset();
	// 	}

	// })
};

VM.onShareAppMessage = function () {

};
Page(VM);