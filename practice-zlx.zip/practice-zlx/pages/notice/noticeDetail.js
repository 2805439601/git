// pages/notice/noticeDetail.js
var app = getApp();
var fonter = require('../common/footer.js');
var WxParse = require('../../utils/wxParse/wxParse.js');
var VM = {
	data: {
		
	},
};

var urls = {
	'index': 'source=article'
}







//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var self = this;
	fonter.init(self);
	//console.log(query)
	if (query.aid){
		var url = urls['index'],
			s = { url: url, data: { aid: query.aid}, post: 'GET' };
		wx.showLoading({
			title: '加载中...',
		})
		app.request(s, function (inf) {
			//console.log(inf)
			if (inf.errorCode==0){
				var article = inf.data.article.content;
				// console.log(article)
				WxParse.wxParse('article1', 'html', article, self, 5);
				self.setData(inf.data)
			}
			wx.hideLoading()
		}, function (inf) {

		})
	}
	

};

VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};

VM.onShareAppMessage = function () {

};
Page(VM);