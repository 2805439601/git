// pages/notice/notice.js
var app = getApp();
var VM = {
	data: {
		page: 1,//第几页
		end: false,//是否加载中
		noend: true,//是否最后一页 true非最后一页
		//测试数据
		list:[
			// {
			// 	id: 9,
			// 	title: "社群盈利思维逻辑",
			// 	addtime: "04-28"
			// },
			// {
			// 	id: 11,
			// 	title: "社群运营高手5天速成班",
			// 	addtime: "04-29"
			// }
		]
	},
};

var urls = {
	'index': 'source=article'
}

//取消
VM.myColse = function (e) {
	var that = this;
	//console.log('我在返回')
	wx.navigateBack({
		delta: 1
	})
};
//获取数据
VM.getList = function(){
	var that = this, page = that.data.page, myEnd = that.data.end;
	if (myEnd || !that.data.noend) { return };//判断是否在加载中或者已经到最后一个
	that.setData({
		end: true
	});

	// wx.showLoading({
	// 	title: '加载中...',
	// })
	var data = { page: page, method: 'ajaxgetlist', op:'getlist'},
		url = urls['index'],
		s = { url: url, data: data};
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode==0){
			var list = that.data.list || [];
			inf.data.list.forEach(function (o, i) {
				list.push(o);
			})
			page++;

			if (inf.data.page_count < page) {
				that.setData({
					list: list,
					noend: false,
					page: page,
					end: false,

				});
			} else {
				that.setData({
					list: list,
					page: page,
					end: false
				});
			}
		}
		
		wx.hideLoading()
	}, function (inf) {
		wx.hideLoading()
		that.setData({
			end: false
		});
	})

}





//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var self = this;
	self.getList();
};

VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};
VM.onReachBottom = function () {
	var that = this;
	
	that.getList();
};
VM.onShareAppMessage = function () {

};
Page(VM);