//index.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
  data: {
    current_sw: 0,
    isFooter: 'index',
    showBg: true,
    allCategoryIco: '',
    syInfo: '', //系统信息，安卓还是iOS或PC
  },
};
var urls = {
  'index': 'source=index'
}
// VM.getUserInfo = function (e) {

//   //console.log(e.detail.userInfo);
//   var userInfo = e.detail.userInfo,
//     that = this;
//   if (userInfo) {
//     wx.setStorageSync('scope.userInfo', userInfo);
//     app.getToken(function () {

//       that.setData({ isOpen: 2 })


//     }, userInfo, that.data.scene);
//   } else {
//     wx.showModal({
//       title: '提示',
//       showCancel: false,
//       confirmColor: '#333333',
//       content: '你已拒绝授权',
//     })

//   }
// };


// 通用input事件
VM.inputComm = function (e) {
  var key = e.currentTarget.dataset.key;
  //console.log(key);
  var data = {};
  data[key] = e.detail.value;
  this.setData(data);
};


VM.tapSwiper = function (e) {
  // console.log(e);
  this.setData({
    current: e.detail.current + 1,
    unlock_tx: '',
  });
};

/*
 * 将一个百数组度分成几个问同等长答度的数组
 * array[分割的原版数组]
 * size[每个子数组的长权度]
 */
VM.sliceArray = function (array, size) {
  var result = [],
    n = Math.ceil(array.length / size);
  for (var x = 0; x < n; x++) {
    var start = x * size;
    // x == n-1?end=array.length:end=start + size;
    var end = start + size;
    //console.log('start,' + start + 'end,' + end)
    result.push(array.slice(start, end));
    // console.log(result);
    // console.log(start);
    // console.log(end);
  }
  return result;
}


//获取用户信息
VM.onLoad = function (query) {
  // 登录
  var self = this;
  fonter.init(self);
  var syInfo = app.sysInfo(); //判断iOS还是安卓
  self.setData({
    syInfo: syInfo
  })

  var url = urls['index'],
    s = {
      url: url,
      data: {},
      post: 'GET'
    };
  if (query.scene) {
    var scene = decodeURIComponent(query.scene)
    s.data.scene = scene;
    wx.setStorageSync('scene', scene);
  }
  s.isOpen = 1;
  //判断是否授权用户信息
  app.myGetSetting({
    scope_key: 'scope.userInfo',
    scene: scene,
    isOPen: 1,
    fail: function () {

    },
    callback: function (ret) {
      if (ret.isOpen) {
        self.setData(ret);
      }
      app.request(s, function (inf) {
        // console.log(inf.data.list)
        // console.log(inf)
        if (inf.errorCode == 0) {
          var data = {};
          data.banner = inf.data.banner;
          data.category_list = inf.data.category_list;
          data.allCategoryIco = inf.data.allCategoryIco;
          data.articlelist = inf.data.articlelist;
          // 接口数据以对象形式给的话，就不用这么麻烦了
          inf.data.list.forEach(function (o) {
            // console.log(o);
            o.arr = self.sliceArray(o.lesson, 3)
            // console.log(self);
            // console.log(o)
          })
          data.list = inf.data.list;
          self.setData(data);
        }

      }, function (inf) {

      })
    }

  })



};

VM.onReady = function () {

};

VM.onShow = function (query) {
  var self = this;

};

VM.onShareAppMessage = function (res) {
  if (res.from === 'button') {
    // 来自页面内转发按钮
    console.log(res.target)
  }
  return {
    title: '首页',
    path: '/pages/index/index'
  }
};
Page(VM);