// pages/askTeacher/teachercenter.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
  data: {
    page: 0,
    shenhe:"申请"
  },
};
//请求地址集合
var urls = {
  'index': 'source=teachercenter'
}


//获取用户信息
VM.onLoad = function (query) {
  // 登录
  var self = this;
  self.setData({
	  approot: app.globalData.approot
  })
  fonter.init(self);
  
};

VM.onReady = function () {

};

VM.onShow = function () {
  var self = this;
	var url = urls['index'],
		s = { url: url, data: {} };

	app.myGetSetting({
		scope_key: 'scope.userInfo',
		fail: function () {

		},
		callback: function () {
			app.request(s, function (inf) {
        if (inf.errorCode==4701){return}
				var shenhe = self.data.shenhe;
				if (!inf.data.teacher || inf.data.teacher == null) {
					shenhe = "未申请";
				} else if (inf.data.teacher.status == -1) {
					shenhe = "审核未通过"
				}
				else if (inf.data.teacher.status == 1) {
					shenhe = "申请通过"
				}
				else if (inf.data.teacher.status == 2) {
					shenhe = "审核中"
				}
				var money = inf.data.member.pay_lesson * 1 + inf.data.member.nopay_lesson * 1;

				self.setData({
					list: inf.data,
					money: money,
					shenhe: shenhe
				});

			}, function (inf) {
        console.log(22222)
        console.log(inf)
			})
		}
	})
};

VM.onShareAppMessage = function () {

};
Page(VM);