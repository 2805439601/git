// pages/askTeacher/index.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {
		imageList1:[],
		imageList2: [],
    arr:[]
	},
};
var urls = {
		'index': 'source=applyteacher',
		'imgUp':'source=uploadimages'
	}
// 输入数据
VM.onChange=function(e){
  let self = this ;
    let arr = self.data.arr;
  let type = e.currentTarget.dataset.input
  let input = e.detail.value
  arr[type] = input
  self.setData({
    arr:arr
  })
},
//添加图片
VM.addImg = function (e) {
	var self = this,
		index = e.currentTarget.dataset['idx'],
		imageList = self.data['imageList' + index];
		// console.log(imageList)
	if (imageList.length == 1) {
		wx.showModal({
			title: '提示',
			content: '图片不能超过1张',
		})
		return;
	}
	wx.chooseImage({
		count: 1,
		success: function (res) {
			//console.log(res)
			var length = res.tempFilePaths.length + imageList.length;
			if (length > 3) {
				wx.showModal({
					title: '提示',
					content: '图片不能超过1张',
				})
				return;
			}
			res.tempFilePaths.forEach(function (o) {
				imageList.push(o)
			})
			var data = {};
			data['imageList'+index] = imageList;
			self.setData(data)
		},
		fail: function () {

		}
	})
}
//删除图片
VM.myDel = function (e) {
	var self = this,
		index = e.currentTarget.dataset['key'],
		idx = e.currentTarget.dataset['idx'],
		imageList = self.data['imageList'+idx];
	imageList.splice(index, 1);
	var data = {};
	data['imageList' + idx] = imageList
	self.setData(data);
}
// 提交
VM.save=function(e){
  var self = this
  //console.log(self.data.arr.teacher);
  if (!self.data.arr.teacher){
      wx.showModal({
        title: '提示',
        content: '请填写讲师名称',
      })
      return false
    }
  else if (!self.data.arr.teacherdes) {
    wx.showModal({
      title: '提示',
      content: '请填写讲师介绍',
    })
    return false
  }
  else if (!self.data.imageList2[0]) {
    wx.showModal({
      title: '提示',
      content: '请选择讲师相片',
    })
    return false
  }
  else{
	  var imgUrl = urls['imgUp'],
		  data1 = {},
		  data = {},
		  arr = [],
		  img1;
	  data1.arr = [];

	  if (self.data.imageList1.length > 0) {
		  data1.arr[0] = self.data.imageList2[0];
		  data1.arr[1] = self.data.imageList1[0];
	  } else {
		  data1.arr = self.data.imageList2;
	  }
	  // console.log(data1.arr)
	  app.myUploadimg(
		  data1,
		  function (res) {//成功
			  // console.log(res)
			  arr.push(res.path);
		  },
		  function (res) {//失败


		  },
		  function (res) {
			  //console.log('完成');
			  // console.log(arr)
			  var url = urls['index'],
				  s = {
					  url: url,
					  data: {
						  qq: self.data.arr.qq,
						  teacher: self.data.arr.teacher,
						  teacherdes: self.data.arr.teacherdes,
						  qqgroup: self.data.arr.qqgroup,
						  teacherphoto: arr[0],
						  weixin_qrcode: arr[1],
						  op: 'postteacher'
					  },
					  post: 'GET'
				  };
				  if(arr[1]){
					  s.data.weixin_qrcode = arr[1];
				  }
			  app.myGetSetting({
				  scope_key: 'scope.userInfo',
				  fail: function () {
				  },
				  callback: function () {
					  app.request(s, function (inf) {
						  if (inf.data.status == 1) {
							  wx.showModal({
								  title: '提示',
								  content: inf.data.message,
								  success: function (res) {
									  if (res.confirm) {
										  wx.reLaunch({
											  url: '/pages/index/index',
										  })
									  } else if (res.cancel) {
										  // console.log('用户点击取消')
									  }
								  }
							  })
						  } else {
							  wx.showModal({
								  title: '提示',
								  content: inf.data.message,
								  success: function (res) {
									  if (res.confirm) {
										  wx.switchTab({
											  url: '/pages/index/index',
										  })
									  } else if (res.cancel) {
										  // console.log('用户点击取消')
									  }
								  }
							  })
						  }
					  }, function (inf) {
					  })
				  }
			  })
		  },
		  imgUrl
	  )
    
   
  }
}

//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var self = this;
	fonter.init(self);
  var url = urls['index'],
     
    s = { url: url, data: { }, post: 'GET' };
  app.myGetSetting({
    scope_key: 'scope.userInfo',
    fail: function () {
    },
    callback: function () {
      app.request(s, function (inf) {
        if (inf.data.status==0)
        {
          wx.redirectTo({
            url: '/pages/askTeacher/teachercenter',
          })
			/*self.setData({
				list: inf.data,
				isshow: 1
			});*/
        }
        else{
          self.setData({
            list: inf.data,
			isshow:1
          });
        }
       
      }, function (inf) {
      })
    }
  })

};

VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};

VM.onShareAppMessage = function () {

};
Page(VM);