// pages/pay/orderDetail.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {
		
	},
};
var urls = {
	'index': 'source=orderdetail'
}
//取消
VM.myColse = function (e) {
	var that = this;
		
		wx.navigateBack({
			delta: 1
		})
	



};
//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var that = this;
	fonter.init(that);
	var url = urls['index'],
		s = { url: url, data: { orderid: query.id }, post: 'GET' };
	app.request(s, function (inf) {
		// console.log(inf)
		if (inf.errorCode == 0) {
			that.setData(inf.data)

		}
	}, function (inf) {

	})
	
};



VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};

VM.onShareAppMessage = function () {

};
Page(VM);