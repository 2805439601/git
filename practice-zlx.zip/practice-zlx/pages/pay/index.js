// pages/pay/index.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
  data: {
    page: 0,
    sb:[]
  },
};
var urls = {
  'index': 'source=pay'
}

//支付提示
VM.Worning = function(e){
	var that = this,
		title = e.currentTarget.dataset['title'];
		
	wx.showModal({
		title: '提示',
		content: '确定使用'+title+'支付',
		success: function (res) {
			if (res.confirm) {
				that.payMoney(e);
			} else if (res.cancel) {
				
			}
		}
	})
}
//支付
VM.payMoney = function(e){
	var that = this,
		key = e.currentTarget.dataset['key'];
	var	price = parseFloat(that.data.list.fee);

	var	balance = 0;
  that.data.list.credtis && (balance = parseFloat(that.data.list.credtis.credit2));
	var url = urls['index'],
		data = {},
		s = { url: url, data:data, post: 'GET' };
	if (that.data.op=='buyvip'){
		s.data.ordertype = 'buyvip';
	}
	if (key =="balance"){
		if (balance >= price){
			
			s.data = that.data.list.params;
			s.data.op = 'credit';
			app.myGetSetting({
				scope_key: 'scope.userInfo',
				fail: function () {
				},
				callback: function () {
					app.request(s, function (inf) {
						//console.log(inf)
					
						if (inf.errorCode == 0){
							
							wx.showToast({
								title: '支付成功',
								icon: 'success',
								duration: 2000,
								success: function () {
                  if (that.data.sb.type == 'buyvip') {
                    wx.navigateBack({
                      delta: 1
                    })
                  } else {
                    // wx.redirectTo({
                    //   url: '/pages/introduce/coment?orderid=' + that.data.sb.orderid + '&lessonid=' + that.data.sb.lessonid
										// })
                    wx.navigateBack({
                      delta: 1
                    })
                  }
								}
							})
						}else{
							wx.showModal({
								title: '提示',
								showCancel: false,
								confirmColor: '#333333',
								content: '支付失败',
							})
						}
					}, function (inf) {

					})
				}
			})
		}else{
			wx.showModal({
				title: '提示',
				showCancel: false,
				confirmColor: '#333333',
				content: '您的余额不足',
			})
		}
	} else if (key == "wx"){
		s.data.orderid=that.data.level_id;
		s.data.op='wxpay';
		app.myGetSetting({
			scope_key: 'scope.userInfo',
			fail: function () {
			},
			callback: function () {
				app.request(s, function (inf) {
					//console.log(inf)
					if (inf.errorCode == 0) {
						app.myRequestPayment(
							inf.data.wxpay,
							function(res){
								wx.showToast({
									title: '支付成功',
									icon: 'success',
									duration: 2000,
									success: function () {
                    if (that.data.sb.type == 'buyvip'){
                      wx.navigateBack({
											delta: 1
										})
                    } else{
                     
                      // wx.redirectTo({
                      //   url: '/pages/introduce/coment?orderid=' + that.data.sb.orderid + '&lessonid=' + that.data.sb.lessonid
											// })
											
											wx.navigateBack({
												delta: 1
											})
                    }
										
                    
									}
								})
							},
							function (res) {
								wx.showModal({
									title: '提示',
									showCancel: false,
									confirmColor: '#333333',
									content: '支付失败',
								})
							}
						)
						
					}else{
						wx.showModal({
							title: '提示',
							showCancel: false,
							confirmColor: '#333333',
							content: inf.data,
						})
					}
				}, function (inf) {
					wx.showModal({
						title: '提示',
						showCancel: false,
						confirmColor: '#333333',
						content: '支付失败',
					})
				})
			}
		})
	}
}
//获取用户信息
VM.onLoad = function (query) {
  // 登录
	var self = this;
	fonter.init(self);
	if (query.level_id){
		self.setData(query)
		var url = urls['index'],
			s = { url: url, data: { orderid: query.level_id, ordertype: query.op }, post: 'GET' };
		app.myGetSetting({
			scope_key: 'scope.userInfo',
			fail: function () {
			},
			callback: function () {
				app.request(s, function (inf) {
					console.log(inf.data.sb)
					self.setData({
						list: inf.data,
            sb: inf.data.sb
					});
				}, function (inf) {
				})
			}
		})
	}
  
};



VM.onReady = function () {

};

VM.onShow = function () {
  var self = this;

};

VM.onShareAppMessage = function () {

};
Page(VM);