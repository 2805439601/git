// pages/myCurse/index.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {
    pages:1,//顶部分页
    pages2:2,//触底分页
    show: false,//弹框
		isFooter: 'usercenter',
		key:'',
		curr: 0,//第几页
		end: false,//是否加载中
		noend: true,//是否最后一页 true非最后一页
		//测试数据
		isNo: 1,
		//试学课程列表
		sxList:[],
		list: [],
    lessid:0
	},
};

var urls = {
	'index': 'source=mylesson',
  'mylive':'source=self&op=myLiveLesson'
}
//切换
VM.choseTap = function(e){
	var that = this,
		curr = e.currentTarget.dataset['curr'],
    id = e.currentTarget.dataset['id'];
		that.setData({
			curr: curr,
      lessid:id,
      pages2:2
		})
  var url2 = urls['mylive'],
    data2 = { page: 1, id: id },
    s2 = { url: url2, data: data2 };
  app.request(s2, function (inf2) {
    if (inf2.errorCode == 0) {
      that.setData({
        list:inf2.data.list,
        total: inf2.data.total
      })
    }
  })
}

VM.gotoPlay = function(e){
	// var status = e.currentTarget.dataset['status'],
	// 		id = e.currentTarget.dataset['id'],
	// 		cate_id = e.currentTarget.dataset['cateid'],
	// 		sectionid = e.currentTarget.dataset['sectionid'],
	// 		sectiontype = e.currentTarget.dataset['sectiontype'],
	// 		idx = e.currentTarget.dataset['idx']
	// if(status == 0){
	// 	//跳转报名
	// 	wx.navigateTo({
	// 		url: '/pages/livebroadcast/curriculumList/index?cate_id=' + cate_id + '&id=' +id
	// 	});
	// }else if(status == 1){
	// 	//跳转直播间
	// 	wx.navigateTo({
	// 		url: '/pages/livebroadcast/livebroadcastDetail/index?id=' + id
	// 	});
	// }else{
	// 	//播放录播
	// 	wx.navigateTo({
	// 		url: '/pages/introduce/section?sectionid=' + sectionid + '&id=' + id + '&sectiontype=' + sectiontype + '&idx=' + idx
	// 	});
	// }
  var that = this
  var live = e.currentTarget.dataset.live
  var live_status = e.currentTarget.dataset.live_status
  if (live_status == '2') {
    wx.navigateTo({
      url: '../videodemo/videodemo?item=' + JSON.stringify(live),
    })
  } else if (live_status == '0') {


    wx.showModal({
      title: '直播未开始',
      content: '',
    })
  } else if (live_status == '1') {
    var tag = e.currentTarget.dataset.tag
    var url = e.currentTarget.dataset.url
    var vods = e.currentTarget.dataset.vods

    if (tag == 1) {
      if (vods.length == 1) {
        var item = vods[0]
        wx.navigateTo({
          url: '/pages/vodDemo/vodDemo?item=' + JSON.stringify(item)
        })
      }else{
        that.setData({
          show: true,
          vods: vods,
          hideBox: true
        })
      }
      

    } else {
      wx.showModal({
        title: '直播已结束',
        content: '没有录播视频',
      })
    }

  }
};
// 关闭弹框
VM.vclose = function() {
  var that = this
  that.setData({
    show: false,
    vods: [],
    hideBox: false
  })
};
VM.allgo = function(e) {
  var that = this
  var item = e.currentTarget.dataset.item
  wx.navigateTo({
    url: '/pages/vodDemo/vodDemo?item=' + JSON.stringify(item)
  })
};

//重置页面
VM.reset = function () {//
	var that = this;
	that.setData({
		page: 1,
		end: false,
		noend: true,
		list: []
	});
	// that.getList()
};

//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var that = this;
	fonter.init(that);
  var url = urls['index'],
    data = { page: 1, status: 1, size: 6 },
    s = { url: url, data: data };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      if (inf.data.mylessonlist[0].lessonid){
       var lessid = inf.data.mylessonlist[0].lessonid
       that.setData({
         lessid: inf.data.mylessonlist[0].lessonid
       })
      }
      that.setData({
        sxList: inf.data.mylessonlist
      })
      //课程
      var url2 = urls['mylive'],
        data2 = { page: 1, id: lessid },
        s2 = { url: url2, data: data2 };
      app.request(s2, function (inf2) {
        if (inf2.errorCode == 0) {
          that.setData({
            list: inf2.data.list,
            total: inf2.data.total
          })
        }
      })
    }
   
  })
  
};
//查看更多
VM.takemore = function(){
  var that = this
  var pages = that.data.pages
  var url = urls['index'],
    data = { page: pages + 1, status: 1, size:6},
    s = { url: url, data: data };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      var list = that.data.sxList
      for (var i = 0; i < inf.data.mylessonlist.length;i++){
        list.push(inf.data.mylessonlist[i])
      }
      if (inf.data.mylessonlist != ""){
        that.setData({
          pages:pages+1
        })
      } else{
        wx.showToast({
          title: "没有更多数据了",
          icon: "success",
          duration: 2e3
        })
      }
      console.log(list)
      setTimeout(function(){
        that.setData({
          sxList: list
        })
      },500)

      
    }
  })
};

VM.onReady = function () {

};

VM.onShow = function () {
	var that = this;
	// that.reset()
};
// 触底分页
VM.getList = function () {
  var that = this
// <<<<<<< .mine
//   var pages = that.data.pages
//   var pages2 = that.data.pages2
// ||||||| .r12
//   var pages2 = that.data.pages2
// =======
  var pages2 = that.data.pages2+1
// >>>>>>> .r19
  //课程
  console.log(pages)
  var url2 = urls['mylive'],
    data2 = { page: pages2, id: that.data.lessid },
    s2 = { url: url2, data: data2 };
  app.request(s2, function (inf2) {
    if (inf2.errorCode == 0) {

      var list = that.data.list
      for (var i = 0; i < inf2.data.list.length; i++) {
        list.push(inf2.data.list[i])
      }
      
      if (inf2.data.list != "") {
        that.setData({
          pages2: pages2
        })
      } else {
        wx.showToast({
          title: "没有更多数据了",
          icon: "success",
          duration: 2e3
        })
      }
      setTimeout(function () {
        that.setData({
          list: list
        })
      }, 500)

      // that.setData({
      //   list: inf2.data.list,
      // })
    }
  })
};
VM.onShareAppMessage = function () {

};
// 去上课
VM.goffuck = function(){
  var that = this
  wx.navigateTo({
    url: '/pages/introduce/index?id=' + that.data.lessid,
  })
}
// 去浏览
VM.goffuck2 = function () {
  var that = this
  wx.reLaunch({
    url: '/pages/index/index',
  })
}

Page(VM);
