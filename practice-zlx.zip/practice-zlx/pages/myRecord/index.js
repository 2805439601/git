// pages/myCurse/index.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {
    pages:1,//顶部分页
    pages2:1,//触底分页
    show: false,//弹框
		isFooter: 'usercenter',
		key:'',
		curr: 0,//第几页
		end: false,//是否加载中
		noend: true,//是否最后一页 true非最后一页
    loadType:0,
		//测试数据
		isNo: 1,
		//试学课程列表
		sxList:[
      
    ],
		list: [],
    showListNum : null,

	},
};

var urls = {
	'index': 'source=mylesson',
  'mylive':'source=self&op=myLiveLesson',
  'myrecord': 'source=Myrecord&op=getrecord'
}
//切换
VM.choseTap = function(e){
	var that = this,

    start = e.currentTarget.dataset.start,
    end = e.currentTarget.dataset.end,
    curr = e.currentTarget.dataset.curr;
  
  that.setData({
    curr: curr,
    list:[],
    loadType:0,
    showListNum:null
  });
  this.getRecord(start, end);

}

//展开详细
VM.showList = function (e) {
  var that = this,
    curr = e.currentTarget.dataset.index;
  
  var currnum = null;
  curr != that.data.showListNum ? currnum = curr : currnum = null;
  that.setData({
    showListNum: currnum
  });
  console.log(curr, that.data.showListNum)

}


// 关闭弹框
VM.vclose = function() {
  var that = this
  that.setData({
    show: false,
    vods: [],
    hideBox: false
  })
};

//重置页面
VM.reset = function () {//
	var that = this;
	that.setData({
		page: 1,
		end: false,
		noend: true,
		list: []
	});
	// that.getList()
};

//进入页面加载
VM.onLoad = function (query) {
  var that = this;
  // 时间格式化
  function format(time,type) {
    function add0(m) { return m < 10 ? '0' + m : m }
    var time = new Date(time);
    var y = time.getFullYear();
    var m = time.getMonth() + 1;
    var d = time.getDate();
    var h = time.getHours();
    var mm = time.getMinutes();
    var s = time.getSeconds();
    if(type == 'day'){
      return y + '/' + add0(m) + '/' + add0(d);
    }else{
      return y + '/' + add0(m) + '/' + add0(d) + ' ' + add0(h) + ':' + add0(mm) + ':' + add0(s);
    }
  }
  // 获取时间
  var getData = new Date();                                                           //当前时间
  var getTodayDay = format(new Date(new Date()),'day');                               //当前日期
  
  var getWeek = new Date().getDay()-1;                                                  //周几

  var tablistdatas = [];
  tablistdatas.push({
    bookname : '本周',
    startTime: format(new Date(getTodayDay).setHours(0, 0, 0, 0) - (86400 * getWeek * 1000)),
    endTime: format(getData)
  });

  for(let i=0;i<5;i++){
    tablistdatas.push({
      bookname: '',
      startTime: format(new Date(tablistdatas[i].startTime).setHours(0, 0, 0, 0) - (86400 * 7 * 1000)),
      endTime: tablistdatas[i].startTime
    });
    tablistdatas[i + 1].bookname = tablistdatas[i + 1].startTime.substring(0, 10) + '  ' + tablistdatas[i + 1].endTime.substring(0, 10);
  }
  
  that.setData({
    sxList: tablistdatas
  })
  // 获取列表
  this.getRecord(tablistdatas[0].startTime, tablistdatas[0].endTime);

};
//格式化时间
VM.setTime = function(mss){
  var hours = parseInt((mss % ( 60 * 60 * 24)) / ( 60 * 60));
  var minutes = parseInt((mss % ( 60 * 60)) / ( 60));
  var seconds = (mss % (60));
  hours = hours < 10 ? ('0' + hours) : hours;
  minutes = minutes < 10 ? ('0' + minutes) : minutes;
  seconds = seconds < 10 ? ('0' + seconds) : seconds;

  return hours + ":" + minutes + ":" + seconds;
}
//获取列表
VM.getRecord = function(startTime,endTime){
  var that = this
  fonter.init(that);
  var url = urls['myrecord'],
  data = {
    playtime: {
      start: startTime,
      end: endTime
    }
  },
  s = { url: url, data: data, post: 'post' };
  app.request(s, function (inf) {
    //console.log(inf);
    that.setData({
      loadType: 1,
    });

    var data = inf.data;
    var datalist = [];

    var setData = (arr, index) => {
      if (index == null || index == undefined){
        datalist[datalist.length] = {
          bookname: arr.bookname,
          id: arr.id,
          playtime: parseInt(arr.playtime),
          images: app.globalData.approot + '../../attachment/' + arr.images,
          find: [arr]
        }
        datalist[datalist.length - 1].find[0].playtime = that.setTime(arr.playtime)
        
      }else{
        datalist[index].playtime = datalist[index].playtime + parseInt(arr.playtime);
        arr.playtime = that.setTime(arr.playtime);
        datalist[index].find[datalist[index].find.length] = arr;
      }
    }

    //处理数据
    if (inf.errorCode == 0 && data.length !=0) {
      for (let i = 0; i < data.length;i++){
        if (datalist.length > 0){
          var forNumber = datalist.length;
          var forindex = null;
          for (let n = 0; n < forNumber;n++){
            var sart = 0;
            if(datalist[n].id == data[i].id){
              forindex = n;
            }
          }
          
          setData(data[i],forindex);
        }else{
          setData(data[0]);
        }
      }
      for (let i = 0; i < datalist.length;i++){
        datalist[i].playtime = that.setTime(datalist[i].playtime);
      }

      that.setData({ list: datalist});
      console.log(that.data.list)
    }else{
      that.setData({ list: [] });
    }
    
  });
}

VM.onReady = function () {

};

VM.onShow = function () {
	var that = this;
	// that.reset()
};

VM.onShareAppMessage = function () {
};


Page(VM);
