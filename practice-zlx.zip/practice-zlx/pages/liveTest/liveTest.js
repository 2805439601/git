// index.js
// 获取应用实例
const app = getApp();

const LIVE = require("../../sdk/live");
const GSSDK = require("../../sdk/gssdk");
const GS = GSSDK.GS;

Page({
    data: {
      array: ["submitQuestion", "submitVote", "submitRollcall", "submitChat", "submitChatTo", "submitNetChoice", "requireNetSettings", "uploadLogFile", "submitAnswerSheet"],
        index: 0,//数组下标
        textValue: '',//输入框的值
        dataArray: [],//获取到的数据
        playSrc: '',//视频参数
        joinItem: '',//加入设置各种参数
        autoplay: true,
        showBar: false
    },
    onLoad: function (options) {
        this.channel = GS.createChannel();
        app.globalData.channel = this.channel;
        // 页面初始化 options为页面跳转所带来的参数
        if (options.item) {
            this.setData({
                joinItem: JSON.parse(options.item)
            });
        }

    },
    onReady: function (res) {
        var that = this;
        var evts = ["onDocChange", "onDataReady", "onQA", "onQARemove",
            "onQAList", "onSetting", "onMessage", "onKickOut",
            "onRollcall", "onLottery", "onUserList", "onUserJoin",
            "onUserLeave", "onUserOnline", "onStart", "onPause",
            "onPlay", "onStop", "onVote", "onVoteResult", "onStatus",
            "onAPIError", "onPublicChat", "onPriChat", "onNetSettings",
            "onAnnoClear", "onChatRemove", "onQAHighlight",
          "onCancelHighlight", "onTagAudio", "onVideoUrl", "onAudioUrl", "onInitAnno", "onAnnotation", "onTitle", "onAnswerSheet", "onAnswerSheetAnswer"];

        for (var i = 0; i < evts.length; i++) {
            this.channel.bind(evts[i], function (e) {
                var dataArr = that.data.dataArray, obj = {};
                var date = new Date();
                var hours = date.getHours(), minutes = date.getMinutes(), seconds = date.getSeconds();

                obj.time = that.numTen(hours) + ":" + that.numTen(minutes) + ":" + that.numTen(seconds);
                obj.name = e.type + ":";
                obj.data = JSON.stringify(e.data);

                dataArr.unshift(obj);
                if (e.type == "onVideoUrl") {
                    that.setData({
                        playSrc: e.data,
                        dataArray: dataArr
                    });
                } else {
                    that.setData({
                        dataArray: dataArr
                    });
                }
            });
        }
        LIVE.init({
            "site": that.data.joinItem.site,
            "ownerid": that.data.joinItem.id,
            "ctx": that.data.joinItem.ctx,
            "authcode": that.data.joinItem.authcode,
            "uid": '',
            "uname": app.globalData.userInfo.nickName,
            "encodetype": '',
            "password": '',
            "stream": '',
            "istest": 'true'
        }, function (e) {
            console.log("回调");
            app.globalData.userInfo.userid = e.userid;
        });

        this.numTen = function (m) {
            return m > 9 ? m : '0' + m;
        }
    },
    onUnload: function (res) {
        LIVE.refresh();
    },
    pickerChange: function (e) {
        this.setData({
            index: e.detail.value
        })
    },
    textareaValue: function (e) {
        var val = e.detail.value;
        this.setData({
            textValue: val
        })
    },
    sendMes: function (e) {
        var that = this, arr = this.data.array, index = this.data.index, val = this.data.textValue, dataArr = this.data.dataArray, obj = {};
        if (val == '') return false;
        var date = new Date();
        var hours = date.getHours(), minutes = date.getMinutes(), seconds = date.getSeconds();

        obj.time = that.numTen(hours) + ":" + that.numTen(minutes) + ":" + that.numTen(seconds);
        obj.name = arr[index] + ":";
        obj.data = val;

        this.channel.send(arr[index], JSON.parse(val));
        dataArr.unshift(obj);
        that.setData({
            dataArray: dataArr
        });
    },
    timeupdate: function (event) {
        app.globalData.currentTime = event.detail.currentTime;
    },
    playVideo: function (e) {
        LIVE.toldPlay();
        LIVE.initBindPlaying();
        LIVE.initBindPlay();
    },
    pauseVideo: function (e) {
        LIVE.initBindPause();
    },
    waitVideo: function (e) {
        LIVE.initBindWaiting();
    },
    endVideo: function (e) {
        LIVE.initBindEnded();
    }

});