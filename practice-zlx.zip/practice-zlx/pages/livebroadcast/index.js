// pages/myCurse/index.js
var app = getApp();
var fonter = require('../common/footer.js');
var {formatTime} = require('../../utils/util.js');

var VM = {
	data: {
		isFooter: 'livebroadcast',
		isphone: null,
		key:'',
		nowDate: null,
    is_last: !1,
    page: 1,
		//测试数据,日期为当天的直播课列表
		list:[
			// {
			// 	id: 0,
			// 	title: "",
			// 	list: [
			// 		{
			// 			id: 0,
			// 			img: "",
			// 			title: "",
			// 			start_time: 1566436869370,
			// 			end_time: 1566440469370,
      //       desc: "",
			// 		},
					
			// 	]
			// },
			
		]
	},
};

var urls = {
	'index': 'source=mylesson',
  'lists':'source=lesson&op=liveLesson'
}

//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var that = this;
	fonter.init(that);
  var url = urls['lists']
  var data = {p:1}
  var s = { url: url, data: data };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      that.setData({
        list: inf.data.list,
        page: 2
      })
    } else{

    }

  })
	
};
//分页
VM.onReachBottom = function(){
  var that = this;
  var url = urls['lists']
  var data = { p: that.data.page }
  var s = { url: url, data: data };
  that.data.is_last || app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      if (inf.data.list == ''){
        that.setData({
          is_last: !0
        }), 
        wx.showToast({
          title: "没有更多数据了",
          icon: "success",
          duration: 2e3
        });
      } else{
        for (var e = that.data.list, s = 0; s < inf.data.list.length; s++) e.push(inf.data.list[s]);

        that.setData({
          list: e,
          page: that.data.page + 1
        })
      }
       
      
    } else {

    }

  })
};

VM.onReady = function () {

};

VM.onShow = function () {
	var that = this;
	// console.log(new Date().getTime())
	this.setData({
		nowDate: new Date().getTime()
	});

	//list时间
	let newList = that.filter(this.data.list);
	this.setData({
		list: newList
	});
};

VM.filter = function(list){
	let that = this;
	let newList = list.map(item => {
		for(let i=0; i<item.list.length; i++){
			item.list[i].newTime = formatTime(item.list[i].start_time, 'h:i');
		}
		return item;
	});
	return newList;
}

VM.onShareAppMessage = function () {

};

Page(VM);
