var {
  formatTime
} = require('../../../utils/util.js');
var app = getApp();
var VM = {
  data: {
    nowDate: 0,
    signUpDay: '',
    signUpTime: '',
    isShowSignUp: false,
    //测试数据
    isphone: null,
    pages: 1,
    id: '', //课程id
    cate_id: '', //分类id
    myData: {
      id: 0,
      img: "",
      video: "",
      detailImg: "",
      title: "",
      desc: "",
      isSign: false,
      live_status: 0,
      live: [],
      curriculumList: [
        // {
        //     id: 0,
        //     date: "",
        //     list: [
        //         {
        //             id: 0,
        //             start_time: 1566436869370,
        //             end_time: 1566440469370,
        //             teacher: "",
        //             title: '',
        //             isSign: false
        //         },
        //         {
        //             id: 1,
        //             start_time: 1566440469370,
        //             end_time: 1566444069370,
        //             teacher: "",
        //             title: '',
        //             isSign: true
        //         },
        //         {
        //             id: 2,
        //             start_time: 1566447669370,
        //             end_time: 1566451269370,
        //             teacher: "",
        //             title: '',
        //             isSign: false
        //         },
        //     ]
        // },
        // {
        //     id: 2,
        //     date: "",
        //     list: [
        //         {
        //             id: 3,
        //             start_time: 1566436869370,
        //             end_time: 1566440469370,
        //             teacher: "",
        //             title: '',
        //             isSign: false
        //         },
        //         {
        //             id: 4,
        //             start_time: 1566440469370,
        //             end_time: 1566444069370,
        //             teacher: "",
        //             title: '',
        //             isSign: false
        //         },
        //         {
        //             id: 5,
        //             start_time: 1566447669370,
        //             end_time: 1566451269370,
        //             teacher: "",
        //             title: '',
        //             isSign: false
        //         },
        //     ]
        // },
      ]
    }
  },
};
var urls = {
  'list': 'source=lesson&op=liveLessonList',
  'havephone': 'source=self&op=checkMobile',
  'takename': 'source=self&op=lessonEnter',
  'livelist': 'source=lesson&op=liveLessonMore'
}
//获取用户信息
VM.onLoad = function (query) {
  // 登录
  var that = this;
  if (query.id) {
    this.setData({
      cate_id: query.cate_id,
      id: query.id
    });
  }
  this.setData({
    nowDate: new Date().getTime(),

  });

  let newList = that.filter(that.data.myData.curriculumList);
  let listString = "myData.curriculumList";
  that.setData({
    [listString]: newList
  });
  var url = urls['list']
  var data = {
    cate_id: query.cate_id,
    id: query.id
  }
  var s = {
    url: url,
    data: data
  };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      that.setData({
        myData: inf.data
      })
    } else {

    }

  })
  // 获取以前的直播列表
  var urlss = urls['livelist']
  var datas = {
    cate_id: query.cate_id,
    page: 1
  }
  var ss = {
    url: urlss,
    data: datas
  };
  app.request(ss, function (inf) {
    if (inf.errorCode == 0) {
      console.log('c')
      console.log(inf)
      that.setData({
        livelist: inf.data.list
      })
    } else {

    }

  })
};

// 分页
VM.onReachBottom = function () {
  var that = this
  var pages = that.data.pages
  // 获取以前的直播列表
  var urlss = urls['livelist']
  var datas = {
    cate_id: that.data.cate_id,
    page: pages
  }
  var ss = {
    url: urlss,
    data: datas
  };
  app.request(ss, function (inf) {
    if (inf.errorCode == 0) {
      console.log('s')
      if (inf.data.list == '') {

        wx.showToast({
          title: "没有更多数据了",
          icon: "success",
          duration: 2e3
        })
      } else {
        var list = that.data.livelist
        for (var i = 0; i < inf.data.list.lenght; i++) {
          list.push(inf.data.list[i])
        }
        that.setData({
          pages: pages + 1,
          livelist: list,
        })

      }

    } else {

    }

  })

};
VM.filter = function (list) {
  let that = this;
  let newList = list.map(item => {
    for (let i = 0; i < item.list.length; i++) {
      item.list[i].start_time = formatTime(item.list[i].start_time, 'h:i');
      item.list[i].end_time = formatTime(item.list[i].end_time, 'h:i');
    }
    return item;
  });
  return newList;
}
VM.formSubmit = function (e) {
  var that = this
  // console.log(e)
  // return
  var formid = e.detail.formId
  let info = e.currentTarget.dataset.info;
  let index = e.currentTarget.dataset.index;
  let i = e.currentTarget.dataset.i;
  let id = e.currentTarget.dataset.id;
  let day = info.date;
  let time = `${info.list[index].start_time}-${info.list[index].end_time}`;
  let String = `myData.curriculumList[${i}].list[${index}].isSign`;

  //报名请求
  var url = urls['takename']
  var data = {
    id: id,
    formid: formid
  }
  var s = {
    url: url,
    data: data
  };
  // wx.showModal({
  //   title: '立即报名',
  //   content: '',
  //   showCancel: false,
  //   success: () => {
      wx.requestSubscribeMessage({
        tmplIds: ["45hhbQspfFAksRtSFVrx-2sIOUetyOVerK8u2AxIDtk"],
        success: (res) => {
          console.log(res)
          if (res['45hhbQspfFAksRtSFVrx-2sIOUetyOVerK8u2AxIDtk'] === 'accept') {
            wx.showToast({
              title: '订阅成功',
              duration: 1000,
              success(data) {
                app.request(s, function (inf) {
                  if (inf.errorCode == 0) {
                    // 重新加载数据
                    var urlc = urls['list']
                    var datac = {
                      cate_id: that.data.cate_id,
                      id: that.data.id
                    }
                    var sc = {
                      url: urlc,
                      data: datac
                    };
                    app.request(sc, function (inf) {
                      if (inf.errorCode == 0) {

                        that.setData({
                          myData: inf.data
                        })
                      } else {

                      }

                    })

                    that.setData({
                      signUpDay: day,
                      signUpTime: time,
                      isShowSignUp: true,
                      [String]: true
                    })
                  } else {
                    wx.showModal({
                      title: '提示',
                      showCancel: false,
                      confirmColor: '#333333',
                      content: inf.data.message,
                    })
                  }
                })
              }
            })
          } else if (res['45hhbQspfFAksRtSFVrx-5-E_uTz5BvszJ8RbJ_EHp8'] === 'reject') {
            wx.showToast({
              title: '拒绝授权',
              duration: 1000,
              success(data) {

              }
            })
          }
        },
        fail(err) {
          //失败
          console.error(err);
          // reject()
        }
      })
    // }
  // })
}
// 往期报名
// VM.formSubmit = function (e) {
//   var that = this
//   var formid = e.detail.formId
//   let index = e.target.dataset.index;
//   let i = e.target.dataset.i;
//   let id = e.target.dataset.id;
//   let day = info.date;
//   let time = e.target.dataset.time;;
//   let String = `myData.curriculumList[${i}].list[${index}].isSign`;


//   //报名请求
//   var url = urls['takename']
//   var data = { id: id, formid: formid }
//   var s = { url: url, data: data };
//   app.request(s, function (inf) {
//     if (inf.errorCode == 0) {

//       // 重新加载数据
//       var urlc = urls['list']
//       var datac = { cate_id: that.data.cate_id, id: that.data.id }
//       var sc = { url: urlc, data: datac };
//       app.request(sc, function (inf) {
//         if (inf.errorCode == 0) {

//           that.setData({
//             myData: inf.data
//           })
//         } else {

//         }

//       })

//       that.setData({
//         signUpDay: day,
//         signUpTime: time,
//         isShowSignUp: true,
//         [String]: true
//       })

//     } else {
//       wx.showModal({
//         title: '提示',
//         showCancel: false,
//         confirmColor: '#333333',
//         content: inf.message,
//       })
//     }

//   })
// }



//报名
VM.signUp = function (e) {
  var that = this
  console.log(e.target.dataset.info, e.target.dataset.index, e.target.dataset.i);
  let info = e.target.dataset.info;
  let index = e.target.dataset.index;
  let i = e.target.dataset.i;
  let id = e.target.dataset.id;
  let day = info.date;
  let time = `${info.list[index].start_time}-${info.list[index].end_time}`;
  let String = `myData.curriculumList[${i}].list[${index}].isSign`;


  //报名请求
  var url = urls['takename']
  var data = {
    id: id
  }
  var s = {
    url: url,
    data: data
  };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {

      // 重新加载数据
      var urlc = urls['list']
      var datac = {
        cate_id: that.data.cate_id,
        id: that.data.id
      }
      var sc = {
        url: urlc,
        data: datac
      };
      app.request(sc, function (inf) {
        if (inf.errorCode == 0) {

          that.setData({
            myData: inf.data
          })
        } else {

        }

      })

      that.setData({
        signUpDay: day,
        signUpTime: time,
        isShowSignUp: true,
        [String]: true
      })

    } else {
      wx.showModal({
        title: '提示',
        showCancel: false,
        confirmColor: '#333333',
        content: inf.message,
      })
    }

  })
}
VM.gobuy = function () {
  var that = this
  wx.navigateTo({
    url: '/pages/introduce/index?id=' + that.data.myData.p_id,
  })
};
//关闭报名框
VM.hideSignUp = function () {
  this.setData({
    isShowSignUp: false
  })
}

VM.onReady = function () {

};

VM.getPhoneNumber = function (e) {
  var that = this;
  if (e.detail.errMsg == "getPhoneNumber:ok") {
    wx.setStorageSync('isphone', true);
    app.myGetPhoneNumber(function () {
      that.setData({
        isphone: true
      })
      if (e.target.dataset.type == "bm") {
        that.signUp(e);
        return;
      }
      wx.navigateTo({
        url: `../livebroadcastPlay/index?id=${e.target.dataset.id}`
      })
    }, e.detail);
  }
}

VM.onShow = function () {
  var that = this;
  this.setData({
    nowDate: new Date().getTime(),
    isphone: wx.getStorageSync('isphone')
  });
};
VM.golive = function (e) {
  var that = this

  wx.navigateTo({
    url: '../../videodemo/videodemo?item=' + JSON.stringify(e.currentTarget.dataset.item),
  })
};
VM.gotoPlay = function () {
  var that = this
  console.log(that.data.myData.live)
  wx.navigateTo({
    url: '../../videodemo/videodemo?item=' + JSON.stringify(that.data.myData.live),
  })
};

Page(VM);