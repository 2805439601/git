var {formatTime} = require('../../../utils/util.js');
var app = getApp();
var VM = {
	data: {
    isphone: false,//先默认没有电话,
    isphonebox:false,//授权电话弹框是否显示
        //直播课介绍和最近的直播时间信息
		myData:{
            id: 0,
            img: "",
            video: "",
            detailImg: "",
            title: "",
            start_time: 1566436869370,
            end_time: 1566440469370,
            desc: "",
            isSign: true,
            articlelist: [
                {
                    id: 0,
                    photo: "http://img4.imgtn.bdimg.com/it/u=2246980521,2027696365&fm=26&gp=0.jpg",
                    phone: 15521022770,
                    text: "进入了直播间"
                },
                {
                    id: 1,
                    photo: "http://img4.imgtn.bdimg.com/it/u=2246980521,2027696365&fm=26&gp=0.jpg",
                    phone: 15521022770,
                    text: "进入了直播间"
                },
            ]
        }
	},
};
var urls = {
  'text' : 'source=lesson&op=liveLessonDetail',
  'phone' : 'source=self&op=checkMobile',
  'takephone' : 'source=self&op=bindMobile'
}
//获取用户信息
VM.onLoad = function (query) {
	// 登录
    var that = this;
    that.setData({
      id: query.id,
      islogin:app.globalData.islogin
    })
    if(JSON.stringify(query) != "{}"){
        wx.setNavigationBarTitle({
            title: query.title
        })
    }
  var url = urls['text']
  var data = { id: query.id }
  var s = { url: url, data: data };
  app.request(s, function (inf) {
    if (inf.errorCode == 0) {
      that.setData({
        myData: inf.data.lesson,
      })
    } else {

    }

  })

};
//用户授权
VM.getuserinfo= function(e) {
  var userInfo = e.detail.userInfo;
  var that = this;
  if (userInfo) {
    that.setData({
      islogin: true,
      isOpen: 2,
    })
    wx.setStorageSync('scope.userInfo', userInfo);
    app.globalData.userInfo = userInfo;
    app.globalData.islogin = true;
    //判断是否有绑定手机号码
    var url = urls['phone']
    var data = {}
    var s = { url: url, data: data };
    app.request(s, function (inf) {
      if (inf.errorCode == 0) {
        //重新获取是否有报名
        var urlc = urls['text']
        var datac = { id: that.data.id }
        var sc = { url: urlc, data: datac };
        app.request(sc, function (inf) {
          if (inf.errorCode == 0) {
            that.setData({
              myData: inf.data.lesson,
            })
          } else {

          }

        })



        if (inf.data.is_bind == 1){
          if (that.data.myData.isSign == 1 && that.data.myData.live_status == '2'){
            wx.navigateTo({
              url: '../../videodemo/videodemo?item=' + JSON.stringify(that.data.myData.live),
            })
          } else if (that.data.myData.isSign == 0){
            wx.redirectTo({
              url: '../curriculumList/index?cate_id=' + that.data.myData.cate_id + '&id=' + that.data.myData.id,
            })
          } else if (that.data.myData.isSign == 1 && that.data.myData.live_status != '2'){
              wx.showModal({
                title: '直播未开始',
                content: '',
              })
          }
            
        } else if (inf.data.is_bind == 0){
          that.setData({
            isphonebox:true,
            isphone: false
          })
        }
        // that.setData({
        //   myData: inf.data.lesson,
        //   isphone: app
        // })
      } else {

      }

    })


    



  } else {
    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '你已拒绝授权',
    })
  }
};

//
VM.gogo = function (e) {
  var that = this
  var live_status = e.currentTarget.dataset.live_status
  if (live_status == '0'){
    wx.showModal({
      title: '直播未开始',
      content: '',
    })
  } else if (live_status == '1') {
    wx.showModal({
      title: '直播已结束',
      content: '',
    })
  } else{
    wx.navigateTo({
      url: '../../videodemo/videodemo?item=' + JSON.stringify(that.data.myData.live),
    })
  }
  
};
// 获取电话
VM.getPhoneNumber = function (e) {
  var that = this;
  if (e.detail.errMsg == "getPhoneNumber:ok") {
    wx.setStorageSync('isphone', true);
    app.myGetPhoneNumber(function () {
      that.setData({
        isphone: true
      })
    }, e.detail);
  } else {
    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '你已拒绝授权',
    })
    that.setData({ isphone: true })
  }
};
VM.onReady = function(){

};

VM.getPhoneNumber = function(e){
    console.log(e);
    var that = this;
    if(e.detail.errMsg == "getPhoneNumber:ok"){
        wx.setStorageSync('isphone', true);
        app.myGetPhoneNumber(function(){
            that.setData({
                isphone: true
            })
            wx.navigateTo({
                url: `../livebroadcastPlay/index?id=${e.target.dataset.id}`
            }) 
        }, e.detail);
    }
}

VM.onShow = function () {
    var that = this;
	this.setData({
        nowDate: new Date().getTime(),
        isphone: wx.getStorageSync('isphone')
    });
  var urlc = urls['text']
  var datac = { id: that.data.id }
  var sc = { url: urlc, data: datac };
  app.request(sc, function (inf) {
    if (inf.errorCode == 0) {
      that.setData({
        myData: inf.data.lesson,
      })
    } else {

    }

  })
};
VM.golist = function(e){
  var that = this;
  if (app.globalData.islogin){
    console.log(that.data.myData,that.data.myData.cate_id)
    wx.redirectTo({
      url: '../curriculumList/index?cate_id=' + that.data.myData.cate_id + '&id=' + that.data.myData.id,
    })
  } else{
    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '请先授权登录',
    })
  }
 
};

Page(VM);

