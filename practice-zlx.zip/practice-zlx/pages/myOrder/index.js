// pages/myCurse/index.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {
		isFooter: 'usercenter',
		key:'',
		page: 1,//第几页
		end: false,//是否加载中
		noend: true,//是否最后一页 true非最后一页
		//测试数据
		isNo: 1,
    syInfo: '',//判断当前设备iOS还是安卓
		//试学课程列表
		sxList:[
			{
				id: 0,
				images: "/images/banner.jpg",
				buynum_total: 2,
				seccount: 7,
				bookname: "本科学历提升",
				price: 0.01,
				section_status: 0
			},
			{
				id: 1,
				images: "/images/banner.jpg",
				buynum_total: 2,
				seccount: 7,
				bookname: "本科学历提升",
				price: 0.01,
			},
			{
				id: 2,
				images: "/images/banner.jpg",
				buynum_total: 2,
				seccount: 7,
				bookname: "本科学历提升",
				price: "免费",
			}
		],
		list: []
	},
};

var urls = {
	'index': 'source=mylesson'
}
//切换
VM.choseTap = function(e){
	var that = this,
		key = e.currentTarget.dataset['key'];
		that.setData({
			key: key
		})
		that.reset()
}
//跳转页面
VM.myReTo = function(e){
	var that = this,
		key = e.currentTarget.dataset['key'],
		id= e.currentTarget.dataset['id'];
  if (that.data.syInfo == 'ios') {
    wx.showModal({
      title: '提示',
      content: '由于相关规范，iOS功能暂不可用',
      showCancel: false
    })
    return
  }
	if (key =='pay'){
		wx.navigateTo({
			url:'/pages/pay/index?level_id=' + id
		})
	}else{
		var lessonid = e.currentTarget.dataset['lessonid'];
		if(key=='section'){
			wx.navigateTo({
				url: '/pages/introduce/index?myTap=2&id='+lessonid
			})
		}else{
			wx.navigateTo({
				url: '/pages/introduce/coment?orderid=' + id + '&lessonid=' + lessonid
			})
		}
	}
}
// 取消订单二次确认
VM.showno = function(e){
  var that = this
  wx.showModal({
    title: '提示',
    content: '是否确定取消订单',
    success: function (res) {
      if (res.confirm) {
        that.setData({
          noindex: e.currentTarget.dataset['idx']
        })
        that.myCancle()
      }
      if (res.cancel) {
        // console.log('用户点击取消')
      }
    }
  })
    
}
//取消订单
VM.myCancle = function(e){
	var that = this,
		// index = e.currentTarget.dataset['idx'],
    index = that.data.noindex,
		list = that.data.list;
	var data = { orderid: list[index].id,op: 'cancle' },
		url = urls['index'],
		s = { url: url, data: data };
	wx.showLoading({
		title: '正在取消',
	})
	
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			wx.showToast({
				title: '取消订单成功',
				icon: 'success',
				duration: 2000
			})
			list.splice(index, 1);
			if (that.data.key == '0'){
				if (list.length > 0){
						that.setData({
							list: list,
							isNo: 1
						});
				}else{
					that.setData({
							list: list,
							isNo: 2
						});
					}
					
			}else{
					that.reset()
			}
			
		}else{
			if (inf.data){
				wx.showModal({
					title: '提示',
					showCancel: false,
					confirmColor: '#333333',
					content: inf.data.message,
				})
			}else{
				wx.showModal({
					title: '提示',
					showCancel: false,
					confirmColor: '#333333',
					content: "数据加载失败",
				})
			}
			
			
		}

		wx.hideLoading()
	}, function (inf) {
		wx.hideLoading()
	})
} 
//删除订单
VM.myDetel = function(e){
	var that = this,
		index = e.currentTarget.dataset['idx'],
		list = that.data.list;
	var data = { orderid: list[index].id, op: 'cancle',is_delete:1 },
		url = urls['index'],
		s = { url: url, data: data };
	wx.showLoading({
		title: '正在删除',
	})

	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			wx.showToast({
				title: '删除订单成功',
				icon: 'success',
				duration: 2000
			})
			list.splice(index, 1);
			if (list.length > 0) {
				that.setData({
					list: list,
					isNo: 1
				});
			} else {
				that.setData({
					list: list,
					isNo: 2
				});
			}
		}

		wx.hideLoading()
	}, function (inf) {
		wx.hideLoading()
	})
}
//重置页面
VM.reset = function () {//
	var that = this;
	that.setData({
		page: 1,
		end: false,
		noend: true,
		list: []
	});
	that.getList()
};

VM.getList = function () {
	var that = this, page = that.data.page, myEnd = that.data.end;
	if (myEnd || !that.data.noend) { return };//判断是否在加载中或者已经到最后一个
	that.setData({
		end: true
	});

	var data = { page: page};
	if (that.data.key == 4){
		data.status = 1;
		data.is_verify=0;
	}else{
		data.status = that.data.key;
	}
	var url = urls['index'],
		s = { url: url, data: data };
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			var list = that.data.list || [];
			inf.data.mylessonlist.forEach(function (o, i) {
				list.push(o);
			})
			page++;
			if(list.length>0){
				that.setData({
					isNo:1
				});
			}else{
				that.setData({
					isNo: 2
				});
			}
			if (inf.data.pageCount < page) {
				that.setData({
					list: list,
					noend: false,
					page: page,
					end: false

				});
			} else {
				that.setData({
					list: list,
					page: page,
					end: false
				});
			}
		} else {
			that.setData({
				end: false
			});
		}
	}, function (inf) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '数据加载失败',
		})
		that.setData({
			isMask3: 2,
			end: false
		});
	})

}

//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var that = this;
	fonter.init(that);
  var syInfo = app.sysInfo();//判断iOS还是安卓
  that.setData({
    syInfo: syInfo
  })
};

VM.onReady = function () {

};

VM.onShow = function () {
	var that = this;
	that.reset()
};

VM.onShareAppMessage = function () {

};
Page(VM);
