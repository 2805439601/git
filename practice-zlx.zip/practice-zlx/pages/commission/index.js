// pages/commission/index.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {
		
	},
};
//请求地址集合
var urls = {
	'index': 'source=commission'
}

VM.myCommit = function(){
	var that = this;
	if (that.data.member.nopay_commission < that.data.cash_lower){
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: "当前提现最低额度为" + that.data.cash_lower + "元",
			success: function () {
				
			}
		})
	}
}
//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var self = this;
	self.setData({
		approot: app.globalData.approot
	})
	fonter.init(self);
	
};

VM.onReady = function () {
	
};

VM.onShow = function () {
	var self = this;
	var url = urls['index'],
		s = { url: url, data: {} };

	app.myGetSetting({
		scope_key: 'scope.userInfo',
		fail: function () {

		},
		callback: function () {
			app.request(s, function (inf) {
				//console.log(inf)
				if (inf.errorCode == 0) {
					//console.log(index)
					inf.data.tolMoney = parseFloat(inf.data.member.nopay_commission + inf.data.member.pay_commission).toFixed(2);
					self.setData(inf.data)

				} else {
					wx.showModal({
						title: '提示',
						showCancel: false,
						confirmColor: '#333333',
						content: inf.data.message,
						success: function () {
							wx.navigateBack({

							})
						}
					})
				}
			}, function (inf) {
				wx.showModal({
					title: '提示',
					showCancel: false,
					confirmColor: '#333333',
					content: '数据加载失败',
				})
			})
		}
	})
};

VM.onShareAppMessage = function () {

};
Page(VM);