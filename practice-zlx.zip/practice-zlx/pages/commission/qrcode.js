// pages/commission/qrcode.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {
		
	},
};

//请求地址集合
var urls = {
	'index': 'source=qrcode'
}
//取消
VM.myColse = function (e) {
	var that = this;
	// console.log('我在返回')
	wx.navigateBack({
		delta: 1
	})


};
//预览图片
VM.lookImg = function() {
	var that = this,
		img = [that.data.imagepath];


	wx.previewImage({
		current: '', // 当前显示图片的http链接
		urls: img // 需要预览的图片http链接列表

	})

};

//获取数据列表
VM.getList = function () {
	var that = this;



	var data = { uid: that.data.uid};

	var url = urls['index'],
		s = { url: url, data: data };
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			that.setData(inf.data)
      
			
		} else {
			wx.showModal({
				title: '提示',
				showCancel: false,
				confirmColor: '#333333',
				content: inf.data.message,
			})
			
		}


	}, function (inf) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '数据加载失败',
		})
	

	})

};

//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var that = this;
  wx.getSystemInfo({
    success: function (res) {
      that.setData({
        widheight: res.screenHeight,
        widwidth: res.screenWidth
      });
      console.log(res.bgcolor)
      
    }
  });
	fonter.init(that);
	
	app.myGetSetting({
		scope_key: 'scope.userInfo',
		fail: function () {

		},
		callback: function () {
			if (query.uid && query.uniacid){
				that.setData(query);
				that.getList();
			}else{
				wx.showModal({
					title: '提示',
					showCancel: false,
					confirmColor: '#333333',
					content: '页面参数缺失',
				})
			}
			
		}

	})
};

VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};
//滑动加载
VM.onReachBottom = function () {
	var that = this;

};
VM.onShareAppMessage = function () {

};
Page(VM);