// pages/teacher/account.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {

	},
};


var urls = {
	'index': 'source=teachercenter'
}


//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var self = this;
	fonter.init(self);
	var url = urls['index'],
		s = { url: url, data: { op: 'account' }, post: 'GET' };
	app.myGetSetting({
		scope_key: 'scope.userInfo',
		fail: function () {

		},
		callback: function () {
			app.request(s, function (inf) {
				var account;
				if (!inf.data.teacher.teacher){
					account = ''
				}else{
          account = inf.data.teacher.account;
				}
				self.setData({
					list: inf.data,
					account: account
				});
			}, function (inf) {

			})
		}
	})
};
// 输入
VM.input = function (e) {
	let value = e.detail.value,
		key = e.currentTarget.dataset['key'];
		var data = {};
	data[key] = value;
	this.setData(data);
};
// 点击开通
VM.again = function (e) {
	var submit = e.detail.value,
		self = this;
	if (!self.data.password || self.data.password.length < 6 || self.data.password.length>16) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '请输入6-16位的讲师平台登录密码',
		})
		return;
	}
	var url = urls['index'],
		s = { url: url, data: { op: 'account', account: self.data.account,submit: 1, password: self.data.password } };
	app.myGetSetting({
		scope_key: 'scope.userInfo',
		fail: function () {

		},
		callback: function () {
			app.request(s, function (inf) {
				//console.log(inf)
				if (inf.errorCode == 0) {
					wx.showToast({
						title: '修改成功',
						icon: 'success',
						duration: 2000,
						success: function () {
							wx.navigateBack({
								delta: 1
							})
						}
					})

				} else {
					wx.showModal({
						title: '提示',
						showCancel: false,
						confirmColor: '#333333',
						content: inf.data.message,
					})
				}
				// self.setData({
				// 	list: inf.data
				// });
			}, function (inf) {

			})
		}
	})
},
VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};

VM.onShareAppMessage = function () {

};
Page(VM);