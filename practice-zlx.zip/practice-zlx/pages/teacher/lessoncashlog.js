// pages/teacher/lessoncashlog.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {
		page: 1,//第几页
		end: false,//是否加载中
		noend: true,//是否最后一页 true非最后一页
	},
};

//请求地址集合
var urls = {
	'index': 'source=lessoncashlog'
}
//取消
VM.myColse = function (e) {
	var that = this;
	// console.log('我在返回')
	wx.navigateBack({
		delta: 1
	})


};


//获取数据列表
VM.getList = function () {
	var that = this, page = that.data.page, myEnd = that.data.end;
	if (myEnd || !that.data.noend) { return };//判断是否在加载中或者已经到最后一个
	that.setData({
		end: true
	});



	var data = { page: page };

	var url = urls['index'],
		s = { url: url, data: data };
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			var list = that.data.list || [];
			inf.data.list.forEach(function (o, i) {
				list.push(o);
			})
			page++;

			if (inf.data.pageCount < page) {
				that.setData({
					list: list,
					noend: false,
					page: page,
					end: false

				});
			} else {
				that.setData({
					list: list,
					page: page,
					end: false

				});
			}
		} else {
			wx.showModal({
				title: '提示',
				showCancel: false,
				confirmColor: '#333333',
				content: inf.data.message,
			})
			that.setData({
				end: false

			});
		}


	}, function (inf) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '数据加载失败',
		})
		that.setData({
			end: false
		});

	})

};

//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var that = this;
	fonter.init(that);
	app.myGetSetting({
		scope_key: 'scope.userInfo',
		fail: function () {

		},
		callback: function () {
			that.getList();
		}

	})
};

VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};
//滑动加载
VM.onReachBottom = function () {
	var that = this;
	that.getList();//请求数据
};
VM.onShareAppMessage = function () {

};
Page(VM);