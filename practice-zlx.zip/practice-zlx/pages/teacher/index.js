// pages/teacher/index.js
var app = getApp();
var fonter = require('../common/footer.js');
var WxParse = require('../../utils/wxParse/wxParse.js');

var VM = {
	data: {
		key:1,
		page: 1,//第几页
		end: false,//是否加载中
		noend: true,//是否最后一页 true非最后一页
		//测试数据
		total: '',
		student_num: '',
    syInfo: '',//系统信息，安卓还是iOS或PC
		teacher: {
			// teacherphoto: "http://img4.imgtn.bdimg.com/it/u=2246980521,2027696365&fm=26&gp=0.jpg",
			// teacher: "王老师",
			// desc: "具有丰富的培训和内训经验，专业基础知识扎实；熟悉经济师考试内容，结合实践经验对于经济师培训有自己独到的方法；曾在《中国证券报》、《证券时报》、《上海证券报》《期货日报》、《中国橡胶》及《中国石油报》等报纸和杂志上发表过文章。"
		},
		list:[
			// {
			// 	id: 0,
			// 	images: "/images/banner.jpg",
			// 	bookname: "社群运营高手5天速成班",
			// 	price: 99.00,
			// 	seccount: 1,
			// 	virtualandbuynum: 6
			// },
			// {
			// 	id: 1,
			// 	images: "/images/banner.jpg",
			// 	bookname: "社群运营高手5天速成班",
			// 	price: 99.00,
			// 	seccount: 1,
			// 	virtualandbuynum: 6
			// },
		]
	},
};
var urls = {
	'index': 'source=teacher',
	'collect':'source=updatecollect'
}
//取消
VM.myColse = function (e) {
	var that = this;
	// console.log('我在返回')
	wx.navigateBack({
		delta: 1
	})
};
//切换
VM.chosetap = function(e){
	var that = this,
		key = e.currentTarget.dataset['key'];
		
	if(key==that.data.key){return;}
	
	that.setData({key:key});
} 
//收藏讲师
VM.myCollect = function(e){
	var that = this;
	var data = { id: that.data.teacherid, ctype: 'teacher' };

	var url = urls['collect'],
		s = { url: url, data: data };
	
	//收藏
	that.setData({
		collect: !this.data.collect
	})

	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			var data1 = inf.data, collect;
			if (data1.status == 1) {
				collect = 1;
			} else if (data1.status == 2) {
				collect = false;
			}
			that.setData({
				collect: collect 
			})
			wx.showToast({
				title: data1.message,
				icon: 'success',
				duration: 2000
			})
			
		}
	}, function (inf) {

	})
}
//获取数据
VM.getList = function () {
	var that = this, page = that.data.page, myEnd = that.data.end;
	if (myEnd || !that.data.noend || that.data.key!=1) { return };//判断是否在加载中或者已经到最后一个
	that.setData({
		end: true
	});



	var data = { page: page, teacherid: that.data.teacherid, op:'ajaxgetlesson' };

	var url = urls['index'],
		s = { url: url, data: data };
	app.request(s, function (inf) {
		//console.log(inf)
		if (inf.errorCode == 0) {
			var list = that.data.list || [];
			inf.data.lesson_list.forEach(function (o, i) {
				list.push(o);
			})
			page++;

			if (inf.data.pageCount < page) {
				that.setData({
					list: list,
					noend: false,
					page: page,
					end: false

				});
			} else {
				that.setData({
					list: list,
					page: page,
					end: false

				});
			}
		} else {
			wx.showModal({
				title: '提示',
				showCancel: false,
				confirmColor: '#333333',
				content: inf.data.message,
			})
			that.setData({
				end: false

			});
		}


	}, function (inf) {
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '数据加载失败',
		})
		that.setData({
			end: false
		});

	})

}


//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var that = this;
  var syInfo = app.sysInfo();//判断iOS还是安卓
  that.setData({
    syInfo: syInfo
  })

	fonter.init(that);
	that.setData({ appUrl: app.globalData.approot});
	if (query.id) {
		that.setData({teacherid: query.id});
		var url = urls['index'],
			s = { url: url, data: { teacherid: query.id }, post: 'GET' };
		// wx.showLoading({
		// 	title: '加载中...',
		// })
		app.request(s, function (inf) {
			//console.log(inf)
			if (inf.errorCode == 0) {
				var article = inf.data.teacher.teacherdes;
				// console.log(article)
				WxParse.wxParse('article1', 'html', article, that, 5);
				that.setData(inf.data);
				that.getList()
			}
			wx.hideLoading()
		}, function (inf) {

		})
	}
};

VM.onReady = function () {

};
VM.onReachBottom = function () {
	var that = this;

	that.getList();
};
VM.onShow = function () {
	var self = this;

};

VM.onShareAppMessage = function () {

};
Page(VM);