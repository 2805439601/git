// pages/search/index.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
  data: {
    isFooter: 'search',
    isMask: 3, //排序列表选项，1选择排序，2选择分类，3空白
    isOpen: '', //打开分类项序号，如区块链：1
    value: '',
    title1: '综合排序', //选项文字
    isKey: '', //排序选项代号如free
    title2: '', //选项文字
    page: 1, //第几页
    end: false, //是否加载中
    noend: true, //是否最后一页 true非最后一页
    syInfo: '', //系统信息，安卓还是iOS或PC
  },
};
//请求地址集合
var urls = {
  'index': 'source=search',

}
//点击排序导航
VM.choseItem = function (e) {
  var that = this,
    isMask = that.data.isMask,
    key = e.currentTarget.dataset['key'];
  if (key) {
    isMask == key ? isMask = 3 : isMask = key;
  } else {
    isMask = 3;
  }

  that.setData({
    isMask: isMask
  })

};
//点击排序项
VM.choseSearch = function (e) {
  var that = this;

  var key = e.currentTarget.dataset['key'],
    key1 = that.data.isMask,
    title = e.currentTarget.dataset['title'];
  if (that.data.isKey == key) {
    that.setData({
      isMask: 3
    });
    return;
  }

  var data = {};
  data.isKey = key;
  data.isMask = 3;
  data['title' + key1] = title;
  that.setData(data)
  that.reset();
}
//选择分类项
VM.choseAllItem = function (e) {
  var that = this,
    title = e.currentTarget.dataset['key'],
    id = e.currentTarget.dataset['idx'];

  if (id == '') { //判断是否选择全部分类
    that.setData({
      isOpen: ''
    });
  }
  if (that.data.title2 == title) { //判断是否为当前选项
    that.setData({
      isMask: 3
    });

    return;
  }
  var data = {};
  data.isMask = 3;
  data['title2'] = title;
  data['cid'] = id;
  that.setData(data)
  that.reset();
}
//展开选项
VM.choseOpen = function (e) {
  var that = this,
    key = e.currentTarget.dataset['key'];
  if (key === that.data.isOpen) {
    key = ''
  }
  that.setData({
    isOpen: key
  });

}

//输入关键字
VM.myInput = function (e) {
  var self = this,
    value = e.detail.value;
  if (value != '') {
    value = value.replace(/ /ig, '')
    self.setData({
      value: value,

    })
  } else {
    self.setData({
      value: ''
    })
  }
};

//重置页面
VM.reset = function () { //
  var that = this;
  that.setData({
    page: 1,
    end: false,
    noend: true,
    sort: '',
    list: []
  });
  that.getList()
};
//获取数据
VM.getList = function () {
  var that = this,
    page = that.data.page,
    myEnd = that.data.end;
  if (myEnd || !that.data.noend) {
    return
  }; //判断是否在加载中或者已经到最后一个
  that.setData({
    end: true
  });



  var data = {
    page: page,
    isajax: 1
  };
  if (that.data.isRec == 1) {
    data.isRec = that.data.isRec;
    if (that.data.cid) {
      data.rec_id = that.data.cid;
    }

  } else {
    if (that.data.cid) {
      data.cat_id = that.data.cid;
    }
  }
  if (that.data.value != '') {

    data.keyword = that.data.value;
  }

  data.sort = that.data.isKey;
  var url = urls['index'],
    s = {
      url: url,
      data: data
    };
  app.request(s, function (inf) {
    //console.log(inf)
    if (inf.errorCode == 0) {
      var list = that.data.list || [];
      inf.data.list.forEach(function (o, i) {
        list.push(o);
      })
      page++;

      if (inf.data.page_total < page) {
        that.setData({
          list: list,
          noend: false,
          page: page,
          end: false

        });
      } else {
        that.setData({
          list: list,
          page: page,
          end: false

        });
      }
    } else {
      wx.showModal({
        title: '提示',
        showCancel: false,
        confirmColor: '#333333',
        content: '数据加载失败',
      })
      that.setData({
        end: false

      });
    }


  }, function (inf) {
    wx.showModal({
      title: '提示',
      showCancel: false,
      confirmColor: '#333333',
      content: '数据加载失败',
    })
    that.setData({

      isMask3: 2,
      end: false
    });

  })

}



//获取用户信息
VM.onLoad = function (query) {
  // 登录
  var that = this;
  var syInfo = app.sysInfo(); //判断iOS还是安卓
  that.setData({
    syInfo: syInfo
  })
  wx.getSystemInfo({
    success: function (res) {

      if (res.model.indexOf('iPhone 6') != -1) {

        that.setData({
          'isiPhone': 1
        })
      }
    }
  })
  fonter.init(that);
  if (query) {
    that.setData(query)
  }
  var data = {};
  if (query.isRec == 1) {
    that.getList();
  } else {
    var url = urls['index'],
      s = {
        url: url,
        data: data
      };
    app.request(s, function (inf) {
      //console.log(inf)
      var title2 = '全部分类'
      inf.data.categorylist.forEach(function (o) {
        // console.log(o)
        if (o.id == that.data.cid) {
          title2 = o.name;
        }
        o.child.forEach(function (p) {
          // console.log(p)
          if (p.id == that.data.cid) {
            title2 = p.name;
          }
        })
      })
      // console.log(title2)
      that.setData({
        categorylist: inf.data.categorylist,
        title2: title2
      })
      that.getList();

    }, function (inf) {

    })
  }


};

VM.onReady = function () {

};
VM.onReachBottom = function () {
  var that = this;

  if (that.data.isiPhone == 1) {

    that.getList();
  }
};
VM.onShow = function () {
  var self = this;

};

VM.onShareAppMessage = function () {

};
Page(VM);