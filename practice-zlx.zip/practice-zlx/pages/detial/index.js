// pages/detial/index.js
var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    images: "https://zlx.51cedu.com/attachment/images/7/2020/02/jjH8AaCJJlA76a1h3hnO6HH62aJZnG.jpg",

    myTap: 1 //切换1介绍，2章节，3评论
  },

  // 点击切换
  tap: function (e) {
    // console.log(e);
    // console.log(this);
    var that = this,
      key = e.currentTarget.dataset['key'];
    // if (that.data.myTapFirst == 1) {
    //   // that.getList1();
    //   that.setData({
    //     myTapFirst: 2
    //   })
    // }
    that.setData({
      myTap: key
    })

  },
  // 评论列表
  getList1() {
    app.request({

    })
  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    app.request({

    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})