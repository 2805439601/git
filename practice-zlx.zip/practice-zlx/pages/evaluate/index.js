var app = getApp();
var urls = {
  'index': 'source=live_comment&op=getLabels',
  'star':'source=live_comment&op=post'
}
Page({
  data: {
    item: {},
    xx:'',
    score:0,//几颗星
    content:'',//评价内容
    labels: {
      //新增 区分评价
      good:[
        {value: '课堂内容好',i:0, sel: false},
        { value: '课堂内容好', i: 1, sel: false},
        { value: '课堂内容好', i: 2,sel: false},
        { value: '知识点清晰度有待提高', i: 3, sel: false}
      ],
      wrong: [
        { value: '课堂内容有待改进', i: 0, sel: false},
        { value: '课堂内容有待改进', i: 1, sel: false},
        { value: '课堂内容有待改进', i: 2,sel: false},
        { value: '知识点清晰度有待提高', i: 3,sel: false}
      ]
    },
    res: {
      score: {},
      labels: [],
      other: ''
    }
  },
  onLoad: function(options){
    var that = this
    var item = JSON.parse(options.item)
    that.setData({
      item: JSON.parse(options.item),
      id: item.id
    })
    var data = {},
      url = urls['index'],
      s = { url: url, data: data };
    app.request(s, function (inf) {
      // console.log(inf)
      if (inf.errorCode == 0) {
        that.setData({
          labels: inf.data.labels
        })
      }
    })
  },
  sel: function(e){
    let i = e.currentTarget.dataset.i;
    let goodORwrong = this.data.score > 3 ? 'good' : 'wrong';
    let str = `labels.${goodORwrong}[${i}].sel`;
    this.setData({
      [str]: !this.data.labels[goodORwrong][i].sel
    })
  },
  getScore: function(e){
    var that = this
    let str = 'res.score';
    // if ((e.detail.item.score > 3 && that.data.score <= 3) || (e.detail.item.score <= 3 && that.data.score > 3)){

    // } 
      that.setData({
      [str]: e.detail.item,
      score: e.detail.item.score
    })
  },
  otherInput: function(e){
    let str = 'res.other';
    this.setData({
      [str]: e.detail.value,
      content: e.detail.value
    })
    // console.log(e.detail.value)
  },
  submit: function(){
    var that = this
    let res = that.data.res;
    var lab=[];
    let goodORwrong = that.data.score > 3 ? 'good' : 'wrong';
    let labels = that.data.labels[goodORwrong].filter(item => {
      if(item.sel){
        return lab.push(item.value);
      }
    });
    // res.labels = labels;
    // console.log(lab)
    if (that.data.score == 0){
      wx.showModal({
        title: '请为我们打星',
        content: '',
        showCancel: false,
      })
      return
    }
    if (that.data.content == ''){
      wx.showModal({
        title: '请给予意见',
        content: '',
        showCancel: false,
      })
      return
    }
    var data = { lesson_id: that.data.id, star: that.data.score, labels: lab, content: that.data.content},
      url = urls['star'],
      s = { url: url, data: data, post: 'POST' };
    app.request(s, function (inf) {
      // console.log(inf)
      if (inf.errorCode == 0) {
        wx.showModal({
          title: inf.data.message,
          content: '',
          showCancel: false,
          success: function (res) {
            wx.navigateBack({})
          }
        })
      }else{
        wx.showModal({
          title: inf.data.message,
          content: '',
          showCancel: false,
        })
      }
    })
    
  }
})