// pages/classindex/classindex.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      scrollHei:'601px',//设备高度
      tabarHeader:false,//是否显示头部
      nowTarBar:'tab0',//
      nowwwTar:'0',
      showAllWrap:false,//显示所有章节课程
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },
  bindscroll:function(res){//监听滚动事件，显示头部
    var that = this;
    if(res.detail.scrollTop>120){
      that.setData({
        tabarHeader:true
      });
    }else{
      that.setData({
        tabarHeader: false
      });
    }
    var query = wx.createSelectorQuery()
    query.select('#tab0').boundingClientRect()
    query.selectViewport().scrollOffset()
    query.exec(function (re) {
      if (re[0].top < 220 && re[0].top>=0){       // #the-id节点的上边界坐标
          that.setData({
            nowwwTar:'0'
          });
      }
    })
    var queryy = wx.createSelectorQuery()
    queryy.select('#tab1').boundingClientRect()
    queryy.selectViewport().scrollOffset()
    queryy.exec(function (re) {
      if (re[0].top < 220 && re[0].top >= 0) {       // #the-id节点的上边界坐标
        that.setData({
          nowwwTar: '1'
        });
      }
    })
    var queryyy = wx.createSelectorQuery()
    queryyy.select('#tab2').boundingClientRect()
    queryyy.selectViewport().scrollOffset()
    queryyy.exec(function (re) {
      if (re[0].top < 220 && re[0].top >= 0) {       // #the-id节点的上边界坐标
        that.setData({
          nowwwTar: '2'
        });
      }
    })
    var queryyyy = wx.createSelectorQuery()
    queryyyy.select('#tab3').boundingClientRect()
    queryyyy.selectViewport().scrollOffset()
    queryyyy.exec(function (re) {
      if (re[0].top < 230 && re[0].top >= 0) {       // #the-id节点的上边界坐标
        that.setData({
          nowwwTar: '3'
        });
      }
    })
  },
  nowTarB:function(re){//点击头部
      this.setData({
        nowTarBar: re.currentTarget.dataset.inde,
        nowwwTar: re.currentTarget.dataset.now
      });
  },
  showAllWrap:function(){
    this.setData({
      showAllWrap:true
    });
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var aa = wx.getSystemInfoSync().windowHeight;
      this.setData({//获取高度
        scrollHei:aa+'px'
      });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})