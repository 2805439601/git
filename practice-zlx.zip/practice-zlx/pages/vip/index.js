// pages/vip/index.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {
		isFooter: 'usercenter',
    	page:0
	},
};
var urls = {
  'index': 'source=vip'
}
VM.goComfit = function(e){
	var that = this,
		url = urls['index'],
		id = e.currentTarget.dataset['id'],
		s = { url: url, data: { level_id: id, op:'buyvip'}, post: 'GET' };
	app.myGetSetting({
		scope_key: 'scope.userInfo',
		fail: function () {
		},
		callback: function () {
			app.request(s, function (inf) {
				// console.log(inf)
				if(inf.errorCode==0){
					wx.navigateTo({
						url: '/pages/pay/index?op=buyvip&level_id=' + inf.data.orderid
					})
				}else{
					wx.showModal({
						title: '提示',
						confirmColor: '#333333',
						content: inf.data.message,
						success: function (res) {

						}
					})
				}
			}, function (inf) {
			})
		}
	})
}
//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var self = this;
	fonter.init(self);
	self.setData({ appUrl: app.globalData.approot });
  
};
// 更多
VM.more = function(query){
  var self = this;
  let page = this.data.page;
  page = page*1 + 1
  var url = urls['index'],
    s = { url: url, data: { page: page, op: 'ajaxgetlist'}, post: 'GET' };
  app.myGetSetting({
    scope_key: 'scope.userInfo',
    fail: function () {
    },
    callback: function () {
      app.request(s, function (inf) {
        self.setData({
          link: inf.data.evaluate_list
        });
      }, function (inf) {
      })
    }
  })
}


VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;
	var url = urls['index'],
		s = { url: url, data: {}, post: 'GET' };
	app.myGetSetting({
		scope_key: 'scope.userInfo',
		fail: function () {
		},
		callback: function () {
			app.request(s, function (inf) {
				self.setData({
					list: inf.data
				});
			}, function (inf) {
			})
		}
	})
};

VM.onShareAppMessage = function () {

};
Page(VM);