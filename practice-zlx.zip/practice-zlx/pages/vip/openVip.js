// pages/vip/openVip.js
var app = getApp();
var fonter = require('../common/footer.js');
var VM = {
	data: {

	},
};


var urls = {
	'index': 'source=vip'
}


//获取用户信息
VM.onLoad = function (query) {
	// 登录
	var self = this;
	fonter.init(self);
  var url = urls['index'],
    s = { url: url, data: { op: 'vipcard'}, post: 'GET' };
  app.myGetSetting({
    scope_key: 'scope.userInfo',
    fail: function () {

    },
    callback: function () {
      app.request(s, function (inf) {
        self.setData({
          list: inf.data
        });
      }, function (inf) {

      })
    }
  })
};
// 输入
VM.input=function(e){
  let value = e.detail.value;
  this.setData({
    value:value
  })
};
// 点击开通
VM.again=function(e){
  var submit = e.detail.value,
    self  = this,
 token = e.currentTarget.dataset.token
	if (!self.data.value){
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: 'VIP服务卡密码不能为空',
		})
		return;
	}
  var url = urls['index'],
	  s = { url: url, data: { op: 'vipcard', submit: 1, card_password: self.data.value} };
  app.myGetSetting({
    scope_key: 'scope.userInfo',
    fail: function () {

    },
    callback: function () {
      app.request(s, function (inf) {
		  //console.log(inf)
		  if (inf.errorCode == 0) {
			  wx.showToast({
				  title: '开通成功',
				  icon: 'success',
				  duration: 2000,
				  success: function () {
					  wx.navigateBack({
						  delta: 1
					  })
				  }
			  })

		  } else {
			  wx.showModal({
				  title: '提示',
				  showCancel: false,
				  confirmColor: '#333333',
				  content: inf.data.message,
			  })
		  }
			// self.setData({
			// 	list: inf.data
			// });
      }, function (inf) {

      })
    }
  })
},
VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};

VM.onShareAppMessage = function () {

};
Page(VM);