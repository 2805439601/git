const app = getApp();
// var api = require('../../utils/api.js')
// var request = require('../../utils/request.js')
var urls = {
  'index': 'source=self&op=getCode',
  'take':'source=self&op=editMobile'
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    mobile: '',
    code: '',
    send:1,
    codeStatus: 0,
    timenum: ''
  },
  // 获取手机号
  mobile: function (e) {
    var mobile = e.detail.value
    this.setData({
      mobile: e.detail.value
    })
  },
  countDown: function(){
    let _this = this;
    let timer = setInterval(() => {
      _this.setData({
        timenum: --_this.data.timenum
      }, function(){
        if(_this.data.timenum <= -1){
          _this.setData({
            codeStatus: 2
          });
          clearInterval(timer);
        }
      })
    }, 1000);
  },
  // 获取验证码
  send: function () {
    var that = this
    if(that.data.timenum > 0) return;

    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(14[0-9]{1})|(18[0-9]{1})|(16[0-9]{1})|(19[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    var mobile = that.data.mobile
    if (mobile.length === 11) {
      if (!myreg.test(mobile)) { 
        wx.showToast({
          title: '手机号有误！',
          icon: 'none',
          duration: 1500
        })
        return false;
      } else {

        var data = { mobile: mobile },
          url = urls['index'],
          s = { url: url, data: data };
        app.request(s, function (inf) {
          // console.log(inf)
          if (inf.errorCode == 0) {
            that.setData({
              timenum: 60,
              codeStatus: 1
            }, function(){
              that.countDown();
            })
            wx.showToast({
              title: inf.data.message,
              icon: 'none',
              duration: 1500
            })
          }else{
            wx.showToast({
              title: inf.data.message,
              icon: 'none',
              duration: 1500
            })
          }
        })
       
      }

    } else {
      wx.showToast({
        title: '请输入11位手机号码',
        icon: "none",
        duration: 1500
      })
    }
  },

  // 获取验证码
  code: function (e) {
    var code = e.detail.value
    this.setData({
      code: e.detail.value
    })
  },

  // 确定提交
  formSubmit: function () {
    var that = this
    var myreg = /^(((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(19[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    var mobile = that.data.mobile
    var mobile = that.data.mobile
    var code = that.data.code
    if (mobile.length === 11) {
      if (!myreg.test(mobile)) {
        wx.showToast({
          title: '手机号有误！',
          icon: 'none',
          duration: 1500
        })
        return false;
      } else {
        if (code.length != '') {
          //发起网络请求
          var data = { mobile: mobile, code: code},
            url = urls['take'],
            s = { url: url, data: data };
          app.request(s, function (inf) {
            // console.log(inf)
            if (inf.errorCode == 0) {
              wx.showToast({
                title: inf.data.message,
                icon: 'none',
                duration: 1500
              })
              setTimeout(function () {
                wx.reLaunch({
                  url: '/pages/usercenter/usercenter',
                })
              }, 1000)
            } else {
              wx.showToast({
                title: inf.data.message,
                icon: 'none',
                duration: 1500
              })
            }
          })
          
        } else {
          wx.showToast({
            title: '请输入验证码',
            icon: "none",
            duration: 1500
          })
        }
      }
    } else {
      wx.showToast({
        title: '请输入11位手机号码',
        icon: "none",
        duration: 1500
      })
    }

  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})