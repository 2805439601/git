/** 
 * login/login.js
 * 业务组件
 * 通用检查网络&登录
 */
var app = getApp();

var Login = (function () {

	// 检查是否未登录
	function checkLogin(query, cb) {
		if (!app.globalData.userData) {

			// 预留扩展，作为处理分享入口的query参数
			// app.globalData.gradeId = query && query.gid; // 与 userData 区别开
			// 提交key到服务端获取用户信息
			app.login(function (we_session) {
				app.getUserData(function () {
					cb && cb();
				});
			});
		} else {
			cb && cb();
		}
	}


	// 检查网络情况
	function checkNetwork(page, query, cb) {
		var self = page;
		wx.getNetworkType({
			success: function (res) {
				console.log(res)
				var networkType = res.networkType; // 返回网络类型2g，3g，4g，wifi，none, unknown
				if (/fail|none/.test(networkType)) { /*unknown*/
					// 断网
					/*Toast.alert('提示', '网速不太好呢~点确定重试：' + networkType, function () {
						// wx.redirectTo({url: 'pickgrade'});
					});*/
					self.setData({ offline: true });
				} else {
					checkLogin(query, cb);
				}
			}
		});
	}

	return {
		checkLogin: checkLogin,
		checkNetwork: checkNetwork
	};
})();


module.exports = Login;