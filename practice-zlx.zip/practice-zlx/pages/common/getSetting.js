// pages/common/getSetting.js
var app = getApp();
var VM = {
	data: {
		
	},
};
var urls = {
	'index': 'source=index'
}
VM.getUserInfo = function(e){
console.log('把搭把手');
	var userInfo = e.detail.userInfo,
		that = this;
	if (userInfo){
		wx.setStorageSync('scope.userInfo', userInfo);
		if (that.data.scene){
			app.getToken(function () {
				if (!that.data.scene) {
					wx.reLaunch({
						url: '/pages/index/index'
					})
				} else {
					wx.reLaunch({
						url: '/pages/index/index?scene=' + that.data.scene
					})
				}
			}, userInfo,that.data.scene);
		}else{
			app.getToken(function () {
				wx.reLaunch({
					url: '/pages/index/index'
				})
			}, userInfo);
		}
	}else{
		wx.showModal({
			title: '提示',
			showCancel: false,
			confirmColor: '#333333',
			content: '你已拒绝授权',
		})
		console.log('用户拒绝授权')
	}
};
VM.goBack = function(e){
	var that = this;

	if (!that.data.scene) {
		wx.redirectTo({
			url: '/pages/index/index'
		})
	} else {
		wx.redirectTo({
			url: '/pages/index/index?scene=' + that.data.scene
		})
	
	}
	
}
//获取用户信息
VM.onLoad = function (query) {
	
	var that = this;
	if (query.scene){
		that.setData(query);
	}
};

VM.onReady = function () {

};

VM.onShow = function () {
	var self = this;

};

VM.onShareAppMessage = function () {

};
Page(VM);
