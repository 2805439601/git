//app.js
App({
  onLaunch: function (e) {
    wx.login({
      success: res => {
        console.log(res.code);
      }
    })
    let that = this;
    wx.setStorageSync('scence', e)
    wx.getSetting({
      success: function (res) {

        if (res.authSetting['scope.userInfo']) {

          wx.getUserInfo({
            success: res => {
              that.globalData.islogin = true;
              that.globalData.userInfo = res.userInfo

              if (that.userInfoReadyCallback) {
                that.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  },
  //微信支付
  myRequestPayment: function (data, _success, _fail) {
    wx.requestPayment({
      'timeStamp': data.timeStamp,
      'nonceStr': data.nonceStr,
      'package': data.package,
      'signType': data.signType,
      'paySign': data.paySign,
      'success': function (res) {
        if (typeof _success === "function") _success(res);
      },
      'fail': function (res) {
        if (typeof _fail === "function") _fail(res);
      }
    })
  },
  /**
   * 需要设定openSetting的接口
   * @param opt Object
   *   @key storage_key String   storage的key
   *   @key callback    Function pre的回调函数 @param res
   *   @key fail        Function 失败 @param res
   *   @key pre         Function 调用该权限相关的方法，没有则默认执行callback的函数 @param callback
   *   @key scope_key   String   需要判断权限的 getSetting scope
   * (scope.userInfo,scope.userLocation,scope.address,scope.record)
   */
  myGetSetting: function (opt) { //检查是否授权
    // console.log(this.globalData.scenes,121212)
    var storage_key = opt.storage_key,
      scope_key = opt.scope_key, // scope.userLocation需要授权项
      callback = opt.callback,
      fail = opt.fail;
    var needGetSetting = wx.getStorageSync(scope_key);
    var canUse = wx.getSetting;
    wx.getSetting({
      success(res) {
        //console.log(res.authSetting[scope_key])授权状态
        //isOpen：1未授权，2已授权
        if (!res.authSetting[scope_key]) { //未授权
          if (opt.isOPen) {
            var data = {
              isOpen: 1
            };
            callback(data);
          } else {
            //   wx.navigateTo({
            //     url: '/pages/common/getSetting'
            //   })
          }
        } else { //'已授权'
          //console.log('已授权')
          var data = {
            isOpen: 2
          };
          callback(data)
        }
      }
    })
  },
  //手机授权
  myGetPhoneNumber: function (cb, info) {
    wx.login({
      success: (res) => {
        // console.log(res.code);
        // console.log(info)
        console.log(res);
        //发起请求,
        var s = {
          url: 'source=self&op=bindMobile',
          post: 'POST',
          data: {
            encryptedData: info.encryptedData,
            iv: info.iv
          }
        };
        this.request(s, function (inf) {
          // console.log(inf)
          typeof cb == "function" && cb();
        }, function (err) {
          // console.log(err)
        })

      }
    })
  },
  //判断是否已经包含了手机号码
  myPhone: function (noe, fn) {
    var s = {
      url: 'source=self&op=checkMobile'
    };
    this.request(s, function (inf) {
      // console.log(inf)
      if (inf.data.is_bind == 0) { //0未绑定
        noe()
      } else if (inf.data.is_bind == 1) { //1已绑定
        fn()
      }
    }, function (err) {})
  },
  //微信登录
  getToken: function (cb, userInfo, scene) { //登录获取token值
    // console.log('没有key')
    var that = this;
    wx.login({
      success: (res) => {
        // console.log(res,'asdfas')
        var code = res.code;
        if (code) {
          var url = that.globalData.api + 'source=token&op=get';
          var setting = {
            url: url,
            method: 'GET',
            // header: option.header || {'Content-type':'application/json'},
            header: {
              'content-type': 'application/json'
            },
            success: null
          };

          if (userInfo) {
            // console.log('第一次');
            if (scene) {
              setting.data = {
                code: res.code,
                nickName: userInfo.nickName,
                avatarUrl: userInfo.avatarUrl,
                scene: scene
              };

            } else {
              setting.data = {
                code: res.code,
                nickName: userInfo.nickName,
                avatarUrl: userInfo.avatarUrl
              };
            }

          } else {
            var userInfo1 = wx.getStorageSync('scope.userInfo');
            //console.log(userInfo1)	
            setting.data = {
              code: res.code,
              nickName: userInfo1.nickName,
              avatarUrl: userInfo1.avatarUrl
            };
            // console.log('第二次')
          }

          setting.success = function (data) {
              // console.log(data,'token')
              var inf = data.data;
              // console.log(inf.data.token);
              if (inf.data.token) {
                wx.setStorageSync('token', inf.data.token)

                typeof cb == "function" && cb()
              } else {
                //TODO显示异常状态码
                //console.log(inf.data.errorCode)

              }

            },
            setting.fail = function () {
              // console.log('获取token失败')
            }
          wx.request(setting);
        } else {
          // console.log('获取用户登录态失败！');
        }

      }
    })
  },
  checkToken: function (cb) { //检查token
    var that = this;

    var token = wx.getStorageSync('token');
    if (!token) {
      that.getToken()
    } else {
      //console.log('有key')
      /*this.request({ url: 'source=token&op=check' }, (res) => {
      		if (res.data.result) return true;
      		this.getToken()
      })*/
      var url = that.globalData.api + 'source=token&op=check';
      var setting = {
        url: url,
        method: 'GET',
        data: {}, // jsonToFormData
        // header: option.header || {'Content-type':'application/json'},
        header: {
          'content-type': 'application/json',
          'TOKEN': token
        },
        success: null
      };
      setting.success = function (res) {
          // console.log(res)
          // console.log('检查token成功')
        },
        setting.fail = function () {
          // console.log('检查token失败')
        }
      wx.request(setting)
    }
  },
  //图片上传
  myUploadimg: function (data, _success, _fail, _complete, allData) {
    var self = this,
      success = data.success || 0, //成功次数
      i = data.i || 0, //当前文件下标
      fail = data.fail || 0, //失败次数
      invalid = data.invalid || 0, //图片格式错误
      filePath = data.arr[i], //图片路径数组
      url1 = self.globalData.api + allData; //上传文件路径
    // console.log(filePath)
    var token = wx.getStorageSync('token'),
      header = {
        'content-type': 'application/json',
        'TOKEN': token
      };
    wx.uploadFile({
      url: url1,
      filePath: filePath,
      name: 'uploadFile',
      formData: {},
      header: header,
      success: function (res) {

        var d = JSON.parse(res.data);
        //console.log(d)
        var isSuccess;
        i++;
        success++;
        if (i == data.arr.length) {
          isSuccess = true;
        }
        if (typeof _success === "function") _success(d, isSuccess, invalid);
      },
      fail: function (res) {

        //console.log(res);
        var d = JSON.parse(res.data);
        var isSuccess;
        i++;
        fail++;
        //console.log("fail:", fail);
        if (i == data.arr.length) {
          isSuccess = true;
        }

        if (typeof _fail === "function") _fail(d, isSuccess, invalid);
      },
      complete: function (res) {

        var d = JSON.parse(res.data);
        if (d.error == "1") {
          core.alert(res.errMsg);
          return;
        }
        var cb = function () {
          if (i == data.arr.length) { //当图片传完时，停止调用       
            // console.log('执行完毕');
            // console.log('成功：' + success + " 失败：" + fail);
            if (typeof _complete === "function") _complete(res);
          } else {
            data.i = i;
            data.success = success;
            data.fail = fail;
            self.myUploadimg(data, _success, _fail, _complete, allData);
          }
        };

        if (/ok/.test(res.errMsg)) {
          var _data = res;
          if (!invalid && _data.status == 1) {
            // 成功且违规图片
            invalid = 1;
            data.invalid = invalid;
          }
        }
        cb();

      }
    })
  },
  //封装请求数据
  request: function (option, success, fail) {
    var that = this,
      url = that.globalData.api + option.url;
    /*if(option.isUrl){
    	url = 'http://zsff.iiio.top/app/index.php?i=1&c=entry&op=display&id=23&do=app&m=wx_zsff&source=lesson';
    }*/
    option.data = option.data || {};
    // option.data.is_debug = 1
    //that.checkToken()//检查token
    var token = wx.getStorageSync('token') || '';
    // console.log(token)
    var scene = 'no'
    if (wx.getStorageSync('scene')) {
      scene = wx.getStorageSync('scene')
    }

    var setting = {
      url: url,
      method: option.post || 'GET',
      data: option.data, // jsonToFormData
      header: option.header || {
        'content-type': 'application/json',
        'TOKEN': token,
        'scene': scene
      },
      success: null
    };
    if (option.post === 'POST') {
      setting.header = {
        'content-type': 'multipart/form-data',
        'TOKEN': token,
        'scene': scene
      }
    }
    //console.log(setting.header)
    //setting.success
    setting.success = function (res) {
      if (res.data.errorCode >= 1000 && res.data.errorCode < 1100) {
        // console.log(option.isOpen);
        if (!option.isOpen) {
          that.myGetSetting({
            scope_key: 'scope.userInfo',
            fail: function () {

            },
            callback: function () {
              that.getToken(function () {
                //console.log('token异常')
                that.request(option, success, fail)
              });
            }

          })
        } else {
          typeof success == "function" && success(res.data)
        }
        return;
      };

      if (res.data.errorCode > 999) that.uniFail(res.data)
      typeof success == "function" && success(res.data)
    }
    //setting.fail
    setting.fail = function (res) {
      typeof fail == "function" && fail(res)
    }
    wx.request(setting);
    // console.log(option);
    // console.log(success);
  },
  uniFail: function (data) {
    if (data.data) {
      // wx.showToast({
      //   title: data.data.message,
      //   icon: 'none',
      //   duration: 2000
      // })
      // console.log(data)
    } else {
      // console.log(2)
    }
  },
  //判断安卓还是iOS
  sysInfo: function () {
    var info;
    wx.getSystemInfo({
      success: function (res) {
        if (res.platform == "devtools") {
          info = 'pc'
        } else if (res.platform == "ios") {
          info = 'ios'
        } else if (res.platform == "android") {
          info = 'android'
        }
      }
    })
    return info
    // return 'ios'
  },
  globalData: {
    appid: "wxf00e29bc9530f927",
    // api: "https://3680.yesswl.top/api/zsff_api.php?i=7&",
    // approot: "https://3680.yesswl.top/addons/wx_zsff/",
    // appImg:'https://3680.yesswl.top/addons/wx_zsff/template/mobile/images/',
    api: "https://zlx.51cedu.com/api/zsff_api.php?i=7&",
    approot: "https://zlx.51cedu.com/addons/wx_zsff/",
    appImg: 'https://zlx.51cedu.com/addons/wx_zsff/template/mobile/images/',
    //api: "https://zlxt1.51cedu.com:444/api/zsff_api.php?i=7&",
    //approot: "https://zlxt1.51cedu.com:444/addons/wx_zsff/",
    //appImg: 'https://zlxt1.51cedu.com:444/addons/wx_zsff/template/mobile/images/',
    userInfo: null,
    islogin: false, //判断是否已授权登录
    ver: 315,
    channel: null, //SDK使用
    currentTime: 0, //SDK使用
  }
})