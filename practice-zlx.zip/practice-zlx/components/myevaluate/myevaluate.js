Component({
  properties: {
    isIcon: {
      type: Boolean,
      value: true
    }
  },
  data: {
    sel: {
      value: '请选择', 
      score: 0, 
      icon: '/images/evaluate_null.png'
    },
    evaluate: [
      {value: '很差', score: 1, icon: '/images/evaluate_l.png'},
      {value: '差', score: 2, icon: '/images/evaluate_l.png'},
      {value: '一般', score: 3, icon: '/images/evaluate_c.png'},
      {value: '满意', score: 4, icon: '/images/evaluate_h.png'},
      {value: '很满意', score: 5, icon: '/images/evaluate_h.png'},
    ]
  },
  methods: {
    selEvaluate(e){
      let i = e.currentTarget.dataset.i;
      this.setData({
        sel: this.data.evaluate[i]
      });
      this.triggerEvent('getScore', {item: this.data.evaluate[i]});
    }
  }
})
