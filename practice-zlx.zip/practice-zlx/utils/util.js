const formatTime = (date, formats) => {
  formats = formats || 'y-m-d';
  let myDate = date ? new Date(date) : new Date();
  const year = myDate.getFullYear();
  const month = formatNumber(myDate.getMonth() + 1);
  const day = formatNumber(myDate.getDate());
  const hour = formatNumber(myDate.getHours());
  const minute = formatNumber(myDate.getMinutes());
  const second = formatNumber(myDate.getSeconds());

  return formats.replace(/y|m|d|H|i|s/ig, function(matches){
    return ({
      y: year,
      m: month,
      d: day,
      h: hour,
      i: minute,
      s: second
    })[matches];
  });

  // return [year, month, day].map(formatNumber).join('-') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

module.exports = {
  formatTime: formatTime
}
