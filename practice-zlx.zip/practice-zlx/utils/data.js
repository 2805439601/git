var list = [{
  "id": "h9cjfC3rBY",//直播id
		"title": "随便写点字不要太多",//直播主题
		"status": 0,//直播状态 0未开始 1直播中
		"num": 0,//在线人数
		"pic": parseInt(Math.random()*4+1),//左边的图片1-4
    "ctx": "training",//webcast or training
		"authcode": '222222',//加入密码 可选
  "site": '51cedu.gensee.com',//站点域名
		"liveDemo": true
	}, {
    "id": "437c7527d1054fa290e2ee152f06a6fc",
		"title": "随是飒飒",
		"status": 1,
		"num": 100,
		"pic": parseInt(Math.random()*4+1),
		"ctx": "webcast",
		"authcode": '222222',
    "site": '192.168.1.138',
		"liveDemo": true
	}, {
    "id": "6f5a0999c3b8407e9a609e06f2ad0ee0",
		"title": "随是飒飒",
		"status": 1,
		"num": 100,
		"pic": parseInt(Math.random()*4+1),
		"ctx": "webcast",
		"userid": '',
		"username": '',
		"authcode": '',
		"site": '192.168.1.106',
    "liveTest": true
	}, {
    "id": "d5fa16edf9ff4947a5addfd621af4a70",//直播id
    "title": "你叫啥",//直播主题
    "status": 0,//直播状态 0未开始 1直播中
    "num": 0,//在线人数
    "pic": parseInt(Math.random() * 4 + 1),//左边的图片1-4
    "ctx": "webcast",//webcast or training
    "authcode": '333333',//加入密码 可选
    "site": '192.168.1.106',//站点域名
		"liveTest": true
	}];
module.exports = list;